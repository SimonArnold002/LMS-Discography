package Plugins::Discography::Browse;

# Browse feeds for the Discography plugin.
#
# Step 2 (current): the real discography list — MusicBrainz release-groups in
# original-release-date order (newest/oldest toggle at the top of the view,
# fleet convention), Cover Art Archive tiles, and a per-release detail page
# with the MusicBrainz metadata + weblink. Step 3 adds source resolution
# (local library + Qobuz/Tidal/Deezer/Spotify) and playback.
#
# String rule: NO non-ASCII literals in output strings (no `use utf8` in the
# fleet — a literal em dash double-encodes to mojibake). Use \x{..} escapes,
# which are proper Perl characters (same as LBF's tiles).

use strict;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(cstring);
use Slim::Utils::PluginManager;
use Slim::Utils::Timers;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Misc;
use Slim::Schema;
use File::Spec;
use Time::HiRes ();

use Plugins::Discography::API;
use Plugins::Discography::Sources;
use Plugins::Discography::Covers;

# The FUNCTION form (0.56.16): LMS's logger() takes the category as its first
# argument, so `Slim::Utils::Log->logger(...)` filed this file's lines under
# "Slim::Utils::Log" and dropped everything below WARN (Slim/Utils/Log.pm).
my $log   = logger('plugin.discography');
my $prefs = preferences('plugin.discography');
# The plugin's own store (DB.pm), version-scoped -- see the note in API.pm.
# MUST match API.pm exactly (asserted by tools/syntax_check.sh).
use Plugins::Discography::DB;
use constant CACHE_VERSION => '0.56.30';
my $cache = Plugins::Discography::DB->store(CACHE_VERSION);

use constant REVIEW_FOUND_TTL => 30 * 86400;
use constant REVIEW_EMPTY_TTL =>  1 * 86400;
use constant REVIEW_SUMMARY_CHARS => 380;   # summary cut point (word boundary)

use constant BIO_FOUND_TTL => 30 * 86400;
use constant BIO_EMPTY_TTL =>  1 * 86400;

# Similar artists (MAI/Last.fm related artists).
use constant SIMILAR_FOUND_TTL => 30 * 86400;
use constant SIMILAR_EMPTY_TTL =>  1 * 86400;
use constant SIMILAR_MAX       => 25;          # cap the "Similar artists" list

# Plugin-shipped images. The *_MTL_icon_<name>.png convention makes Material
# swap in its themed '<name>' icon (icon-mapping.js); the PNG itself is the
# fallback for other skins.
use constant IMG_BASE     => 'plugins/Discography/html/images/';
use constant ICON         => IMG_BASE . 'DiscographyIcon_svg.png';
use constant MENU_SORT    => IMG_BASE . 'dsc-sort_MTL_icon_sort.png';
use constant MENU_REFRESH => IMG_BASE . 'dsc-refresh_MTL_icon_refresh.png';
use constant MENU_SEARCH  => IMG_BASE . 'dsc-find_MTL_icon_search.png';
# Reuses the shipped library_music glyph for the local-only view toggle (both
# states) — no new asset, per the 0.25.0 icon-reuse precedent.
use constant MENU_LOCAL   => IMG_BASE . 'dsc-lib_MTL_icon_library_music.png';

use constant SEARCH_TTL   => 600;  # merged artist-search results (item_id walk
                                   # determinism across legacy re-walks, not a
                                   # data cache — searches are user-initiated)
use constant BANNER_MAX     => 20;  # cover tiles sent (CSS clips to one row —
                                    # what fits the viewport is what shows;
                                    # 20 x 132px fills up to ~2600px ultrawide)
use constant BANNER_TILE_PX => 120; # fixed tile size the responsive row clips to
# Detail-page rows: prose (type 'text') must stay IMAGE-LESS — Material
# mutates text+image items to type "other" (browse-resp.js:800), which loses
# the full-wrap prose rendering (0.7.2 regression: clamped review summary,
# broken view). Only LINK rows get thumb-slot icons; flush-left prose is the
# fleet-standard look (LBF detail pages do the same, deliberately).
use constant MENU_REVIEW  => IMG_BASE . 'dsc-review_MTL_icon_rate_review.png';
use constant MENU_WEBLINK => IMG_BASE . 'dsc-link_MTL_icon_launch.png';
use constant PAGE_MORE    => IMG_BASE . 'dsc-ver_MTL_icon_unfold_more.png';
use constant PAGE_LESS    => IMG_BASE . 'dsc-pg_MTL_icon_unfold_less.png';

# Rows shown per section before "Show more" (and the step it grows by).
use constant PAGE_SIZE => 30;

# Seconds the first render waits for the bootleg map (API::warmOfficial) before
# giving up and showing the unfiltered list. One MB request per 100 groups on
# the page (stage 2), so at most 6, about 7s on the public API: every artist's
# check fits. Pref `official_wait` overrides; 0 opts out of waiting entirely.
use constant OFFICIAL_WAIT_DEFAULT => 15;

# Seconds the first render waits for a COLD streaming pool when hide_unmatched
# is on (see the await block in _discographyView). Purely a safety net against a
# service handler that never calls back: the wait normally ends when resolution
# does. Long enough for three services to answer, short enough that a wedged
# handler doesn't look like a hung page.
use constant POOL_WAIT_MAX => 20;

# The same wait with hide_unmatched OFF (0.56.26). Nothing is hidden then, so a
# service that answers late costs only its badges and covers until the next
# visit, and the page should not stand still for the full watchdog. Measured
# 2026-10-02: a cold pool lands about 1.7 s after the page would have drawn
# (Calum Scott, James Arthur); TIDAL's own watchdog is SVC_TIMEOUT, 20 s.
use constant POOL_WAIT_SHOWN => 6;

# Secondary types NEVER shown (variant noise, not discography entries). Live
# is deliberately NOT here — it's its own selectable section now.
my %HIDE_SECONDARY = map { $_ => 1 } ('Remix', 'DJ-mix');

# Section order for the grouped view (fixed, independent of the date sort).
# MB primary types map: Album->ALBUMS, EP->EPS, Single->SINGLES; a secondary
# "Compilation" or "Live" wins over the primary; Broadcast/Other/untyped ->
# OTHER. Which sections actually show is the show_types pref (CSV of keys).
# Icons are Material's OWN release-type set, referenced via the MTL_svg_<name>
# image-name convention (icon-mapping.js maps it to the named built-in svg;
# the placeholder .png only exists so non-Material skins don't 404).
my @GROUP_ORDER = (
    [ ALBUMS       => 'PLUGIN_DISCOGRAPHY_ALBUMS',       'release-album'  ],
    [ EPS          => 'PLUGIN_DISCOGRAPHY_EPS',          'release-ep'     ],
    [ SINGLES      => 'PLUGIN_DISCOGRAPHY_SINGLES',      'release-single' ],
    [ COMPILATIONS => 'PLUGIN_DISCOGRAPHY_COMPILATIONS', 'album-multi'    ],
    [ LIVE         => 'PLUGIN_DISCOGRAPHY_LIVE',         'release-live'   ],
    [ OTHER        => 'PLUGIN_DISCOGRAPHY_OTHER',        'release'        ],
);

# The release groups the Singles view shows (the Albums | Singles toggle).
my %SINGLE_FAMILY = (SINGLES => 1, EPS => 1);

sub _groupOf {
    my ($rg) = @_;
    return 'COMPILATIONS' if grep { $_ eq 'Compilation' } @{ $rg->{secondary} };
    return 'LIVE'         if grep { $_ eq 'Live' }        @{ $rg->{secondary} };
    my $t = $rg->{type} || '';
    return 'ALBUMS'  if $t eq 'Album';
    return 'EPS'     if $t eq 'EP';
    return 'SINGLES' if $t eq 'Single';
    return 'OTHER';
}

# A release's type icon, the one its section header shows (0.56.26: a tile with
# no cover the server holds shows it, see _caaHeld).
my %GROUP_ICON = map { $_->[0] => $_->[2] } @GROUP_ORDER;
sub _typeIcon {
    my ($rg) = @_;
    return IMG_BASE . 'dsc_MTL_svg_' . $GROUP_ICON{ _groupOf($rg) } . '.png';
}

# Release-groups grouped by the MATCHER's normalised title: the rivals that will
# all title-match the same streaming candidate. Only groups that can actually be
# rendered take part — a bootleg or a Remix/DJ-mix group must never win a
# candidate away from the real album, which would then show nothing.
#
# Order IS the ownership order (Sources::_rivalOwner takes rivals->[0] as the
# default winner) and must be deterministic across rebuilds:
#   1. real album before compilation. "The Beatles" the album (1968) beats
#      "The Beatles" the compilation (1967) even though the compilation is
#      EARLIER — a self-titled record is the album; the same-named ones are
#      collections of it. Date alone would hand the White Album to a 1967 comp.
#   2. earliest first-release-date (undated last).
#   3. mbid, so ordering can never depend on hash iteration.
# A candidate belongs to exactly ONE release group; this decides which. Order
# matters twice over — `_rivalOwner` takes the FIRST rival whose year matches
# the candidate, and the first rival outright when none does.
#
# TYPE RANK (0.46.8). Field, from the full-library sweep: **three of ABBA's nine
# studio albums were missing** — Ring Ring, Waterloo and Super Trouper, i.e.
# exactly the three whose title is ALSO a single. Measured against the mirror:
#
#   Waterloo       Album 1974-03-04   vs  Single 1974-03
#   Super Trouper  Album 1980-11-03   vs  Single 1980-11
#   Ring Ring      Album 1973-03-26   vs  Single 1973-02-14
#
# Sorting on `date cmp` put the SINGLE first every time, so it took the
# streaming candidate and `hide_unmatched` then removed the album. Note WHY for
# two of the three: a partial date is a PREFIX of the fuller one, so
# "1980-11" sorts before "1980-11-03" — the tie-break was deciding on date
# PRECISION rather than chronology, which was nobody's intent.
#
# A service release titled "Super Trouper" by ABBA is the ALBUM; 1970s vinyl
# singles rarely exist as separate streaming releases at all. So primary type
# ranks ahead of date: Album, then EP, then Single.
#   KNOWN COST: where a service DOES carry both, both candidates now land on the
#   album (its detail lists two versions) and the single row hides. Giving each
#   rival its own best candidate needs a global assignment pass across every
#   release group — far more than this defect warrants.
my %RIVAL_TYPE_RANK = ( Album => 0, EP => 1, Single => 2 );

sub _rivalsByTitle {
    my ($rgs, $officialMap, $show) = @_;

    my %by;
    for my $rg (@$rgs) {
        next if grep { $HIDE_SECONDARY{$_} } @{ $rg->{secondary} };
        my $official = $officialMap ? $officialMap->{ $rg->{mbid} } : undef;
        next if defined $official && !$official;          # bootleg: can't own anything
        # AND NOT A GROUP THE USER HAS HIDDEN (0.46.8). This list already
        # excludes what cannot be rendered — bootlegs, Remix/DJ-mix — for
        # exactly one reason: an invisible group must not win a candidate the
        # visible album would then never show. The user's own type filter was
        # missed, so with Singles hidden the single still claimed the album's
        # candidate and NEITHER row appeared. Second half of the same sweep
        # finding ("the matcher runs over release groups that are never
        # rendered — 202 match calls for 75 rendered releases").
        next if $show && !$show->{ _groupOf($rg) };

        push @{ $by{ Plugins::Discography::Sources::_norm($rg->{title}) } }, {
            mbid => $rg->{mbid},
            year => ($rg->{date} =~ /^(\d{4})/) ? $1 : undef,
            comp => ((grep { $_ eq 'Compilation' } @{ $rg->{secondary} }) ? 1 : 0),
            # Unknown/absent primary type sorts with Album rather than last: it
            # is what an untyped studio release usually is, and demoting it
            # would recreate this bug for artists MB has typed loosely.
            rank => ($RIVAL_TYPE_RANK{ $rg->{type} // '' } // 0),
            date => (length $rg->{date} ? $rg->{date} : '9999'),
        };
    }

    for my $k (keys %by) {
        @{ $by{$k} } = sort {
               $a->{comp} <=> $b->{comp}
            || $a->{rank} <=> $b->{rank}
            || $a->{date} cmp $b->{date}
            || $a->{mbid} cmp $b->{mbid}
        } @{ $by{$k} };
    }
    return \%by;
}

# { rg-mbid => 1 } for the groups a local copy's MusicBrainz id may place it in
# (Sources::_idGroup): every group except the hidden Remix/DJ-mix ones — the
# same pool claimedLocalIds claims across, so a tile and "Also in your library"
# never disagree about where an id-tagged copy belongs.
sub _idGroups {
    my ($rgs) = @_;
    my %g;
    for my $rg (@{ $rgs || [] }) {
        next unless $rg->{mbid};
        next if grep { $HIDE_SECONDARY{$_} } @{ $rg->{secondary} || [] };
        $g{ $rg->{mbid} } = 1;
    }
    return \%g;
}

# The owned albums' MusicBrainz ids that the bootleg check did not place, each
# once: neither a group on the page (a GROUP id in the tag places the copy
# directly, Sources::_idGroup) nor a release the check mapped ($known, from
# API::peekReleaseMap). Stage 2 looks up only these, after the render
# (API::warmLocalReleases), for the next visit. $known undef means the check
# failed, and then every owned id goes.
sub _unplacedReleases {
    my ($local, $rgs, $known) = @_;
    my %onPage = map { $_->{mbid} => 1 } grep { $_->{mbid} } @{ $rgs || [] };
    my %seen;
    return [ grep { !$onPage{$_} && !($known && $known->{$_}) && !$seen{$_}++ }
             grep { $_ } map { $_->{_mbid} } @{ $local || [] } ];
}

# Which EDITION titles each release group may match by (review 2026-09-19).
# MusicBrainz names a group after its first edition; later editions can be
# sold under another name (Kraftwerk's 2003 "Tour de France Soundtracks" group
# holds the 2009 "Tour de France" Simon owns). Returns
# { rg-mbid => [ [norm, raw, albumOnly], ... ] } for API::peekEditions' titles.
#
# The alias rule (API::getReleaseGroups) applies: an edition title that is
# ANOTHER group's real title is dropped — the B-52's box holds an edition
# titled like the debut album. ONE exception, safe only because of the size
# gate in Sources::matchesFor: when every group it clashes with is a plain
# (visible) SINGLE, the title is kept for a non-single group but marked
# album-only, so only an album-sized copy may use it. A clash with a hidden
# Remix group drops it (that group's releases must not route here).
sub _editionTitles {
    my ($rgs, $edMap) = @_;
    return {} unless $edMap && ref $edMap eq 'HASH';

    my %owners;
    push @{ $owners{ Plugins::Discography::Sources::_norm($_->{title}) } }, $_ for @$rgs;

    my %out;
    for my $rg (@$rgs) {
        my $titles = $edMap->{ $rg->{mbid} } or next;
        my %seen = map { $_ => 1 } grep { length }
                   map { Plugins::Discography::Sources::_norm($_) }
                   grep { defined } ($rg->{title}, @{ $rg->{aliases} || [] });
        for my $raw (@$titles) {
            my $n = Plugins::Discography::Sources::_norm($raw);
            next if $n eq '' || $seen{$n}++;
            my @others = grep { $_->{mbid} ne $rg->{mbid} } @{ $owners{$n} || [] };
            if (!@others) {
                push @{ $out{ $rg->{mbid} } }, [ $n, $raw, 0 ];
            }
            elsif (($rg->{type} // '') ne 'Single'
                   && !grep { ($_->{type} // '') ne 'Single'
                              || grep { $HIDE_SECONDARY{$_} } @{ $_->{secondary} || [] } } @others) {
                push @{ $out{ $rg->{mbid} } }, [ $n, $raw, 1 ];
            }
        }
    }

    # AND THE SAME RULE BETWEEN EDITIONS (review 2026-09-20). The test above
    # is against every group's CANONICAL title only, so where two groups each
    # sell an edition under a name no group is titled, both kept the key and
    # `_rivalsByTitle` — which arbitrates by OWNER, and here there are two —
    # had nothing to separate them: one owned copy rendered as Local under
    # both tiles. Measured over 1,043 library artists on the mirror: 13 such
    # clashes on 12 artists (MusicBrainz files "Every Breath You Take: The
    # Singles" under BOTH the Police's "Every Breath You Take" and their
    # "Greatest Hits"; ELO, Kraftwerk, Count Basie, New Order likewise).
    # Nothing can say which tile owns it, so NEITHER may claim it: the copy
    # falls back to its other routes (its own title, its MusicBrainz id) and
    # otherwise to "Also in your library", which is the honest answer.
    my %claims;
    for my $g (keys %out) { $claims{ $_->[0] }{$g} = 1 for @{ $out{$g} } }
    for my $g (keys %out) {
        my @keep = grep { keys %{ $claims{ $_->[0] } } == 1 } @{ $out{$g} };
        @keep ? ($out{$g} = \@keep) : delete $out{$g};
    }
    return \%out;
}

sub _shownTypes {
    my %show = map { uc($_) => 1 } split /\s*,\s*/, ($prefs->get('show_types') // '');
    return \%show;
}

# True when the client advertises the "header" item type ('h' in features) —
# LBF's convention. Material sends features:hi on drill commands itself; the
# custom-action entry carries it because we put it in the action's params.
sub _wantHeaders {
    my ($features) = @_;
    return (defined $features && $features =~ /h/) ? 1 : 0;
}

# Which header type to emit for a header-capable client (LBF's port):
# 'header-basic' (Material >= 6.4.3) is a non-actionable full-width divider;
# older Material only has 'header', which is drawn bold BUT gets a forced
# drill action — so header items always carry a url to their own section.
my $_headerTypeCache;
sub _headerType {
    return $_headerTypeCache if defined $_headerTypeCache;
    my $ver = eval { Plugins::MaterialSkin::Plugin->getPluginVersion() };
    my $useBasic;
    if (!defined $ver) {
        $useBasic = 0;
    } elsif ($ver =~ /^(\d+)\.(\d+)\.(\d+)/) {
        $useBasic = ( $1 <=> 6 || $2 <=> 4 || $3 <=> 3 ) >= 0 ? 1 : 0;
    } else {
        $useBasic = 1;   # dev/test build -> assume new type
    }
    return $_headerTypeCache = $useBasic ? 'header-basic' : 'header';
}

# The installed Material is at least the version given: four parts compared as
# numbers (6.4.9 < 6.4.11, 6.10.0 > 6.4.x), a missing fourth part counting as
# 0, so a release 6.4.11 sits above Simon's self-built 6.4.10.x test builds. A
# non-numeric version (a git checkout says DEVELOPMENT) or no Material is never
# new enough.
sub _materialAtLeast {
    my @want = @_;
    my $ver  = eval { Plugins::MaterialSkin::Plugin->getPluginVersion() } // '';
    my @have = $ver =~ /^(\d+)\.(\d+)\.(\d+)(?:\.(\d+))?/ or return 0;
    $have[3] //= 0;
    for my $i (0 .. 3) {
        my $c = $have[$i] <=> ($want[$i] // 0);
        return $c > 0 ? 1 : 0 if $c;
    }
    return 1;
}

# Tile strips: a 'header-strip' header makes Material draw the tiles after it
# as one sideways-scrolling row, the way its own search results look, so the
# bio and link rows can share the page with tiles. Material 6.4.11 is the first
# release that understands the type (the 'plugin-tile-strips' PR, #1270, merged
# 2026-09-27; upstream ChangeLog 6.4.11 item 5). Before it, only Simon's
# self-built test builds did, 6.4.10.1 and up. 6.4.10 itself, anything older,
# a non-numeric version or no Material at all gets exactly the old list.
# 30 tiles, the most Material ever shows in a strip: it caps each strip by
# screen width with numScrollItems (10 to 30, the way its search and home rows
# do; Craig on the PR, 2026-09-24), so a phone shows 10 and a 1920px desktop
# about 15. Sending more would be dropped. The header's More opens every tile.
use constant STRIP_SIZE => 30;
my $_stripsCache;
sub _useStrips { $_stripsCache //= _materialAtLeast(6, 4, 10, 1) }

# ARTIST ROWS (0.56.29): a row of type 'artist-link' is an artist to Material
# (Simon's PR #1276, merged 2026-10-02): a round image, and Material's artist
# header (photo and name) on the page it opens. Search results, MusicBrainz
# same-name rows, Also a member of and Similar artists send it. First in
# Simon's test build 6.4.10.9 (upstream master b652e87b1); expected in the
# 6.4.11 release beside the strips, though not yet in its ChangeLog. A Material
# without it shows the row exactly like a 'link' (no Material code reads that
# type), but it is gated like header-strip all the same: that Material AND a
# client that draws headers, so Default/Classic, the CLI and old controllers
# keep 'link'. NOT 'artist': Material offers Play on an 'artist' row whose go
# action carries `artist` or an id (hasPlayableId), which every one of ours does.
my $_artistLinksCache;
sub _useArtistLinks { $_artistLinksCache //= _materialAtLeast(6, 4, 10, 9) }

sub _artistRowType {
    my ($features) = @_;
    return (_wantHeaders($features) && _useArtistLinks()) ? 'artist-link' : 'link';
}

# Each section's layout is the user's choice (Settings, 0.54.0): Singles follow
# `layout_singles`, every other section (release types, library, appearances,
# streaming) follows `layout_albums`. 'tiles' or 'list'; the defaults give the
# mix Simon settled on — tile strips, with Singles a list the way Material's
# search keeps tracks as rows under its strips (2026-09-24).
sub _layoutOf {
    my ($key) = @_;
    return ($key // '') eq 'SINGLES'
        ? ($prefs->get('layout_singles') // 'list')
        : ($prefs->get('layout_albums')  // 'tiles');
}

# Strips need BOTH a patched Material on the server AND a client that draws
# headers ($useH): the header's More is the only way to the tiles past
# STRIP_SIZE, and a client without features:h gets a text divider with no url.
# $useH rides every row's params (and the walk stash), so a client's tree shape
# is the same on every re-walk.
sub _stripsOn { $_[0] && _useStrips() }

sub _stripSection { my ($useH, $key) = @_; _stripsOn($useH) && _layoutOf($key) ne 'list' }

# The release-type sections in display order. Singles as a list under tile
# strips follow every other release type rather than sitting between two strips
# (Simon, 2026-09-24). Every other mix (all list, all tiles, list albums over
# tile singles) keeps the type order unchanged.
sub _groupOrder {
    my ($useH) = @_;
    return @GROUP_ORDER unless _stripSection($useH, 'ALBUMS') && !_stripSection($useH, 'SINGLES');
    return ((grep { $_->[0] ne 'SINGLES' } @GROUP_ORDER), (grep { $_->[0] eq 'SINGLES' } @GROUP_ORDER));
}

sub _sectionHeaderType { _stripSection(@_) ? 'header-strip' : _headerType() }

# A release section's rows: (visible tiles, paging rows, every tile). In strip
# mode the strip shows the first STRIP_SIZE tiles with no paging rows (they
# would be drawn as tiles), and the header's More opens every tile.
sub _sectionTiles {
    my ($client, $opts, $useH, $key, $tiles) = @_;
    if (_stripSection($useH, $key)) {
        my $n = @$tiles < STRIP_SIZE ? scalar @$tiles : STRIP_SIZE;
        return ([ @$tiles[0 .. $n - 1] ], [], $tiles);
    }
    my ($vis, $pgRows) = _pageSection($client, $opts, $key, $tiles);
    return ($vis, $pgRows, [ @$vis, @$pgRows ]);
}

sub _dbg { Plugins::Discography::Plugin::dbg(@_) }

# Prose rows: Material's text-row CSS is padding:0 (flush to the viewport
# edge), while icon/thumbnail rows start at the avatar column — ragged. Text
# rows render via v-html, so the indent lives INSIDE the content: escaped text
# wrapped in a margin-left div aligned to the avatar column (72px = Material's
# list avatar slot). Images on text rows are NOT an option (0.7.2: text+image
# mutates to a clamped one-line row).
use constant PROSE_INDENT => '72px';

sub _escHtml {
    my $s = shift // '';
    $s =~ s/&/&amp;/g; $s =~ s/</&lt;/g; $s =~ s/>/&gt;/g;
    return $s;
}

sub _proseRow {
    my ($text, $extraStyle) = @_;
    return {
        name => "<div style='margin-left:" . PROSE_INDENT . ($extraStyle // '') . "'>"
              . _escHtml($text) . '</div>',
        type => 'text',
    };
}

# ---------------------------------------------------------------------------
# BIO / REVIEW PROSE — PORTED FROM LBF (ListenBrainzFreshReleases, 1.0.x).
#
# `_cleanBio` (LBF API.pm) and `_bioHardWrapped` / `_bioLooksLikeHeading` /
# `_bioBullet` / `_bioBlocks` / `_bioParagraphs` / `_proseBlock` (LBF Browse.pm)
# are copied with their LBF NAMES KEPT, so a fix on either side can be found
# with one grep across the two repos. LBF's ledger holds the history behind each
# rule (0.9.150-0.9.157, 1.0.13); the comments below keep the reasons that bite.
# They run for the MAI album review and the Qobuz description too, not just the
# bio — the "bio" in the names is LBF's.
#
# MEASURED on the live server before porting (2026-09-24): MAI hands BOTH the
# biography and the albumreview over as Wikipedia HTML — `<link>` stylesheet,
# <p>, <h2>/<h3>, <ul><li>, inline <a>, and a trailing "More online sources"
# <h4> over a list of links. The old `_stripHtml` kept none of that: every
# section title was glued to the paragraph after it ("Description and
# historyInitially formed ...") and the link list ended the text as one run
# ("(Source: Wikipedia)More online sourcesAllMusicAppleBandcamp...").
#
# DIVERGENCES FROM LBF, each deliberate:
#   * PROSE_MAX is 100000, not LBF's BIO_MAX 20000. LBF only ever sees bios;
#     a review is far longer — OK Computer's is 39,776 chars cleaned, which
#     LBF's cap would have cut in half. Still a DoS guard, never a visible trim.
#   * `_cleanBio` also maps U+2028/U+2029 to newlines (the old `_stripHtml` did,
#     and Qobuz descriptions are not HTML-only).
#   * `_proseBlock` makes a DUPLICATE row name unique (see there); it carries no
#     `_lbfProse` tag, because Discography has no web-skin pass to read one.
#   * The collapse threshold is REVIEW_SUMMARY_CHARS (380), Discography's own,
#     not LBF's BIO_PREVIEW (150). PROSE_REGROUP_MIN keeps LBF's 150 for the
#     one-long-chunk regroup rule, which is a different decision.
# ---------------------------------------------------------------------------
use constant PROSE_MAX         => 100000;  # pure DoS guard; never trims a real text
use constant PROSE_REGROUP_MIN => 150;     # LBF BIO_PREVIEW, in its _bioParagraphs role
use constant PROSE_BULLET_IND  => '1.2em'; # hanging indent for a wrapped bullet

# HTML -> plain text that KEEPS the structure `_bioBlocks` parses: a heading
# becomes a setext block ("title\n----------"), a list item a "* " bullet, a
# block element a blank line. Entities are DECODED, so the text must be escaped
# again wherever it is put into markup (`_proseRow` / `_proseBlock` do).
sub _cleanBio {
    my ($s) = @_;
    return '' unless defined $s && length $s;
    # LINKS: DELETE ONLY WHERE THE LINK IS THE WHOLE POINT, UNWRAP EVERYWHERE ELSE.
    # Wikipedia HTML is full of INLINE links inside sentences; a blanket delete
    # removes words mid-sentence. Order matters:
    #   1. a list item that is NOTHING BUT a link is a link list (MAI's "More
    #      online sources"), so the item goes — the heading left trailing over
    #      nothing is then dropped by _bioParagraphs;
    #   2. Last.fm's trailing link goes, matched on its own text;
    #   3. anything still standing is an inline link. Unwrap it.
    # [^<]* IS LOAD-BEARING (not `.*?`): a lazy match still grows, crossed
    # </li><li> under /s and deleted every item between two links (LBF 0.9.160).
    $s =~ s{<li\b[^>]*>\s*<a\b[^>]*>[^<]*</a>\s*</li>}{}gis;
    $s =~ s{<a\b[^>]*>\s*Read more on Last\.fm\s*</a>}{}gis;
    $s =~ s{<a\b[^>]*>(.*?)</a>}{$1}gis;
    # Any element the removals above emptied would otherwise become a bare bullet
    # or a blank paragraph.
    $s =~ s{<(li|p)[^>]*>\s*</\1>}{}gis;
    $s =~ s/\s*\.?\s*User-contributed text is available.*$//is;  # Last.fm CC boilerplate
    # STRUCTURE FIRST, TAGS SECOND: a heading becomes a SETEXT block, the shape
    # _bioBlocks already detects in plain-text sources.
    $s =~ s{<h[1-6][^>]*>\s*(.*?)\s*</h[1-6]>}{"\n\n$1\n" . ('-' x 10) . "\n\n"}gise;
    # \b IS LOAD-BEARING: without it `<li[^>]*>` also matches the `<link rel=…>`
    # stylesheet MAI prepends, turning it into a stray bullet.
    $s =~ s{<li\b[^>]*>}{\n* }gis;     # list items -> the bullet _bioBullet knows
    $s =~ s{</(?:p|div|ul|ol|li|tr|blockquote|section)>}{\n\n}gis;
    $s =~ s{<br\s*/?>}{\n}gis;
    # Remaining tags are INLINE (<b>, <i>, <span>, <link>), so they vanish rather
    # than becoming a space ("Lambchop , originally Posterchild ,").
    $s =~ s/<[^>]+>//g;
    $s =~ s/&amp;/&/gi;
    $s =~ s/&lt;/</gi;
    $s =~ s/&gt;/>/gi;
    $s =~ s/&quot;/"/gi;
    $s =~ s/&#0?39;|&apos;/'/gi;
    $s =~ s/&[a-z]+;/ /gi;             # any remaining named entity (&nbsp; ...)
    $s =~ s/\x{2028}|\x{2029}/\n/g;    # Discography-only: see the header
    $s =~ s/[ \t]+/ /g;                # collapse spaces/tabs, but keep newlines
    $s =~ s/ *\n */\n/g;
    $s =~ s/^[*\x{2022}]\s*$//gm;      # a marker whose item emptied above
    $s =~ s/\n{3,}/\n\n/g;             # at most one blank line between paragraphs
    $s =~ s/^\s+|\s+$//g;
    if (length $s > PROSE_MAX) {
        $s = substr($s, 0, PROSE_MAX);
        $s =~ s/\s+\S*$//;             # back off to a word boundary
        $s .= "\x{2026}";
    }
    return $s;
}

# One styled text row per block — LBF's `_proseBlock`, on Discography's own
# 72px avatar-column indent (which LBF originally copied from here).
#
# ONE ROW PER BLOCK, NOT ONE WRAPPER ROW. LBF tried a single row with its own
# typography (0.9.154) and it did not render as intended on every client; this
# shape demonstrably does, on desktop and iOS. The row-count hazard (Material's
# 100-item fixed-height scroller draws a tall row over the next) is governed by
# PARSING, not by the shape: measured 2026-09-24, OK Computer's review is 73
# blocks (56 rows under the old split — the extra 17 are its headings, which
# used to be glued into paragraphs), Lambchop's bio 13, Nixon's review 12.
#
# HEADINGS USE AN EXPLICIT WEIGHT, NEVER A BARE <b>: Material's row title is
# `font-weight:200 !important`, and `bolder` from 200 lands on 400 — identical
# to the body on a desktop font stack without a 200 face (LBF 0.9.155).
#
# DUPLICATE NAMES ARE MADE UNIQUE. On the My Apps path Material keys a
# NON-playable row by `parent.id + "." + title` and renders `:key="item.id"`,
# so two identical rows on one level show as ONE (Discography 0.51.1, the
# Zappa "Mothers of Invention" row). A review can repeat a sub-heading
# ("Personnel" under two sections). An HTML comment changes the title and
# renders as nothing.
sub _proseBlock {
    my (@paras) = @_;
    return () unless @paras;

    my (@rows, %seen);
    for my $p (map { ref $_ ? $_ : { text => $_, heading => 0, bullet => 0 } } @paras) {
        my $text  = _escHtml($p->{text});
        my $style = 'margin-left:' . PROSE_INDENT;

        if ($p->{heading}) {
            $style .= ';font-weight:bold';
        }
        elsif ($p->{bullet}) {
            $style .= ';padding-left:' . PROSE_BULLET_IND
                    . ';text-indent:-'  . PROSE_BULLET_IND;
            $text   = "\x{2022}\x{00A0}$text";
        }
        my $name = "<div style='$style'>$text</div>";
        my $dup  = $seen{$name}++;              # 0 on first sight, then 1, 2, ...
        $name   .= "<!--$dup-->" if $dup;
        push @rows, { name => $name, type => 'text' };
    }
    return @rows;
}

# Is this text HARD-WRAPPED at a fixed column, rather than carrying deliberate
# line breaks? A plain-text render (MAI's non-HTML output) wraps at ~72 columns
# with setext headings; prose sources never column-wrap, so a lone "\n" there IS
# a break. TWO signals, BOTH required — no line past BIO_WRAP_MAX_COL, and more
# than half the non-final lines ending mid-sentence — plus a floor of
# BIO_WRAP_MIN_LINES.
#
# A FALSE POSITIVE IS NOT HARMLESS: it joins lines AND lets _bioLooksLikeHeading
# promote any short unpunctuated line to a bold heading. (This comment used to
# say "one joined paragraph, never a broken render" — review 2026-09-24 showed
# otherwise.)
#
# SETEXT HEADINGS ARE STRUCTURE, NOT PROSE, so a setext underline and the title
# it underlines are left out of the count. Counted, they are exactly the lines
# the test reads as wrapping: short, unpunctuated. A one-paragraph Wikipedia
# stub from MAI cleans to four lines — the sentence, "(Source: Wikipedia)",
# "More online sources" and its dashes — which cleared the floor and the
# mid-sentence test, and "(Source: Wikipedia)" rendered as a bold heading.
# The underline itself is still consumed by _bioBlocks whatever this returns.
use constant BIO_WRAP_MAX_COL   => 100;
use constant BIO_WRAP_MIN_LINES => 4;
sub _bioHardWrapped {
    my ($lines) = @_;
    my $rule = qr/^[-=_~*]{3,}$/;      # the same underline test as _bioBlocks
    my @l = grep { length }
            map  { ($lines->[$_] =~ $rule
                    || ($_ < $#$lines && $lines->[$_ + 1] =~ $rule)) ? () : $lines->[$_] }
            0 .. $#$lines;
    return 0 if @l < BIO_WRAP_MIN_LINES;

    my $mid = 0;
    for my $i (0 .. $#l) {
        return 0 if length($l[$i]) > BIO_WRAP_MAX_COL;
        $mid++ if $i < $#l && $l[$i] !~ /[.!?:;\x{2026}]$/;
    }
    return $mid * 2 > $#l ? 1 : 0;
}

# A section heading that carries NO underline: ONE source line, well short of
# the wrap column, not ending on sentence punctuation (':' allowed —
# "Discography:" is a heading). ONLY SOUND ON A HARD-WRAPPED SOURCE, which is
# why _bioBlocks gates it on that; bullets are excluded by the caller.
use constant BIO_HEADING_MAX_COL => 80;

# How many CONSECUTIVE bare-line headings mean "this is a list, not a stack of
# section titles" — see _bioParagraphs.
use constant BIO_HEADING_RUN_MAX => 3;
sub _bioLooksLikeHeading {
    my ($lines) = @_;
    return 0 unless @$lines == 1;
    return 0 if length($lines->[0]) > BIO_HEADING_MAX_COL;
    return $lines->[0] =~ /[.!?;,]$/ ? 0 : 1;
}

# A LIST ITEM: "*", a real bullet, a middot, a dash or an en dash, followed by
# REQUIRED whitespace (so a hyphenated word cannot open a list). Returns
# ($marker, $text) so _bioBlocks can demand a neighbour for a dash — a hard wrap
# can push a dashed parenthetical to column 0, which is not a list.
sub _bioBullet {
    my ($line) = @_;
    return unless $line =~ /^([*\x{2022}\x{00B7}\-\x{2013}])\s+(\S.*)$/;
    return ($1, $2);
}

# THE ONE STRUCTURE PARSER. Returns { text, heading, bullet, setext } per block.
#
# $wrapped (from _bioHardWrapped) changes exactly two things, and NOTHING else
# may be made conditional on it: how a lone newline is read (a wrap artefact to
# rejoin, or a real break), and whether a bare short line may be promoted to a
# heading. A SETEXT UNDERLINE IS UNAMBIGUOUS IN ANY SOURCE — always consumed,
# and it may reach BACKWARDS to the block already pushed (LBF 0.9.153).
sub _bioBlocks {
    my ($bio, $wrapped) = @_;

    my @lines = split /\n/, ($bio // ''), -1;
    s/^\s+|\s+$//g for @lines;

    # CORROBORATION PRE-PASS: "*", a bullet and a middot open a list on their
    # own; a dash only when a neighbouring non-blank line is marked too.
    # `my ($mk) = ...`, NOT `(_bioBullet($_))[0]`: a slice of an empty list is
    # an empty list, and every index after an unmarked line would shift.
    my @marker = map { my ($mk) = _bioBullet($_); $mk } @lines;
    my @isBullet;
    for my $i (0 .. $#lines) {
        next unless defined $marker[$i];
        if ($marker[$i] =~ /^[*\x{2022}\x{00B7}]$/) { $isBullet[$i] = 1; next }
        for my $j (grep { $_ >= 0 && $_ <= $#lines } ($i - 1, $i + 1)) {
            next unless length $lines[$j];
            $isBullet[$i] = 1 if defined $marker[$j];
        }
    }

    my (@out, @cur, $bullet);
    my $flush = sub {
        my ($underlined) = @_;
        if (!@cur) {
            # An underline with nothing pending marks the block it followed.
            if ($underlined && @out && !$out[-1]{bullet}) {
                $out[-1]{heading} = 1;
                $out[-1]{setext}  = 1;
            }
            return;
        }
        my $text = join(' ', @cur);
        $text =~ s/\s+/ /g;
        $text =~ s/^\s+|\s+$//g;
        # `setext` records WHY a block is a heading: the source's own mark, as
        # opposed to the bare-line inference. _bioParagraphs acts on the difference.
        push @out, {
            text    => $text,
            bullet  => $bullet ? 1 : 0,
            setext  => (!$bullet && $underlined) ? 1 : 0,
            heading => (!$bullet
                        && ($underlined || ($wrapped && _bioLooksLikeHeading(\@cur))))
                       ? 1 : 0,
        } if length $text;
        @cur    = ();
        $bullet = 0;
    };
    for my $i (0 .. $#lines) {
        my $line = $lines[$i];
        if ($line =~ /^[-=_~*]{3,}$/) { $flush->(1); next }
        if (!length $line)            { $flush->(0); next }

        if ($isBullet[$i]) {
            $flush->(0);          # a marker always opens a new block
            $bullet = 1;
            (undef, $line) = _bioBullet($line);
        }
        push @cur, $line;
        # Unwrapped: the newline that ends this line is the author's, so close.
        # Wrapped: it is the renderer's, so the next line joins on.
        $flush->(0) unless $wrapped;
    }
    $flush->(0);
    return @out;
}

# Split cleaned text into display blocks: structure from _bioBlocks (NEVER gated
# on the wrap test), then three corrections — a run of bare-line "headings" is a
# list, a document of nothing but inferred headings was misread, and a trailing
# SETEXT heading with nothing under it goes (MAI's "More online sources"). If
# all that yields ONE long chunk, sentences are regrouped — presentation only.
use constant BIO_SENTENCES_PER_PARA => 3;
sub _bioParagraphs {
    my ($bio) = @_;
    $bio //= '';

    my @lines = map { my $t = $_; $t =~ s/^\s+|\s+$//g; $t } split /\n/, $bio, -1;
    my @paras = _bioBlocks($bio, _bioHardWrapped(\@lines));

    # A RUN OF CONSECUTIVE BARE-LINE HEADINGS IS A LIST. A setext heading is the
    # source's own mark and is never second-guessed; only inferences are demoted.
    my $i = 0;
    while ($i < @paras) {
        if ($paras[$i]{heading} && !$paras[$i]{setext}) {
            my $j = $i;
            $j++ while $j < @paras && $paras[$j]{heading} && !$paras[$j]{setext};
            $paras[$_]{heading} = 0 for ($j - $i >= BIO_HEADING_RUN_MAX) ? ($i .. $j - 1) : ();
            $i = $j;
        }
        else { $i++ }
    }

    # NOTHING BUT (inferred) HEADINGS = misread; demote. Each grep bound to its
    # own scalar — `grep BLOCK LIST` slurps what follows it.
    my $bodyCount   = scalar grep { !$_->{heading} } @paras;
    my $setextCount = scalar grep {  $_->{setext}  } @paras;
    if (@paras && !$bodyCount && !$setextCount) {
        $_->{heading} = 0 for @paras;
        $bodyCount = scalar @paras;
    }

    # A heading with nothing under it is not a section. TWO FLOORS: only while
    # some body remains (else Read more would open an empty section), and only a
    # SETEXT heading (deleting on an inference is what lost LBF's discography).
    pop @paras while $bodyCount && @paras && $paras[-1]{heading} && $paras[-1]{setext};

    return @paras if @paras != 1
                  || $paras[0]{heading}
                  || $paras[0]{bullet}
                  || length $paras[0]{text} <= PROSE_REGROUP_MIN;

    # Break after . ! ? when the next sentence opens like one (capital or an
    # opening quote); a stray split only shifts a boundary.
    my @sent = split /(?<=[.!?])\s+(?=["'\x{201C}\x{2018}(]?[A-Z\x{00C0}-\x{00DE}])/, $paras[0]{text};
    return @paras if @sent < 2;

    my @out;
    while (@sent) {
        my @chunk = splice(@sent, 0, BIO_SENTENCES_PER_PARA);
        push @out, { text => join(' ', @chunk), heading => 0, bullet => 0, setext => 0 };
    }
    return @out;
}

# Does cleaned text carry anything worth a section? A MAI answer can be nothing
# but the "More online sources" link list: cleaned, that is one setext heading
# and no body, which _bioParagraphs keeps (its floor) and would render as a lone
# bold title. Treated as NO text at fetch time, so the review falls back to
# Qobuz and neither section is drawn over an empty body.
sub _proseHasBody {
    my ($text) = @_;
    return 0 unless defined $text && length $text;
    return scalar(grep { !$_->{heading} } _bioParagraphs($text)) ? 1 : 0;
}

# The rows for a bio or review, and whether it needs a Read more / Show less
# toggle. Shared by both sections so their shapes cannot drift apart.
#
#   * Whole text <= REVIEW_SUMMARY_CHARS: every block, inline, no toggle. A lone
#     plain paragraph is one `_proseRow` (no structure to style).
#   * Longer, expanded: every block (`_proseBlock`); caller adds Show less.
#   * Longer, collapsed: ONE summary row; caller adds Read more.
#
# THE SUMMARY IS BUILT FROM THE PARSED BODY BLOCKS, NOT THE RAW TEXT. The raw
# text carries setext underlines ("title\n----------") that collapsing
# whitespace would leave in the summary as literal hyphens (LBF 1.0.x). BRANCH
# SELECTION still measures the WHOLE text: measuring the body alone would send a
# long text that is mostly headings down the inline branch.
sub _proseSection {
    my ($text, $expanded) = @_;
    my @paras = _bioParagraphs($text);
    return ([], 0) unless @paras;

    my $whole = join(' ', map { $_->{text} } @paras);
    if (length $whole <= REVIEW_SUMMARY_CHARS) {
        return ([ (@paras == 1 && !$paras[0]{heading} && !$paras[0]{bullet})
                    ? _proseRow($paras[0]{text})
                    : _proseBlock(@paras) ], 0);
    }
    return ([ _proseBlock(@paras) ], 1) if $expanded;

    my $body = join(' ', map { $_->{text} } grep { !$_->{heading} } @paras);
    my ($summary, $cut) = _reviewSummary(length $body ? $body : $whole);
    # This branch means more follows even when the body alone fit.
    $summary .= " \x{2026}" unless $cut;
    return ([ _proseRow($summary) ], 1);
}

# A section-header divider (walk-stable: emitted whenever its rows exist, only
# the type differs per client). Older Material forces a drill action on
# 'header' items, so it points at its own child rows.
sub _sectionHeader {
    my ($client, $token, $useH, $image, $kids, $act) = @_;
    my $hdr = {
        name  => cstring($client, $token),
        type  => $useH ? _headerType() : 'text',
        ($image ? (image => $image) : ()),
    };
    if ($useH) {
        my @k = @{ $kids || [] };
        $hdr->{url}         = sub { $_[1]->({ items => \@k }) };
        $hdr->{passthrough} = [{}];
        # Self-identifying drill (stale-view fix): older Material forces a go
        # action onto headers; give it explicit params so it lands on this
        # section's rows regardless of server state.
        if ($act && $act->{id}) {
            $hdr->{id}          = $act->{id};
            $hdr->{itemActions} = $act->{itemActions};
        }
    }
    return $hdr;
}

# Material substitutes $VARS in the custom action's params from the tapped
# item; a $VAR the item doesn't carry arrives as the literal token. Treat those
# (and empties) as absent.
sub _cleanParam {
    my ($v) = @_;
    return undef unless defined $v && length $v;
    return undef if $v =~ /^\$/;
    return $v;
}

# XMLBrowser drill-ins re-run the TOP feed with only item_id:<path> — the
# lmsbrowse entry params (artist_id/artist) are NOT echoed back by Material,
# and with cachetime=>0 there is no server-side session tree either (verified
# live: the drill request carried just item_id + menu, and the paramless
# re-run served the Apps-hint page, so every click landed on a dead text row).
# Fix: stash the entry context per player; a paramless WALK call (item_id
# present) rebuilds the same view (deterministic order, data served from the
# API cache) so the item_id walk resolves. A paramless call WITHOUT item_id is
# the app root and renders the root (search/hint) view instead — restoring the
# stash there trapped the app on the last artist (0.37.2). Known limit: one
# artist per player at a time — jumping back to an older artist's still-open
# view after opening another artist's walks the newer tree.
my %lastCtx;
sub _cid { my ($client) = @_; return $client ? $client->id : '_none' }

sub topLevel {
    my ($client, $callback, $args) = @_;

    # Somebody is looking: the archive cover fetch (Covers.pm) waits, then runs
    # at its browsing width (0.56.27).
    Plugins::Discography::Covers::noteBrowse();

    my $params   = ref $args->{params} eq 'HASH' ? $args->{params} : {};
    my $artistId = _cleanParam($params->{artist_id});
    my $artist   = _cleanParam($params->{artist});
    # A KNOWN MusicBrainz artist mbid — set by an "Also a member of" band link
    # (via its %lastCtx re-stash) to enter that band's discography directly,
    # skipping name/tag resolution. Absent on the normal artist entry.
    my $mbid     = _cleanParam($params->{mbid});
    # Param-addressed navigation (the stale-view fix): rg = a release-group
    # mbid -> render that release's DETAIL directly; item = a row id — WITH rg
    # a row of that detail view, WITHOUT rg a row of the artist LIST view
    # (toggles/paging/headers/extras). sort = an explicit list order (the sort
    # toggle's fresh-entry param; also re-issued by refresh toggles inside a
    # sorted view, so the order sticks). All arrive from itemActions'
    # fixedParams (always alongside the artist identity), never positional.
    my $rgParam   = _cleanParam($params->{rg});
    my $itemParam = _cleanParam($params->{item});
    my $sortParam = _cleanParam($params->{sort});
    $sortParam = undef unless ($sortParam // '') =~ /^(?:newest|oldest)$/;
    # local_only = show ONLY releases the user owns (the Options view toggle).
    # A view-state param, threaded like sort: NOT stashed in ctx, it rides the
    # rows' own itemActions (Material, param-addressed), so a legacy positional
    # walk in a filtered view has the same best-effort limitation sort has.
    my $localOnlyParam = (_cleanParam($params->{local_only}) // '') eq '1' ? 1 : 0;

    # Param-addressed search submission (the search row's overridden go
    # action: search:<text> + features, NO item_id — see _searchRow). Rendered
    # directly, BEFORE any ctx stash/restore: the results view must be immune
    # to whatever artist is stashed, and the request carries no artist
    # identity to stash anyway. Raw param (not _cleanParam — typed text may
    # legitimately start with '$'); _artistSearchView trims/guards it.
    #
    # GATED ON item_id BEING ABSENT (0.42.2). A POSITIONAL walk into the search
    # row sends item_id:<path> + search:<text> in the SAME request (the legacy
    # path _searchRow's url coderef exists for — Control/XMLBrowser.pm:493
    # hands the text to the row's coderef as $args->{search}). Without this
    # guard that request was intercepted here and the RESULTS were returned as
    # the TOP feed, whereupon XMLBrowser descended the item_id path into them
    # (_cliQuery_done splits item_id and indexes $feed->{items} positionally) —
    # so the walk landed on an arbitrary result row. Reproduced live: root-view
    # item_id:5 + search:"The Beatles" rendered "The Beatles Tribute Band"
    # (result index 5) instead of the result list. Material is unaffected
    # either way — its submitted go action carries only search + features +
    # menu, never item_id (verified live on the served item JSON).
    my $searchParam = $params->{search};
    my $walking     = defined $params->{item_id} && length $params->{item_id};
    if (defined $searchParam && !ref $searchParam && length $searchParam
        && !$walking) {
        my $features = $params->{features} // '';
        # `item:sect:ARTISTS` = the Artists heading's More on a tile row
        # (0.56.10): the same search, answered with that section's rows only.
        _artistSearchView($client, $callback, $features, $searchParam, $itemParam);
        return;
    }

    # artist_id is the reliable key (Material fills $ARTISTID from the item
    # id); the DB name beats the $TITLE fallback whenever we have it.
    if ($artistId) {
        my $contributor = eval { Slim::Schema->find('Contributor', $artistId) };
        $artist = $contributor->name if $contributor && $contributor->name;
    }

    # features comes on the entry (from the custom action) and on drills (from
    # Material's browseBuildCommand); stash it with the artist context so any
    # rebuild renders the SAME tree shape either way.
    my $features = $params->{features} // '';

    if ($artistId || $artist || $mbid) {
        # Fresh entry resets the ctx — EXCEPT the expand flags when it's the
        # SAME artist: the bio "Read more" toggle refreshes the TOP view, and
        # that re-fetch carries the artist params (= lands here), so wiping
        # everything would discard the very flag the toggle just set (0.8.0
        # bug: bio expansion never showed). `page` is the same class of state:
        # the section "Show more" rows refresh the TOP view too. The visibility
        # snapshot is still reset — the refreshed render is a complete,
        # consistent new tree. `view` (the Albums | Singles toggle) is the same
        # class again: its refresh re-issues the artist's own command.
        my $prev = $lastCtx{ _cid($client) };
        my $same = $prev
            && ($prev->{artist_id} // '') eq ($artistId // '')
            && ($prev->{artist}    // '') eq ($artist   // '')
            && ($prev->{mbid}      // '') eq ($mbid     // '');
        $lastCtx{ _cid($client) } = {
            artist_id => $artistId, artist => $artist, mbid => $mbid,
            features => $features,
            $same ? ( bio  => $prev->{bio}, rev => $prev->{rev},
                      ver  => $prev->{ver}, page => $prev->{page},
                      view => $prev->{view} ) : (),
        };
    }
    elsif ($walking && (my $ctx = $lastCtx{ _cid($client) })) {
        # Restore the stash ONLY for positional WALK requests (they always
        # carry item_id — cliQuery passes the full request params copy, so a
        # walk's item_id is visible here): a deeper click re-runs this feed
        # paramless and must rebuild the identical stashed view for its
        # item_id path to resolve. A paramless request WITHOUT item_id is a
        # genuine app-root entry (Apps menu / Material re-fetching the root)
        # and falls through to the root view below — before 0.37.2 it ALSO
        # restored the stash, so once any artist was browsed the app re-opened
        # stuck on that artist and the search/root view was unreachable
        # (Simon, field). Ctx itself is untouched — walks keep working.
        ($artistId, $artist, $mbid) = @$ctx{qw(artist_id artist mbid)};
        $features ||= $ctx->{features} // '';
        _dbg("topLevel: paramless walk re-entry, using stashed context");
    }

    _dbg("topLevel: artist_id=" . ($artistId // '-') . " artist=" . ($artist // '-')
        . " mbid=" . ($mbid // '-'));

    # No artist context: the app-root view (Apps menu) — search, about, and
    # a live plugin-status list, sectioned with the same header dividers as
    # the artist view.
    if (!$artistId && !$artist && !$mbid) {
        $callback->(_rootView($client, $features));
        return;
    }

    my $opts = {
        artist_id => $artistId,
        artist    => $artist,
        mbid      => $mbid,
        features  => $features,
        sort      => $sortParam || $prefs->get('sort_order') || 'newest',
        local_only => $localOnlyParam,
        force     => 0,
    };

    # Param-addressed release detail (rg carries its own artist identity, just
    # stashed above — so this view is durable across any navigation order,
    # restarts, other artists: nothing here depends on a positional walk).
    if ($rgParam && $rgParam =~ /^[0-9a-f-]{36}$/i) {
        _rgView($client, $callback, $opts, lc $rgParam, $itemParam);
        return;
    }

    # Param-addressed LIST-view row (no rg): rebuild the list privately and
    # invoke the named row's own coderef — toggles/paging/headers/extras reuse
    # their existing logic (the same collector pattern as _rgView).
    if (defined $itemParam && length $itemParam) {
        _listItemDispatch($client, $callback, $opts, $itemParam);
        return;
    }

    # A FRESH list render, not a positional walk: the one place MusicBrainz's
    # completed list may replace a first one (0.56.7, API::promoteCompleted). A
    # walk must rebuild the tree the client holds, item_id for item_id.
    $opts->{fresh} = $walking ? 0 : 1;
    _discographyView($client, $callback, $opts);
}

# Locate a feed row by its self-identifying id (topLevel's item: dispatch).
sub _findRow {
    my ($feed, $id) = @_;
    return undef unless ref $feed eq 'HASH';
    my ($row) = grep { defined $_->{id} && $_->{id} eq $id }
                @{ $feed->{items} || [] };
    return $row;
}

# Run a located row's OWN url coderef (toggles / version drills / header drills
# reuse their existing logic — zero duplication). A missing or urlless row ->
# empty response; the tapped action's nextWindow=>'refresh' then re-renders the
# view cleanly (unknown id = stale view from an older build / vanished section).
sub _runRow {
    my ($client, $callback, $row, $what) = @_;
    if ($row && ref $row->{url} eq 'CODE') {
        my $p = ref $row->{passthrough} eq 'ARRAY' ? $row->{passthrough}[0] : {};
        $row->{url}->($client, $callback, {}, $p);
    }
    else {
        _dbg("dispatch: $what not found");
        $callback->({ items => [], cachetime => 0 });
    }
}

# Find a list-view row by id and run it (see topLevel).
sub _listItemDispatch {
    my ($client, $callback, $opts, $item) = @_;
    _discographyView($client, sub {
        _runRow($client, $callback, _findRow(shift, $item), "list item '$item'");
    }, $opts);
}

# ---------------------------------------------------------------------------
# Param-addressed release detail (the stale-view fix). Entered by an rg: param
# carrying full artist identity — resolves the release group from the CACHED
# RG list (14d; the tile that emitted the param came from the same list) and
# renders _releaseDetail directly. With an item: param, the detail is rendered
# PRIVATELY and the matching row's own url coderef is invoked instead — so
# toggles/version rows reuse their existing logic with zero duplication.
# ---------------------------------------------------------------------------
sub _rgView {
    my ($client, $callback, $opts, $rgMbid, $item) = @_;

    my $err = sub {
        $callback->({ items => [{
            name => cstring($client, 'PLUGIN_DISCOGRAPHY_ERROR'), type => 'text',
        }], cachetime => 0 });
    };

    # The artist mbid is part of every rg action's fixedParams; without it we
    # can't fetch the RG list this release belongs to.
    my $ambid = $opts->{mbid};
    return $err->() unless $ambid && $ambid =~ /^[0-9a-f-]{36}$/i;

    Plugins::Discography::API->getReleaseGroups(
        mbid   => lc $ambid,
        onDone => sub {
            my $rgs = shift || [];
            my ($rel) = grep { ($_->{mbid} // '') eq $rgMbid } @$rgs;
            unless ($rel) {
                _dbg("rgView: rg $rgMbid not in the artist's RG list");
                return $err->();
            }
            my $pass = { %$opts, rg => $rel };
            if (defined $item && length $item) {
                _releaseDetail($client, sub {
                    _runRow($client, $callback, _findRow(shift, $item),
                            "detail item '$item'");
                }, $pass);
            }
            else {
                _releaseDetail($client, $callback, $pass);
            }
        },
        onError => $err,
    );
}

# ---------------------------------------------------------------------------
# CLI ["discography","playcmd"]: param-addressed play/add/insert for a release
# (tiles + detail rows point their play actions here — XMLBrowser's default
# play action is positional and breaks on a stale view). Resolves the target
# via the SAME cache-backed _releaseDetail build the page uses: with item: the
# named row's play url, else the detail's kept (preferred-source) play string.
# Async CLI command (candidates may need fetching on a cold cache).
# ---------------------------------------------------------------------------
sub playCommand {
    my $request = shift;
    my $client  = $request->client;

    my $rgMbid = lc($request->getParam('rg') // '');
    my $cmd    = $request->getParam('cmd') // 'play';
    my $item   = $request->getParam('item');
    $cmd = 'play' unless $cmd =~ /^(?:play|add|insert)$/;

    my %opts = map { $_ => scalar $request->getParam($_) }
               grep { defined $request->getParam($_) }
               qw(artist_id artist mbid features);
    my $ambid = lc($opts{mbid} // '');

    # Direct-url mode (library-extras tiles): the play target is already a
    # core-resolved db: url — no resolution step, whitelisted shape only. A
    # lib: tile carries a url but NO rg, so once a url is present this is the
    # only path it can take: play it if whitelisted, else refuse it explicitly
    # (never hand an arbitrary string to the player, and don't fall through to
    # the misleading "missing rg" branch — surface the real reason instead).
    my $direct = $request->getParam('url');
    if ($client && defined $direct && length $direct) {
        if ($direct =~ /^db:album\.id=\d+$/) {
            _dbg("playcmd: $cmd -> $direct (direct)");
            $client->execute(['playlist', $cmd, $direct]);
        }
        else {
            $log->warn("discography playcmd: rejected non-whitelisted url '$direct'");
        }
        $request->setStatusDone();
        return;
    }

    unless ($client && $rgMbid =~ /^[0-9a-f-]{36}$/ && $ambid =~ /^[0-9a-f-]{36}$/) {
        _dbg('playcmd: missing client/rg/artist-mbid');
        $request->setStatusDone();
        return;
    }

    $request->setStatusProcessing();
    my $done = sub {
        my ($url) = @_;
        if (defined $url && length $url) {
            _dbg("playcmd: $cmd -> $url");
            $client->execute(['playlist', $cmd, $url]);
        }
        else {
            _dbg("playcmd: no playable url resolved for rg $rgMbid");
        }
        $request->setStatusDone();
    };

    Plugins::Discography::API->getReleaseGroups(
        mbid   => $ambid,
        onDone => sub {
            my $rgs = shift || [];
            my ($rel) = grep { ($_->{mbid} // '') eq $rgMbid } @$rgs;
            return $done->(undef) unless $rel;
            _releaseDetail($client, sub {
                my $feed = shift || {};
                my $row;
                if (defined $item && length $item) {
                    $row = _findRow($feed, $item);
                }
                else {
                    # The kept preferred-source row is the one carrying a play
                    # string (same node tile-play collects).
                    ($row) = grep { defined $_->{play} } @{ $feed->{items} || [] };
                }
                $done->($row ? ($row->{play} // _playUrl($row)) : undef);
            }, { %opts, sort => $prefs->get('sort_order') || 'newest',
                 force => 0, rg => $rel });
        },
        onError => sub { $done->(undef) },
    );
}

# ---------------------------------------------------------------------------
# The discography list. $opts: artist_id, artist, sort ('newest'|'oldest'),
# force (bypass the release-group cache). Re-entered by the sort toggle and
# Refresh rows via passthrough.
# ---------------------------------------------------------------------------
sub _discographyView {
    my ($client, $callback, $opts) = @_;

    my $artist = $opts->{artist} // '';

    # The post-resolution body, run with whatever mbid we end up with.
    my $withMbid = sub {
            my $mbid = shift;

            unless ($mbid) {
                my @items = ({
                    name => cstring($client, 'PLUGIN_DISCOGRAPHY_NOT_FOUND') . ($artist ? ": $artist" : ''),
                    type => 'text',
                });
                # Retry row: clears the cached miss for this name and re-enters.
                # A "not found" is usually transient (a MB mirror still building
                # its search index returns 0 for everyone), and the short miss TTL
                # alone would still make the user wait — this busts it on demand.
                push @items, {
                    name        => cstring($client, 'PLUGIN_DISCOGRAPHY_RETRY_LOOKUP'),
                    type        => 'link',
                    image       => MENU_REFRESH,
                    nextWindow  => 'refresh',
                    url         => sub {
                        my ($c, $cb) = @_;
                        Plugins::Discography::API->clearArtistMbid($artist);
                        $cb->({ items => [] });
                    },
                } if length $artist;
                $callback->({ items => \@items, cachetime => 0 });
                return;
            }

            # MusicBrainz's completed list, when a first one was drawn last time
            # (0.56.7): on a fresh entry only, before anything reads the spine.
            Plugins::Discography::API->promoteCompleted($mbid) if $opts->{fresh};

            # Warm the streaming candidate caches. A COLD pool is awaited, up to a
            # deadline (the await block below, 0.56.26), so the first view
            # normally has playable, badged tiles; with the pool already cached
            # nothing waits. Client-gated: without a player context the service
            # handlers can't be created and would pollute the cache with empties.
            # SPINE-AWARE: with an ambiguous name a blind warm fetches the
            # WRONG act's catalogue and caches it (field, 0.43.0 — the rapper's
            # page matched against the ska band's 289 albums). So the warm is
            # deferred to the release-group callback, where the MB titles that
            # identify THIS artist are available. Unambiguous names warm
            # immediately, exactly as before.
            my $warm = sub {
                my ($spine, $done) = @_;
                $done ||= sub {};
                unless ($client && defined $artist && length $artist) {
                    return $done->();   # every path must settle $done
                }
                # The release page asks with the same options (_poolOpts).
                _poolOpts($artist, $mbid, $spine, sub {
                    Plugins::Discography::Sources->getCandidates(
                        $client, $artist, 0, sub { $done->() }, $_[0]);
                });
            };

            # Bio + release groups fetched in PARALLEL; render once when both
            # settle. $render assigned BEFORE the fetches (all-caches-warm runs
            # the chain synchronously — the 0.7.0 compose-order trap). The bio
            # is awaited (not fire-and-forget) so its rows are part of the
            # first render — a bio popping in on a REBUILD would shift every
            # item_id below it (walk-stability).
            my ($bio, $bioDone, $rgs, $rgsErr, $local, $offDone, $rendered,
                $poolDone, $extDone);
            my $render = sub {
                return if $rendered || !$bioDone || !$offDone || !$poolDone
                       || !$extDone || (!defined $rgs && !$rgsErr);
                $rendered = 1;
                if ($rgsErr) {
                    $callback->({ items => [{
                        name => cstring($client, 'PLUGIN_DISCOGRAPHY_ERROR'),
                        type => 'text',
                    }], cachetime => 0 });
                }
                else {
                    $callback->({
                        items => _buildList($client, $opts, $mbid, $rgs, $bio, $local),
                        # No feed-level caching: the sort toggle and Refresh must
                        # re-run us (the data layer has its own cache).
                        cachetime => 0,
                    });
                }
            };

            # The MAI/Last.fm biography is name-keyed too — the prominent
            # act's life story under a different artist's name is worse than no
            # biography at all.
            #
            # ASYNC guard (0.44.5). The sync form answers from cache only and a
            # cold cache answers "no", so the FIRST visit to a secondary act's
            # page rendered the prominent act's biography — the exact leak Simon
            # reported (Pete Kember's bio on the Sonic Boom group with Andrew
            # Huang). The fetch is cached and the page is already waiting on MB,
            # so correctness here costs nothing a user can perceive.
            #
            # A SHARED NAME TAKES THE EXACT ROUTE (0.56.22), not no biography:
            # MusicBrainz's Wikidata link for THIS act, never the name. Muzz
            # (the NYC trio) had none on 0.56.21; see _fetchExactBio.
            if ($prefs->get('show_bio')) {
                Plugins::Discography::API->sharesNameWithProminentAsync(
                    $opts->{artist}, $mbid, sub {
                        my ($shared) = @_;
                        my $fetch = $shared ? \&_fetchExactBio : \&_fetchArtistBio;
                        $fetch->($client, $artist, $mbid, sub {
                            $bio = shift; $bioDone = 1; $render->();
                        });
                    });
            }
            else {
                # Bio off (grid-friendly view): no text rows from us.
                $bioDone = 1;
            }

            # THE SIMILAR-ARTISTS WARM RUNS IN PARALLEL WITH MUSICBRAINZ, not
            # behind it (0.47.4). MEASURED cold on the live box (Jamie Cullum,
            # 2.32s total): this leg is **1,130ms — 49% of the render** — and it
            # is MAI/Last.fm, not MusicBrainz, so queueing it inside the serial
            # 1-req/s chain paid an etiquette tax it does not owe.
            #
            # STILL AWAITED (0.31.0's first-render decision stands): the section
            # popping in on a later rebuild would shift item_ids below it. It
            # simply stops waiting for MusicBrainz first. The `official_wait`
            # deadline covers this flag too, so a hung MAI can no longer gate
            # the page any longer than it could before.
            _warmArtistExtras($client, $mbid, $artist,
                              sub { $extDone = 1; $render->() });

            Plugins::Discography::API->getReleaseGroups(
                mbid    => $mbid,
                force   => $opts->{force},
                # The artist read first: the band lookup below needs it anyway,
                # and under 25 groups it carries the whole spine, so no browse
                # is sent (stage 2). It then finds the bands already cached.
                read    => 1,
                onDone  => sub {
                    $rgs = shift;

                    # A secondary act sharing the prominent one's exact name:
                    # every name-keyed lookup below would return the PROMINENT
                    # act's data. See API::sharesNameWithProminent.
                    my $shared = Plugins::Discography::API
                        ->sharesNameWithProminent($opts->{artist}, $mbid);
                    $opts->{shared_name} = $shared;
                    _dbg("'$opts->{artist}' shares its name with a more prominent"
                        . ' act - suppressing name-keyed library/bio/similar')
                        if $shared;

                    # The MB titles for THIS mbid — the reference a service
                    # artist has to corroborate when several share the name.
                    # _resolveArtist self-gates on the service actually
                    # returning >1 same-name artist, so passing this always is
                    # safe: an unambiguous artist takes the identical path it
                    # always did.
                    # AWAIT the streaming warm when hide_unmatched is on and no
                    # pool exists yet. Rendering first produces a page that
                    # ignores the pref (the !resolved exemption treats "not
                    # asked yet" as "asked and found nothing") and then
                    # contradicts itself on the next visit — 85 unmatched
                    # releases, then 0. Version-scoped pool keys mean EVERY
                    # artist is cold after an update, so this was not an edge
                    # case. Costs the streaming resolution once per artist.
                    #
                    # AWAITED WITH THE PREF OFF TOO (0.56.26; Simon 2026-10-02,
                    # Adele -> Sam Smith on a phone: tiles not playable, no
                    # service badges, every cover slow). 0.44.8 waited only when
                    # the pref was on, reasoning that unmatched releases are
                    # shown anyway; but a page drawn before its pool has NO
                    # matches at all, so every tile lost its play, its badge and
                    # its streaming cover, and fell back to the Cover Art
                    # Archive (slow, and it stalls the server while it loads).
                    # The wait is shorter with the pref off (POOL_WAIT_SHOWN):
                    # each service caches its pool as it lands, so a render at
                    # the deadline still shows the services that answered.
                    my $poolCold = Plugins::Discography::Sources
                        ->peekPool($opts->{artist}, $mbid)->{cold};
                    my $await = $poolCold ? 1 : 0;
                    my $waitMax = $prefs->get('hide_unmatched')
                        ? POOL_WAIT_MAX : POOL_WAIT_SHOWN;
                    $poolDone = 1 unless $await;
                    _dbg("pool is cold - awaiting streaming resolution before render"
                        . " (at most ${waitMax}s)")
                        if $await;

                    if ($await) {
                        # SAFETY NET: getCandidates fans out to several service
                        # plugins, and one that never calls back would leave the
                        # page hanging forever — a far worse failure than the
                        # one being fixed. Render regardless after this long.
                        my $settled = 0;
                        my $finish = sub {
                            return if $settled++;
                            $poolDone = 1;
                            $render->();
                        };
                        Slim::Utils::Timers::setTimer(undef, time() + $waitMax,
                            sub {
                                return if $settled;
                                _dbg('pool warm did not settle in '
                                    . $waitMax . 's - rendering anyway');
                                $finish->();
                            });
                        $warm->(_spineTitles($rgs), $finish);
                    }
                    else { $warm->(_spineTitles($rgs)) }

                    # Library albums, fetched ONCE here (sync DB) so the chain
                    # knows which owned releases the bootleg check leaves
                    # unplaced; the same list is handed to _buildList so it
                    # doesn't query again.
                    #
                    # The shared-name suppression applies ONLY to a NAME-resolved
                    # entry. `localAlbums($artist_id, ...)` is ID-keyed whenever an
                    # artist_id is present — it is exact to THAT contributor, and
                    # when that contributor owns no album its fallback (0.51.8)
                    # re-resolves by MB tag ONLY on a shared-name page
                    # (_idFallback), so it cannot return the prominent act's albums
                    # and there is nothing to suppress. Only the name fallback
                    # (no artist_id) would grab the wrong act's catalogue, which is
                    # the case 0.43.4 was written for. Suppressing the id-keyed
                    # lookup too is what hid Simon's owned "The Bees" compilation
                    # tracks (77854/79768): entered by their own contributor id,
                    # their VA-comp appearance is correct and belongs in
                    # "Appearances", but the guard forced $local empty so the page
                    # read "No releases found". The bio and similar-artists
                    # sections stay suppressed via $opts->{shared_name} — those ARE
                    # name-keyed (MAI/Last.fm) and would show the prominent act.
                    # $mbid is the artist we RESOLVED, so a name-entered view
                    # (search drill-in, similar-artist or band link) can find
                    # the owned albums by the library's own MusicBrainz tag
                    # instead of by spelling — 0.51.3.
                    $local = ($opts->{shared_name} && !$opts->{artist_id}) ? []
                           : Plugins::Discography::Sources->localAlbums(
                                 $opts->{artist_id}, $opts->{artist}, $mbid,
                                 { fallback => _idFallback($opts) });

                    # AWAITED, bounded. The bootleg map is cached only whole
                    # (API::warmOfficial says why), so the first render either
                    # waits for it or shows bootlegs — we wait. One MB request per
                    # 100 groups on the page, at most 6 (stage 2); the deadline
                    # still caps it, and a check that misses it finishes in the
                    # background for the next entry. A render the deadline
                    # forces has no release map either, so an owned album only
                    # its id can place (the Esher Demos) waits for the next
                    # visit too (A2 `STAGE 2 CHANGED FIVE`, #4).
                    #
                    # ONE serial MB chain (never parallel — 2 chains break MB's
                    # 1 req/s etiquette): the band lookup, then the bootleg
                    # check, then, after the render, the owned-album lookups and
                    # the collaboration vetting. The check maps every release of
                    # every group on the page, owned ones included, so the
                    # owned-album lookups no longer go first: they are for what
                    # the check could not place, and serve the next visit.
                    my $wait = $prefs->get('official_wait');
                    $wait = OFFICIAL_WAIT_DEFAULT unless defined $wait;

                    my $startBootleg = sub {
                        my ($await) = @_;
                        # AFTER the check, both for the next visit. The owned
                        # releases it did not place (all of them when it
                        # failed; none to do when another visit's check is
                        # still running, which does its own), then the
                        # collaboration vetting. That costs one spaced MB request
                        # per candidate (up to 8), which ahead of the bootleg
                        # check would blow the `official_wait` deadline on a
                        # public-API install and render the page with bootlegs
                        # unfiltered. The section is cache-only at render time
                        # anyway, so it simply appears on the next entry (review
                        # 2026-09-19).
                        my $then = sub {
                            my ($state) = @_;
                            my $collabs = sub {
                                Plugins::Discography::API->warmCollaborations($mbid);
                            };
                            return $collabs->()
                                if ($state // '') eq 'busy' || !@{ $rgs || [] };
                            # A first list (0.56.7): MusicBrainz completes it
                            # first, in the background, so its release map
                            # places the owned albums the community's did not.
                            Plugins::Discography::API->completeArtist($mbid, sub {
                                Plugins::Discography::API->warmLocalReleases(
                                    _unplacedReleases($local, $rgs,
                                        Plugins::Discography::API->peekReleaseMap($mbid)),
                                    $collabs);
                            });
                        };
                        if ($await) {
                            Plugins::Discography::API->warmOfficial($mbid, $rgs, sub {
                                my @state = @_;
                                unless ($offDone) {
                                    $offDone = 1;
                                    Slim::Utils::Timers::killTimers(undef, $await);
                                    $render->();
                                }
                                $then->(@state);
                            });
                        }
                        else {
                            Plugins::Discography::API->warmOfficial($mbid, $rgs, $then);
                        }
                    };

                    unless ($wait > 0) {           # 0 = never wait (opt-out)
                        # Opt-out means render NOW, so the extras flag is
                        # settled here too — it must never reintroduce a wait
                        # the user has explicitly turned off.
                        $offDone = 1; $extDone = 1; $render->();
                        Plugins::Discography::API->warmBandMembers($mbid, sub {
                            $startBootleg->(undef);
                        });
                        return;
                    }

                    my $deadline = sub {
                        return if $offDone && $extDone;
                        # Covers the parallel extras leg as well. Inside the
                        # serial chain a hung MAI was already capped by this
                        # timer (it blocked the bootleg leg, which the timer
                        # overrode); gating a NEW flag without extending the
                        # deadline would have made a hung MAI hang the page
                        # forever — a regression hidden inside a speed-up.
                        $offDone = 1; $extDone = 1;
                        _dbg("official-status: ${wait}s deadline hit - rendering, "
                             . "pass continues in the background");
                        $render->();
                    };
                    Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + $wait, $deadline);

                    # The band-member lookup, then the bootleg check — one serial
                    # MB chain. The lookup is normally a cache hit: the artist
                    # read that answers it came first, with the spine. The band
                    # list and the release map are both cached before the check
                    # sets $offDone, so both are ready for the first render
                    # (deadline permitting).
                    # The MAI/Last.fm extras leg is NOT in this chain: it is
                    # not a MusicBrainz request, so it owes no etiquette gap
                    # and runs in parallel (0.47.4).
                    Plugins::Discography::API->warmBandMembers($mbid, sub {
                        $startBootleg->($deadline);
                    });
                },
                # EVERY $render flag must be settled here, $poolDone included:
                # it is only otherwise set inside the onDone above, so an MB
                # error left $render permanently gated and the callback was
                # never fired at all — a spinner that hangs forever instead of
                # the error row. There is nothing to await anyway: with no
                # release groups there is no spine, so the streaming warm this
                # flag exists to wait for is never started.
                onError => sub {
                    $rgsErr = 1; $offDone = 1; $poolDone = 1; $extDone = 1; $render->();
                },
            );
    };

    # Enter by a KNOWN artist mbid (an "Also a member of" band link) to browse
    # that band directly; otherwise resolve the artist (library tag, then MB name
    # search, with a corroborated fallback for a wrong tag). Both feed $withMbid.
    if ($opts->{mbid} && $opts->{mbid} =~ /^[0-9a-f-]{36}$/i) {
        $withMbid->(lc $opts->{mbid});
    }
    else {
        _resolveArtistMbid($client, $opts, $withMbid);
    }
}

# Resolve an artist to the mbid we should actually BROWSE, healing a wrong/merged
# library tag. getArtistMbid trusts the file's album-artist MBID first (exact
# identity, normally right). But a mis-tagged same-name artist resolves fine yet
# browses EMPTY — field case: Simon's UK "The Bees" albums carry a US garage
# band's mbid (dd11eecd, 0 release-groups), while the real band (276cfa71, 18
# RGs) is what a name search finds. So if a TAG mbid has no release-groups, hand
# off to _disambiguateByLibrary. Name-searched mbids are trusted as-is (no tag to
# be wrong). getReleaseGroups is cached, so the main chain re-fetching the chosen
# mbid is a cache hit.
sub _resolveArtistMbid {
    my ($client, $opts, $cb) = @_;
    my $api  = 'Plugins::Discography::API';
    my $name = $opts->{artist};

    $api->getArtistMbid(
        artist_id => $opts->{artist_id},
        artist    => $name,
        # The page asks the same-name set next (the warm and the bio guard), so
        # the resolver's name search fetches enough entries to answer both
        # (API::_nameSearch): one request where there were two.
        fetch     => Plugins::Discography::API::NAME_FETCH(),
        onDone    => sub {
            my ($mbid, $fromTag) = @_;
            return $cb->($mbid) unless $mbid && $fromTag && defined $name && length $name;

            # This is the page's own spine (the page then finds it cached), so
            # it is asked for the page's way: the artist read first (stage 2).
            $api->getReleaseGroups(mbid => $mbid, read => 1,
                onError => sub { $cb->($mbid) },
                onDone  => sub {
                    my $rgs = shift;
                    return $cb->($mbid) if $rgs && @$rgs;    # tag has a discography -> good
                    _dbg("tag mbid $mbid has 0 release-groups; disambiguating '$name' by library");
                    _disambiguateByLibrary($opts, $mbid, $cb);
                });
        },
    );
}

# Weight of one owned-album title as disambiguation EVIDENCE for a same-name
# artist: 0.5 self-titled or generic, 1.0 distinctive. The list and the reasons
# live in Sources::_titleWeight (moved there for C2, which weighs titles in API).
sub _matchWeight { return Plugins::Discography::Sources::_titleWeight(@_) }

# The page builders' opt-in for localAlbums/localTracks when the entry id
# performs on no album (LMS search lists composer-only contributors — "The
# B-52's", 2026-09-19). A same-name page may fall back by MB tag only: a name
# there would borrow the other act's catalogue (0.43.4).
sub _idFallback {
    my ($o) = @_;
    return $o->{shared_name} ? 'mbid' : 'name';
}

# Among the SAME-NAME MusicBrainz artists, pick the one whose discography best
# matches the user's OWNED albums (title match — no MBIDs needed). Deliberately
# checks EVERY candidate and keeps the BEST-scoring, NOT the first that matches:
# the right "The Bees" isn't necessarily the highest MB-scored one, and a wrong
# same-name artist can coincidentally share a single album title (Simon, 2026-07).
# Matches are WEIGHTED (see _matchWeight): self-titled and generic-compilation
# titles corroborate weakly, so a lone coincidental collision can't win — a
# candidate is adopted only when its weight >= DISAMBIG_MIN_WEIGHT, else the tag
# is kept (an obscure same-name contributor is never mis-attributed). Ties break
# toward the higher search score (strictly-greater keeps the earlier candidate).
# Probes are serial, spaced to MB's 1 req/s on the public API (0 on a mirror),
# bounded to DISAMBIG_MAX; each RG list is cached (14d) so a repeat visit is free.
use constant DISAMBIG_MAX        => 8;
use constant DISAMBIG_MIN_WEIGHT => 1.0;
sub _disambiguateByLibrary {
    my ($opts, $tagMbid, $cb) = @_;
    my $api  = 'Plugins::Discography::API';
    my $name = $opts->{artist};

    my $local = Plugins::Discography::Sources->localAlbums($opts->{artist_id}, $name);
    return $cb->($tagMbid) unless $local && @$local;   # nothing to corroborate against

    $api->getArtistCandidates($name, sub {
        my $cands = shift || [];
        @$cands = grep { ($_->{mbid} // '') ne $tagMbid } @$cands;   # tag already known dead
        @$cands = @$cands[0 .. DISAMBIG_MAX - 1] if @$cands > DISAMBIG_MAX;
        return $cb->($tagMbid) unless @$cands;

        my ($best, $bestW) = ($tagMbid, 0);
        my $i = 0;
        # Self-passing closure, not a captured lexical (the 0.30.1 leak fix):
        # this walk runs whenever a tagged mbid fails to resolve.
        my $step = sub {
            my ($self) = @_;
            if ($i >= @$cands) {
                my $ok = $bestW >= DISAMBIG_MIN_WEIGHT;
                _dbg("disambiguate '$name': "
                    . ($ok ? "adopting $best (weight $bestW)"
                           : "no confident match (best weight $bestW) - keeping $tagMbid"));
                return $cb->($ok ? $best : $tagMbid);
            }
            my $c = $cands->[$i++];
            $api->getReleaseGroups(mbid => $c->{mbid},
                onError => sub { $self->($self) },
                onDone  => sub {
                    my $rgs = shift;
                    if ($rgs && @$rgs) {
                        my $claimed = Plugins::Discography::Sources->claimedLocalIds(
                                          $rgs, $name, $local, {});
                        my $w = 0;
                        for my $it (@$local) {
                            $w += _matchWeight($it->{_candTitle}, $name)
                                if $claimed->{ $it->{_albumid} };
                        }
                        ($best, $bestW) = ($c->{mbid}, $w) if $w > $bestW;   # strictly-greater keeps higher score on ties
                        _dbg("disambiguate '$name': candidate $c->{mbid} (score "
                            . ($c->{score} // '?') . ") weight $w ("
                            . scalar(keys %$claimed) . " raw match(es))");
                    }
                    # No gap of its own (0.51.17): every request this walk makes
                    # goes through API::_netGet, which paces on the URL. A gap
                    # here as well would double the wait on the public host,
                    # and on a mirror it was already 0.
                    $self->($self);
                });
        };
        $step->($step);
    });
}

# ---------------------------------------------------------------------------
# Artist biography (list header): MAI's getBiography via LBF's direct-function
# pattern (guarded; artist MBID passed for exact identity). Cached per artist;
# '' = confirmed none. No Last.fm fallback (that needs LBF's key infra).
# ---------------------------------------------------------------------------
# TEXT IN THE CACHE MUST BE OCTETS (0.51.2). `Slim::Utils::DbCache` dies with
# "Wide character in subroutine entry" on a character string, and MAI hands us
# bios and reviews as CHARACTERS — so every accented bio (i.e. most of them)
# was failing to cache inside an eval that swallowed the error, and was
# re-fetched on every single render. Found in the live log while chasing the
# same defect on the artist-name cache (API::_setMbName has the full autopsy).
# Read gives characters back, which is what the feed rows are built from.
sub _cacheSetText {
    my ($key, $text, $ttl) = @_;
    my $enc = defined $text ? $text : '';
    utf8::encode($enc) if utf8::is_utf8($enc);
    eval { $cache->set($key, $enc, $ttl); 1 }
        or $log->warn("text cache set failed for $key: $@");
    return;
}

sub _cacheGetText {
    my ($key) = @_;
    my $v = $cache->get($key);
    return undef unless defined $v;
    utf8::decode($v) unless utf8::is_utf8($v);
    return $v;
}

sub _fetchArtistBio {
    my ($client, $artist, $mbid, $cb) = @_;

    unless (defined $artist && length $artist) { $cb->(undef); return }

    # v2 (2026-09-24): the cached text is `_cleanBio` output — see _fetchAlbumReview.
    my $key = 'dsc:bio:2:' . lc $artist;
    utf8::encode($key) if utf8::is_utf8($key);
    if (defined(my $c = _cacheGetText($key))) {
        $cb->(length $c ? $c : undef);
        return;
    }

    my $bioFn;
    eval {
        $bioFn = Plugins::MusicArtistInfo::ArtistInfo->can('getBiography')
            if Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin');
        1;
    };
    unless ($bioFn) {
        _dbg("bio '$artist': MAI unavailable");
        eval { $cache->set($key, '', BIO_EMPTY_TTL); 1 };
        $cb->(undef);
        return;
    }

    my $ok = eval {
        $bioFn->($client, sub {
            my $items = shift || [];
            my $text;
            for my $it (@$items) {
                next unless ref $it eq 'HASH';
                my $t = $it->{name};
                if (_maiNotFound($client, $t)) { _dbg("bio '$artist': MAI not-found answer"); next }
                if (defined(my $c = _cleanProse($t))) { $text = $c; last }
            }
            _dbg("bio '$artist': " . (defined $text ? 'len=' . length $text : 'empty'));
            _cacheSetText($key, $text, (defined $text && length $text) ? BIO_FOUND_TTL : BIO_EMPTY_TTL);
            $cb->( (defined $text && length $text) ? $text : undef );
        }, {}, { artist => $artist, ($mbid ? (mbid => $mbid) : ()) });
        1;
    };
    unless ($ok) {
        $log->warn("MAI getBiography threw: $@");
        eval { $cache->set($key, '', BIO_EMPTY_TTL); 1 };
        $cb->(undef);
    }
}

# THE BIOGRAPHY OF AN ACT THAT SHARES ITS NAME (0.56.22; Simon, 2026-10-02, on
# Muzz the NYC trio: "it didnt find a bio for Muzz I am sure there is one").
# The name route above is held back for such an act (the guard in
# _discographyView): keyed and fetched by name, it would show the best-known
# act's biography (MUZZ the producer's). MAI's route is exact at ONE step only:
# the community API, asked with the act's mbid, answers from MusicBrainz's own
# Wikidata link for THAT act. MEASURED 2026-10-02: asked for Muzz with 893e0bd0
# it named 893e0bd0 and Wikipedia "Muzz (band)" (page 64177014), the page
# MusicBrainz links through Wikidata Q96394499. Every other step falls back to
# the NAME: Last.fm, and the community API itself when it does not know the
# mbid (asked with a wrong one, it answered for MUZZ the producer). So only that
# step is taken, with MAI's own functions (its queue, headers and cache):
#   * the reply counts only when it names THIS mbid and carries a Wikidata page;
#     another act's mbid, or no page, is no biography, as before;
#   * the page is read with MAI's own Wikipedia reader, as its route does;
#   * kept under the mbid, never the name, so it never reaches the other act;
#   * a reply naming no act is a failed call (MAI hands back the hash with its
#     error removed): nothing is kept, the next open asks again.
sub _fetchExactBio {
    my ($client, $artist, $mbid, $cb) = @_;

    unless ($mbid && defined $artist && length $artist) { $cb->(undef); return }

    my $key = Plugins::Discography::API::_bioMbidKey($mbid);
    if (defined(my $c = _cacheGetText($key))) {
        $cb->(length $c ? $c : undef);
        return;
    }

    my $done;
    my $answer = sub {
        my ($text, $ttl) = @_;
        return if $done++;
        _cacheSetText($key, $text, $ttl) if $ttl;
        $cb->($text);
    };

    my ($idFn, $pageFn, $langFn);
    eval {
        if (Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin')) {
            $idFn   = Plugins::MusicArtistInfo::API->can('getArtistBioId');
            $pageFn = Plugins::MusicArtistInfo::Wikipedia->can('getPage');
            $langFn = Plugins::MusicArtistInfo::Common->can('validateLanguage');
        }
        1;
    };
    unless ($idFn && $pageFn) {
        _dbg("exact bio '$artist' $mbid: MAI unavailable");
        return $answer->(undef, BIO_EMPTY_TTL);
    }
    my $lang = $langFn ? eval { $langFn->($client) } : undef;

    my $ok = eval {
        $idFn->('Plugins::MusicArtistInfo::API', sub {
            my $d = shift;
            $d = {} unless ref $d eq 'HASH';
            my $said = lc($d->{mbid} // '');
            my $w    = $d->{wikidata};
            unless (length $said) {
                _dbg("exact bio '$artist' $mbid: no answer (not kept)");
                return $answer->(undef, 0);
            }
            unless ($said eq lc $mbid && ref $w eq 'HASH' && $w->{pageid}) {
                _dbg("exact bio '$artist' $mbid: "
                    . ($said ne lc $mbid ? "answered for $said" : 'no Wikidata page'));
                return $answer->(undef, BIO_EMPTY_TTL);
            }
            my $read = eval {
                $pageFn->('Plugins::MusicArtistInfo::Wikipedia', $client, sub {
                    my $p = shift;
                    my $text = (ref $p eq 'HASH' && !$p->{error}) ? _cleanProse($p->{content}) : undef;
                    _dbg("exact bio '$artist' $mbid: Wikipedia '" . ($w->{title} // $w->{pageid}) . "' "
                        . (defined $text ? 'len=' . length $text : 'empty'));
                    $answer->($text, defined $text ? BIO_FOUND_TTL : BIO_EMPTY_TTL);
                }, { id => $w->{pageid}, title => $w->{title}, lang => $w->{lang} || $lang });
                1;
            };
            unless ($read) {
                $log->warn("MAI Wikipedia getPage threw: $@");
                $answer->(undef, BIO_EMPTY_TTL);
            }
        }, { artist => $artist, mbid => $mbid, ($lang ? (lang => $lang) : ()) });
        1;
    };
    unless ($ok) {
        $log->warn("MAI getArtistBioId threw: $@");
        $answer->(undef, BIO_EMPTY_TTL);
    }
}

# ---------------------------------------------------------------------------
# Similar artists via MAI (the same guarded direct-function pattern as the
# bio). The NAME LIST is cached (keyed by artist mbid) and warmed in the MB
# chain, so the section is usually part of the first render. Thumbnails are
# NOT pre-fetched: each row's image points at MAI's own image proxy
# (imageproxy/mai/artist/<name>/image.png — accepts a NAME, resolves local
# artwork -> Discogs/Last.fm -> MAI's default silhouette), so the browser
# loads every photo asynchronously IN-VIEW, like Material's native artist
# lists. No exit-and-re-enter needed (the 0.31.x photo-warm design's flaw).
# ---------------------------------------------------------------------------
sub _similarKey { 'dsc:similar:v1:' . ($_[0] // '') }

# Cache-only, sync: arrayref of similar-artist names, or undef until warmed.
sub _peekSimilar { $cache->get(_similarKey($_[0])) }

# Row thumbnail: MAI's artist image proxy URL (name-keyed), or the person
# icon when MAI isn't available (same look as pre-0.31.0).
# KEY BY CONTRIBUTOR ID WHEN THE LIBRARY KNOWS THE ARTIST — the way LMS itself
# does it (its own artist browse emits `contributor/<hash>/image`, identical for
# every spelling of a name).
#
# FIELD (Simon, 2026-07-22): "when I play these albums or browse the artists I
# get the correct artwork ... from MAI" — while the plugin's own row showed the
# silhouette. The name-keyed proxy CANNOT resolve a name carrying typographic
# punctuation, and 56 of his 4,288 library artists have some. Measured live:
#
#     name 'The La’s'    ->   5,071 bytes (placeholder)   id 57545 -> 418,519
#     name 'The Go‐Go’s' ->   5,071 bytes (placeholder)   id       -> 411,927
#     name 'The dB’s'    ->   5,071 bytes (placeholder)   id       ->  41,154
#     name 'Radiohead'   -> 214,785 bytes                 id       -> 214,785
#
# An earlier plan to TRANSLITERATE the punctuation was dropped: it fixed the
# symptom for library artists while leaving the plugin keyed differently from
# the rest of LMS, and Simon's observation is what showed the id route exists.
# NOTE the id route can return a SMALLER image (The B-52s: 234KB by id vs 1.9MB
# by name) because it serves the artwork MAI already holds for that contributor
# — that is the same picture the rest of his LMS shows, which is the point.
#
# No id (streaming-only rows, similar artists, MB candidates) takes OUR OWN
# proxy since 0.51.0 — same lazy in-view load, but a resolver that can tell a
# placeholder from a photograph and fill the gap from a service (see
# artistImageProxy). The id route is untouched: it already serves the picture
# the rest of LMS shows, which is the whole point of 0.46.2.
sub _artistImg {
    my ($name, $artistId) = @_;
    my $mai;
    eval {
        $mai = Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin');
        1;
    };
    return 'imageproxy/mai/artist/' . $artistId . '/image.png'
        if $mai && defined $artistId && $artistId =~ /^\d+$/;
    return IMG_BASE . 'dsc-bio_MTL_icon_person.png'
        unless defined $name && length $name;
    # No MAI *and* no services = nothing to resolve; don't route a request
    # through the proxy only to answer it with the icon we already have.
    # Counted in LIST context: orderedAdapters ends in `return sort`, and sort
    # in scalar context returns nothing — `scalar(orderedAdapters())` was false
    # with every service enabled.
    return IMG_BASE . 'dsc-bio_MTL_icon_person.png'
        unless $mai || eval { my @a = Plugins::Discography::Sources::orderedAdapters(); scalar @a };
    require URI::Escape;
    return 'imageproxy/dsc/artist/' . URI::Escape::uri_escape_utf8($name) . '/image.png';
}

# ---------------------------------------------------------------------------
# THE ARTIST-ARTWORK RESOLVER (0.51.0) — `imageproxy/dsc/artist/<name>`
#
# WHY WE OWN THE PROXY NOW. MAI's name route ends at api.lms-community.org's
# `/artist/<name>/picture`, a PERIODIC SNAPSHOT of Deezer. When Deezer's own
# picture hash moves, the snapshot URL 302s to the md5 of the empty string and
# MAI faithfully serves the placeholder it was handed — the "no artwork" rows
# Simon reported for The Mothers of Invention (2026-07-29), and the same cause
# as Pink Floyd / B52's in 0.46.5, all three still reproducing today. Nothing
# in the row, the name or the cache is wrong, so nothing on our side could fix
# it by asking MAI more carefully: the ONLY fix is to notice and go elsewhere.
#
# TIERS, first answer wins, whole verdict cached 30d (1d for a miss):
#   1. MAI local artwork — the user's own artist photo files. Unconditionally
#      first: a file the user put there outranks anything online, and it is the
#      one fix 0.46.5 could offer for a dead upstream picture.
#   2. MAI's online picture — UNLESS it is a Deezer CDN url that HEADs to the
#      "no picture" entity (one request, redirect-following off, cached with
#      the verdict). Keeping MAI ahead of the services is deliberate: it is
#      what the rest of LMS shows for that artist.
#   3. The user's own services (Qobuz/Tidal/Deezer in svc_priority order) —
#      live, so a moved Deezer hash resolves here even when the snapshot is
#      stale.
#   4. The person icon. An honest blank, not a silhouette we didn't choose.
#
# The handler runs ONCE PER VISIBLE THUMBNAIL, not per render: the browser asks
# only for rows it actually paints, so a 25-row Similar-artists section costs
# nothing until it is scrolled — and nothing at all on the second visit.
# ---------------------------------------------------------------------------

use constant ARTIMG_FOUND_TTL => 30 * 86400;
use constant ARTIMG_EMPTY_TTL =>  1 * 86400;
use constant ARTIMG_PROBE_TO  => 10;   # HEAD watchdog for the placeholder probe
use constant MAI_PHOTO_TO     => 15;   # MAI must answer or we move on

sub _artImgKey {
    my ($name) = @_;
    my $key = 'dsc:artimg:v1:' . lc($name // '');
    utf8::encode($key) if utf8::is_utf8($key);   # octet key (see Sources::_candKey)
    return $key;
}

# The plugin's own person icon as a file:// url — the imageproxy only accepts
# file/http(s), so the web-relative IMG_BASE path can't be handed back here.
sub _personIconFile {
    my $p = eval {
        my $dir = Slim::Utils::PluginManager->dataForPlugin(
            'Plugins::Discography::Plugin')->{basedir};
        $dir ? File::Spec->catfile($dir, 'HTML', 'EN', 'plugins', 'Discography',
                                   'html', 'images', 'dsc-bio_MTL_icon_person.png')
             : undef;
    };
    return undef unless $p && -f $p;
    return eval { Slim::Utils::Misc::fileURLFromPath($p) };
}

# Slim::Web::ImageProxy handler. Returning a url answers synchronously;
# returning undef means "I called $cb" (ImageProxy.pm:229).
sub artistImageProxy {
    my ($url, $spec, $cb) = @_;

    # ImageProxy hands us the path with the trailing /image* segment already
    # stripped (`imageproxy/(.*)/[^/]*`), so what is left is our escaped name.
    my ($enc) = ($url // '') =~ m{^dsc/artist/(.+)$};
    # `|| ''` as at the other two exits: undef means "I called $cb", so
    # returning it without doing so would hang the image request (a missing
    # bundled icon is the only way _personIconFile answers undef).
    return (_personIconFile() || '') unless defined $enc && length $enc;
    require URI::Escape;
    my $name = URI::Escape::uri_unescape($enc);
    # uri_unescape returns OCTETS; every consumer below wants CHARACTERS.
    # MAI's getArtistPhoto runs uri_escape_utf8 over what we hand it, so octets
    # would be encoded a second time and "Sigur Rós" would go out as
    # "Sigur RÃ³s" — the fleet's chars-vs-bytes trap, and it would silently cost
    # exactly the accented artists this resolver exists to rescue.
    utf8::decode($name);

    my $key = _artImgKey($name);
    if (defined(my $c = $cache->get($key))) {
        return $c || _personIconFile() || '';
    }

    _resolveArtistImage($name, sub {
        my ($u, $conclusive) = @_;
        # An empty verdict is stored only when the walk actually reached an
        # answer. If no service replied at all, this render still shows the
        # person icon, but the next one asks again instead of reading a
        # failure back for a day.
        eval { $cache->set($key, $u // '',
            $u ? ARTIMG_FOUND_TTL : ARTIMG_EMPTY_TTL); 1 }
            if $u || $conclusive;
        _dbg("artist image '$name': "
             . ($u || ($conclusive ? 'nothing found - person icon'
                                   : 'no service answered - person icon, not cached')));
        $cb->($u || _personIconFile() || '');
    });
    return undef;
}

sub _resolveArtistImage {
    my ($name, $cb) = @_;

    # Tier 1 — the user's own files. Sync (filesystem), like MAI's own handler.
    my $local = eval {
        Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin')
            && Plugins::MusicArtistInfo::LocalArtwork->can('getArtistPhoto')
            ? Plugins::MusicArtistInfo::LocalArtwork->getArtistPhoto(
                  { artist => $name, rawUrl => 1 })
            : undef;
    };
    if ($local && -f $local) {
        my $u = eval { Slim::Utils::Misc::fileURLFromPath($local) };
        return $cb->($u, 1) if $u;
    }

    # Tier 2 -> 3. $cb->($url, $conclusive): the service tier reports whether
    # any service actually replied, and that verdict is the whole walk's —
    # tiers 1 and 2 finding nothing is not an answer on its own, it is why we
    # asked the services at all. The proxy caches on it (review 2026-09-20).
    _maiArtistPhoto($name, sub {
        my ($u) = @_;
        return $cb->($u, 1) if $u;
        Plugins::Discography::Sources->artistImage(undef, $name,
            sub { $cb->($_[0], $_[1]) });
    });
}

# MAI's ONLINE picture for a name, or undef when there isn't a real one.
# $cb fires exactly once (no photo / dead photo / good photo / MAI absent /
# MAI never answering).
sub _maiArtistPhoto {
    my ($name, $cb) = @_;
    my $fn;
    eval {
        $fn = Plugins::MusicArtistInfo::API->can('getArtistPhoto')
            if Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin');
        1;
    };
    return $cb->(undef) unless $fn;

    my $settled = 0;
    my $timer;
    my $done = sub {
        return if $settled++;
        Slim::Utils::Timers::killSpecific($timer) if $timer;
        $cb->($_[0]);
    };
    $timer = Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + MAI_PHOTO_TO, sub {
        return if $settled;
        _dbg("artist image '$name': MAI did not answer in " . MAI_PHOTO_TO . 's');
        $done->(undef);
    });

    my $ok = eval {
        $fn->('Plugins::MusicArtistInfo::API', sub {
            my $photo = shift || {};
            my $u = $photo->{url};
            return $done->(undef)
                unless defined $u && !ref $u && $u =~ m{^https?://}i;
            return $done->(undef)
                if Plugins::Discography::Sources::isPlaceholderImage($u);
            # Only Deezer's CDN has the stale-hash failure mode, and only it
            # needs the probe — a last.fm/Discogs url is served as-is.
            return _probeArtistImage($u, $name, $done)
                if $u =~ m{dzcdn\.net/images/artist/}i;
            $done->($u);
        }, { artist => $name });
        1;
    };
    unless ($ok) {
        $log->warn("MAI getArtistPhoto threw: $@");
        $done->(undef);
    }
}

# Is this Deezer CDN url a photograph, or the "no picture" entity in disguise?
# HEAD with redirects OFF (maxRedirect => 0, honoured by Async::HTTP), so the
# 302 lands in the ERROR callback with its Location intact — that target is the
# whole signal. Anything else (timeout, DNS, a 4xx) is INCONCLUSIVE and keeps
# MAI's url: a network hiccup must not demote a good picture.
sub _probeArtistImage {
    my ($url, $name, $cb) = @_;
    Slim::Networking::SimpleAsyncHTTP->new(
        sub { $cb->($url) },
        sub {
            my (undef, $error, $res) = @_;
            my $loc = eval { $res->header('Location') } // '';
            if (Plugins::Discography::Sources::isPlaceholderImage($loc)) {
                _dbg("artist image '$name': MAI's Deezer picture is the "
                     . 'no-picture placeholder - trying the services');
                return $cb->(undef);
            }
            $cb->($url);
        },
        { timeout => ARTIMG_PROBE_TO, maxRedirect => 0 },
    )->head($url);
}

sub _maiFn {
    my ($name) = @_;
    my $fn;
    eval {
        $fn = Plugins::MusicArtistInfo::ArtistInfo->can($name)
            if Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin');
        1;
    };
    return $fn;
}

# Resolve + cache the related-artist NAME list once. $cb fires (arrayref) on
# cache hit / done / MAI-unavailable / failure.
sub _warmSimilarArtists {
    my ($client, $mbid, $artist, $cb) = @_;
    $cb ||= sub {};
    return $cb->([]) unless $mbid && defined $artist && length $artist;

    my $key = _similarKey($mbid);
    if (defined(my $c = $cache->get($key))) { return $cb->($c) }

    my $fn = _maiFn('getRelatedArtists');
    unless ($fn) {
        _dbg("similar '$artist': MAI unavailable");
        eval { $cache->set($key, [], SIMILAR_EMPTY_TTL); 1 };
        return $cb->([]);
    }

    my $ok = eval {
        $fn->($client, sub {
            my $items = shift || [];
            my (@names, %seen);
            for my $it (@$items) {
                next unless ref $it eq 'HASH';
                next if ($it->{type} // '') eq 'text';   # MAI error row
                my $n = $it->{name};
                next unless defined $n && length $n;
                next if $seen{lc $n}++;
                push @names, $n;
                last if @names >= SIMILAR_MAX;
            }
            eval { $cache->set($key, \@names,
                @names ? SIMILAR_FOUND_TTL : SIMILAR_EMPTY_TTL); 1 };
            _dbg("similar '$artist': " . scalar(@names) . ' artist(s)');
            $cb->(\@names);
        }, {}, { artist => $artist, ($mbid ? (mbid => $mbid) : ()) });
        1;
    };
    unless ($ok) {
        $log->warn("MAI getRelatedArtists threw: $@");
        eval { $cache->set($key, [], SIMILAR_EMPTY_TTL); 1 };
        $cb->([]);
    }
}

# Warm the "Similar artists" name list (awaited under its own $extDone flag, in
# parallel with the MusicBrainz chain since 0.47.4, so the section is normally
# part of the FIRST render).
# Thumbnails need no warming — the rows point at MAI's image proxy and load
# in-view (see _artistImg).
sub _warmArtistExtras {
    my ($client, $mbid, $artist, $cb) = @_;
    $cb ||= sub {};
    return $cb->() unless $client;
    # Don't POISON the cache either: the fetch is by name, the key is by mbid,
    # so warming a shared-name act writes the prominent act's similar artists
    # under this artist's key — where a later render would trust it.
    #
    # ASYNC guard (0.47.4), and it is what makes running this leg in PARALLEL
    # with the MusicBrainz chain safe. The sync form answers from cache only,
    # and it used to be warm here purely because the bio path had already
    # fetched the same-name set several steps earlier in the serial chain.
    # Off that chain the peek is COLD, a cold peek answers "not shared", and
    # this would poison the cache for exactly the artists the guard exists to
    # protect — the 0.44.5 bug, re-created by a change that never touched it.
    # It costs no request: `getArtistCandidates` now dedupes in flight, so this
    # rides the fetch the bio guard already started.
    Plugins::Discography::API->sharesNameWithProminentAsync($artist, $mbid, sub {
        return $cb->() if $_[0];
        _warmSimilarArtists($client, $mbid, $artist, sub { $cb->() });
    });
}

# Normalised MB release titles, used to tell same-named service artists apart.
# Keyed with the matcher's own _norm so it compares like for like with the
# candidate titles it will be scored against.
sub _spineTitles {
    my ($rgs) = @_;
    my %t;
    for my $rg (@{ $rgs || [] }) {
        next unless ref $rg eq 'HASH' && defined $rg->{title};
        my $n = Plugins::Discography::Sources::_norm($rg->{title});
        $t{$n} = 1 if $n ne '';
    }
    return \%t;
}

# Did we browse this artist under a name that is genuinely THEIRS? (0.48.5)
#
# Only used to decide whether a render is entitled to record an "empty"
# verdict, which is keyed by MBID alone and therefore speaks for every row that
# resolves to it. A joint-credit entry ("Nick Cave & Warren Ellis") resolves to
# the HEAD act, so its page is built from a pool searched under a name that is
# not the artist's — a fair render of a different question.
#
# MB's canonical name and the cached alias list are the two things that make a
# name genuinely the artist's; a rename (British Sea Power -> Sea Power) is an
# alias and still qualifies. Cache-only, no request.
#
# FAILS SAFE, deliberately: an unknown canonical name returns 0, so we decline
# to record rather than record on a guess. The cost of a missing verdict is one
# thin search row; the cost of a wrong one is a real artist hidden for a week.
sub _browsedAsSelf {
    my ($mbid, $name) = @_;
    return 0 unless $mbid && defined $name && length $name;
    my $canon = Plugins::Discography::API->peekArtistName($mbid);
    return 0 unless defined $canon && length $canon;
    my $n = Plugins::Discography::Sources::_norm($name);
    return 0 unless length $n;
    return 1 if $n eq Plugins::Discography::Sources::_norm($canon);
    for my $a (@{ Plugins::Discography::API->peekArtistAliases($mbid) || [] }) {
        return 1 if $n eq Plugins::Discography::Sources::_norm($a);
    }
    return 0;
}

# The artist's OTHER MusicBrainz names, normalised: its canonical name and its
# aliases for $mbid, minus the name the page was opened under, each once. For
# Sources::_otherNamesFor (C3: the same releases whichever name opened the page).
# Cache only: the artist read every page makes fills both, so no request; a
# cold cache gives none, and the page tests the name it was opened under alone,
# as before.
sub _otherNames {
    my ($mbid, $artist) = @_;
    return [] unless $mbid;
    my %seen = (Plugins::Discography::Sources::_norm($artist // '') => 1);
    my @out;
    for my $n (Plugins::Discography::API->peekArtistName($mbid),
               @{ Plugins::Discography::API->peekArtistAliases($mbid) || [] }) {
        next unless defined $n && length $n;
        my $nn = Plugins::Discography::Sources::_norm($n);
        push @out, $nn unless $nn eq '' || $seen{$nn}++;
    }
    return \@out;
}

sub _buildList {
    my ($client, $opts, $mbid, $rgs, $bio, $local) = @_;

    # Carry the RESOLVED artist MBID on every tile's passthrough so the detail
    # page can rebuild the same relMap + rivals the list used (without it,
    # drill-in loses tier-0 identity — Local wouldn't show — and the rival rule).
    #
    # But keep the ENTRY mbid separate: the LIST-view identity actions must NOT
    # carry the resolved mbid. The Material entry/refresh command (the custom
    # action) carries no mbid on a person/name entry, so emitting the resolved
    # one there desyncs topLevel's $same identity check and wipes the
    # refresh-toggle ctx flags (the 0.8.1 bug — bio "Read more" / section paging
    # dead; verified live 2026-07-15). _identParams emits the ENTRY mbid (present
    # only for a band-link entry, which DOES carry it end-to-end); _rgIdent adds
    # the resolved mbid explicitly where detail dispatch genuinely needs it.
    $opts = { %$opts, entry_mbid => $opts->{mbid}, mbid => $mbid };

    my $sort = $opts->{sort} || 'newest';
    my $useH = _wantHeaders($opts->{features});
    my $show = _shownTypes();
    my $hideUnmatched = $prefs->get('hide_unmatched');
    # local_only (the Options view toggle): render ONLY releases the user owns,
    # and only their Local version rows — the spine, dates, artwork and type
    # grouping stay, but streaming versions and the "Also on streaming" net are
    # dropped. The bio, "Also in your library", and the band/similar links are
    # kept (owned or navigation). It is a FILTERED view, so it neither sets nor
    # clears the empty-artist verdict (see below).
    my $localOnly = $opts->{local_only} ? 1 : 0;

    # WALK-STABILITY: hide_unmatched visibility is SNAPSHOTTED per visit. The
    # background warm means a release can gain/lose "matched" between the
    # render and a click — and since every click re-walks a REBUILT tree by
    # index, a tile disappearing mid-session would shift every item_id under
    # it and clicks would land on the wrong release. The snapshot (kept in the
    # per-player ctx, reset on every fresh entry / Refresh) freezes the
    # visible set for the visit; a re-entry picks up newly-warmed matches.
    my $ctx  = $lastCtx{ _cid($client) } ||= {};
    my $snap = $ctx->{snap} ||= {};

    # Local library albums for this artist: ONE sync DB query, fed into every
    # release's match. Local matches count for visibility (owned = shown) but do
    # NOT mark a release streaming-resolved. Passed in by _discographyView
    # (which needs the mbids to pre-resolve them); fetched here on the paths that
    # don't (e.g. a direct unit call).
    $local ||= Plugins::Discography::Sources->localAlbums(
        $opts->{artist_id}, $opts->{artist}, $opts->{mbid},
        { fallback => _idFallback($opts) });

    # Streaming candidate pools: read + reattached ONCE for the whole build,
    # then filtered per release. Peeking each release separately re-copied
    # every cached item (pools run to thousands since the artist-first fetch).
    # $mbid scopes the pool to THIS MusicBrainz artist — same key getCandidates
    # wrote under. Without it the render reads the name-keyed pool and a
    # same-name act matches against the prominent act's catalogue.
    my $pool = Plugins::Discography::Sources->peekPool($opts->{artist}, $mbid);

    # Filled by the release loop below: { svc => { album-id => 1 } }.
    my %claimedSvc;

    # Bootleg filter: { rg-mbid => 0|1 } for the groups on the page, or undef
    # until the bootleg check has completed once. A release-group MISSING from
    # a present map was never classified — fail open, like undef.
    my $officialMap = Plugins::Discography::API->peekOfficial($mbid);

    # { release-mbid => release-group-mbid }: lets a library album's
    # MUSICBRAINZ_ALBUMID match its tile by identity — the title matcher can't
    # get "The Beatles and Esher Demos" to the White Album. Two sources merged:
    # the bootleg check (every release of every group on the page) and the
    # per-album lookups for what it could not place (made after an earlier
    # render, API::warmLocalReleases). The lookups win where both answer.
    my $relMap = { %{ Plugins::Discography::API->peekReleaseMap($mbid) || {} },
                   %{ Plugins::Discography::API->peekLocalReleaseMap(
                          [ map { $_->{_mbid} } grep { $_->{_mbid} } @$local ] ) } };

    # Owned TRACKS, for linking a release the user owns only as a Various
    # Artists compilation track (Simon's garage "The Bees" single, owned via
    # Nuggets; 0.51.9). LAZY: the
    # coderef fetches (and memoises) the track list only when matchesFor reaches
    # an otherwise-unmatched release, so an artist owned as albums never runs the
    # extra `titles` query. Same shared-name suppression and the same id
    # fallback as $local — id-keyed is exact (an id owning no album re-resolves
    # by tag only on a shared-name page); only a name-resolved shared-name entry
    # would grab the wrong act.
    my $ltCache;
    my $localTracks = sub {
        return $ltCache if defined $ltCache;
        $ltCache = ($opts->{shared_name} && !$opts->{artist_id}) ? []
                 : Plugins::Discography::Sources->localTracks(
                       $opts->{artist_id}, $opts->{artist},
                       { fallback => _idFallback($opts), mbid => $opts->{mbid} });
        return $ltCache;
    };

    # Same-title release-groups compete for one candidate (four official groups
    # normalise to "the beatles"); this decides which one owns it.
    my $rivals = _rivalsByTitle($rgs, $officialMap, $show);
    # Edition titles each group may also match by (same browse as $officialMap).
    my $editions = _editionTitles($rgs, Plugins::Discography::API->peekEditions($mbid));

    # Invariants for the whole list, computed ONCE (matchesFor used to redo both
    # for every release group): the artist norm and the source order. The RG
    # title norm is computed once per RG below and reused for BOTH the rivals
    # lookup and the matcher (was normed twice).
    my $artistNorm = Plugins::Discography::Sources::_norm($opts->{artist} // '');
    # The artist's other MusicBrainz names, and one answer per credit for the
    # whole list (C3: the same releases whichever name opened the page).
    my $otherNames = _otherNames($mbid, $opts->{artist});
    my %creditMemo;
    my $sources    = [ Plugins::Discography::Sources::orderedSources() ];
    # Groups a local copy's MusicBrainz id can place it in: the same pool
    # "Also in your library" claims across, so the two views agree.
    my $idGroups   = _idGroups($rgs);

    # For the empty-artist verdict below: how many release groups the USER's own
    # filters left on the table, and whether streaming was actually resolved.
    my ($typeOk, $poolResolved) = (0, 0);

    my @shown;
    for my $rg (@$rgs) {
        next if grep { $HIDE_SECONDARY{$_} } @{ $rg->{secondary} };
        next unless $show->{ _groupOf($rg) };
        $typeOk++;

        my $official = $officialMap ? $officialMap->{ $rg->{mbid} } : undef;
        my $bootleg = (defined $official && !$official) ? 1 : 0;

        my $rgNorm = Plugins::Discography::Sources::_norm($rg->{title});
        my $peek = Plugins::Discography::Sources->peekMatches(
            $opts->{artist}, $rg->{title}, $local, $pool, $rg->{mbid}, $relMap,
            $rivals->{$rgNorm},
            { artistNorm => $artistNorm, albumNorm => $rgNorm, sources => $sources,
              index => $pool->{index}, aliases => $rg->{aliases},
              rgType => $rg->{type}, editions => $editions->{ $rg->{mbid} },
              idGroups => $idGroups, localTracks => $localTracks,
              otherNames => $otherNames, creditMemo => \%creditMemo });
        # Which streaming candidates a release group CLAIMED. Collected here
        # rather than recomputed, because matching every candidate against
        # every release group is exactly the work this loop already does.
        for my $sec (@{ $peek->{sections} || [] }) {
            next if ($sec->{svc} // '') eq 'Local';
            $claimedSvc{ $sec->{svc} }{ $_->{_albumid} } = 1
                for grep { defined $_->{_albumid} } @{ $sec->{items} || [] };
        }
        $poolResolved ||= $peek->{resolved} ? 1 : 0;

        # In local_only mode a release shows iff the user OWNS it (has a Local
        # section), and only its Local section(s) render. Local membership comes
        # from the sync localAlbums query, stable for the whole visit, so it is
        # snapshot-safe like everything else here.
        my $localSecs = [ grep { ($_->{svc} // '') eq 'Local' } @{ $peek->{sections} || [] } ];

        my $visible = exists $snap->{ $rg->{mbid} }
            ? $snap->{ $rg->{mbid} }
            # Any match (local or streaming) shows; a miss only hides once
            # streaming was actually RESOLVED (cached) — never on unresolved.
            # Bootleg-only groups never show. Both live in the SAME snapshot so
            # a background resolve can't shift item_ids mid-visit.
            : ($snap->{ $rg->{mbid} } = $bootleg ? 0
                : $localOnly ? (@$localSecs ? 1 : 0)
                : (!$hideUnmatched || @{ $peek->{sections} } || !$peek->{resolved}) ? 1 : 0);
        next unless $visible;

        push @shown, [ $rg, $localOnly ? $localSecs : $peek->{sections} ];
    }

    # TWO reasons an empty on-spine result FALLS THROUGH instead of returning
    # "No releases found":
    #   * local_only is a FILTERED view (owned releases only), not a verdict on
    #     the artist's catalogue — an unfiltered render would still find plenty.
    #   * the user OWNS material by this artist (@$local). A spine can render
    #     empty even for an owned act — every release group is bootleg-only, or
    #     the artist has none in MB at all (dd11eecd, "The Bees", is exactly
    #     this: two release groups, both bootleg) — and showing "No releases
    #     found" over the top of an album the user owns is plainly wrong. Fall
    #     through to render the bio, "Also in your library" / "Appearances" and
    #     the band/similar links, so the owned material is reachable.
    # In both cases the markArtistEmpty guard below already refuses to record a
    # verdict (it requires `!@$local` and is skipped entirely on local_only), so
    # this only changes what is RENDERED, never what is remembered.
    unless (@shown || $localOnly || @$local) {
        # PROVE-THEN-REMEMBER (0.46.6). Simon: *"I thought we had put in place a
        # way to stop displaying artists when searching that return no content.
        # I am still finding these popping up."* The search-row filter asks
        # MusicBrainz "does this artist have releases?" — it cannot ask "is any
        # of it playable HERE", because that means resolving every row against
        # every service, ~6 requests per row on a 15-row search.
        #
        # But THIS render has just answered that question the expensive way.
        # Measured live on Luke Bushell (a "bush" search row): 8 release groups
        # in MB, `pool: Deezer=1, Qobuz=1, Tidal=1`, every one NO MATCH. So the
        # verdict is recorded here and `filterRowsWithContent` drops the row
        # next time. No extra request, ever — it reuses work already done.
        #
        # FOUR GUARDS, because wrongly hiding a real artist is far worse than
        # showing a thin one:
        #   * the pool must have RESOLVED — a cold or errored pool means "not
        #     asked yet", not "nothing there" (the 0.43.9 distinction, and the
        #     0.44.5 peek-guard lesson: a cold cache must never answer "no").
        #   * MB must actually list releases, and the user's own type filters
        #     must have left at least one on the table — an empty page because
        #     Singles are hidden is a PREFERENCE, not an absent artist (0.43.9:
        #     check the user's view filters before diagnosing a match failure).
        #   * never for an artist the user owns; owning the music outranks any
        #     verdict we could reach.
        #   * TTL'd, and cleared by Refresh / `clearcache`, so an artist whose
        #     catalogue arrives later heals on its own.
        #
        # NB this return short-circuits BEFORE the "Also on streaming" and
        # library-extras sections are built, so the verdict matches exactly what
        # the user sees: an empty page. If that early return is ever changed to
        # render those sections, this condition MUST move with it — otherwise a
        # row whose page does show playable rows would be hidden.
        #   * and (0.48.5) we must have browsed THIS artist under a name that is
        #     actually theirs. A joint-credit row resolves to the HEAD act
        #     (0.47.0: "Nick Cave & Warren Ellis" -> Nick Cave, because MB has no
        #     such artist), so the page was built from a pool searched under a
        #     DIFFERENT string — and the verdict is keyed by mbid alone, so
        #     recording it there condemns the head artist's own row. That is
        #     exactly how Simon lost solo Nick Cave from search while his page
        #     rendered 9 albums. A rename/alias entry (British Sea Power ->
        #     Sea Power) is a real name for the artist and still counts.
        if ($mbid && $poolResolved && $typeOk && @$rgs && !@$local
            && _browsedAsSelf($mbid, $opts->{artist})) {
            Plugins::Discography::API->markArtistEmpty($mbid, $opts->{artist});
        }
        return [{ name => cstring($client, 'PLUGIN_DISCOGRAPHY_NO_RESULTS'), type => 'text' }];
    }

    # THIS RENDER DISPROVES ANY "EMPTY" VERDICT ON THE ARTIST (0.48.5). The
    # verdict could previously only be SET — see API::clearArtistEmpty for why
    # that made a wrong one unfixable from the search it hides the row from.
    # Never from a filtered (local_only) render — @shown there is owned releases
    # only, which neither proves nor disproves the catalogue verdict.
    if (!$localOnly && $mbid && Plugins::Discography::API->clearArtistEmpty($mbid)) {
        _dbg("empty verdict CLEARED for " . ($opts->{artist} // '?') . " ($mbid) - "
            . 'this render found ' . scalar(@shown) . ' release(s)');
    }

    # ALBUMS | SINGLES VIEW (Simon, 2026-09-24; LBF's "Showing ..." toggle).
    # Applied HERE, after the release loop and the empty-verdict code, so it
    # only decides what is DISPLAYED: matching, rival ownership, the streaming
    # claims ("Also on streaming") and the hide_unmatched snapshot were all
    # computed for every release above, and the verdict judged the full set.
    # Singles view = the EPs and Singles sections (a true tab: no bio, extras or
    # links; EPs joined it at Simon's request, as LBF's "Singles & EPs");
    # Albums view = every other release section. Live etc. stay on Albums for now. The choice lives in the per-player ctx (reset by a
    # different artist, kept across this artist's own refreshes) and is CLAMPED
    # to a family this page has, so a singles-only artist never opens empty and
    # the toggle only appears when both families have something to show.
    my $hasSingles = grep {  $SINGLE_FAMILY{ _groupOf($_->[0]) } } @shown;
    my $hasAlbums  = grep { !$SINGLE_FAMILY{ _groupOf($_->[0]) } } @shown;
    my $view = ($ctx->{view} // '') eq 'singles' ? 'singles' : 'albums';
    $view = 'albums'  if $view eq 'singles' && !$hasSingles;
    $view = 'singles' if $view eq 'albums'  && !$hasAlbums && $hasSingles;
    my $singlesView = $view eq 'singles' ? 1 : 0;
    # The TAB (bio, extras and links held back) only exists when there is an
    # Albums view to hold them: a singles-only artist has no toggle, so its
    # page keeps every section rather than losing them with no way back.
    my $singlesTab = ($singlesView && $hasAlbums) ? 1 : 0;
    my @render = grep { ($SINGLE_FAMILY{ _groupOf($_->[0]) } ? 1 : 0) == $singlesView } @shown;

    my %bucket;
    push @{ $bucket{ _groupOf($_->[0]) } }, $_ for @render;

    # Artist bio at the very top (the phase-2 artist-view vision, list-native):
    # summary + the same refresh-toggle inline expand the review uses. Awaited
    # in _discographyView, so its row count is fixed for the whole visit.
    # Rows come from _proseSection (LBF's parser — headings, bullets, paragraphs).
    my @bioRows;
    if (defined $bio && length $bio) {
        my $akey     = lc($opts->{artist} // '');
        my $expanded = $lastCtx{ _cid($client) }{bio}{$akey};
        my ($prose, $truncated) = _proseSection($bio, $expanded);
        push @bioRows, @$prose;
        if ($expanded && $truncated) {
            push @bioRows, {
                name        => cstring($client, 'PLUGIN_DISCOGRAPHY_SHOW_LESS'),
                type        => 'link',
                image       => MENU_REVIEW,
                nextWindow  => 'refresh',
                id          => 'bio:less',
                itemActions => _listItemActions($opts, 'bio:less'),
                passthrough => [{ akey => $akey }],
                url         => sub {
                    my ($c, $cb, $a, $p) = @_;
                    delete $lastCtx{ _cid($c) }{bio}{ $p->{akey} };
                    $cb->({ items => [] });
                },
            };
        }
        else {
            if ($truncated) {
                push @bioRows, {
                    name        => cstring($client, 'PLUGIN_DISCOGRAPHY_READ_MORE'),
                    type        => 'link',
                    image       => MENU_REVIEW,
                    nextWindow  => 'refresh',
                    id          => 'bio:more',
                    itemActions => _listItemActions($opts, 'bio:more'),
                    passthrough => [{ akey => $akey }],
                    url         => sub {
                        my ($c, $cb, $a, $p) = @_;
                        $lastCtx{ _cid($c) }{bio}{ $p->{akey} } = 1;
                        $cb->({ items => [] });
                    },
                };
            }
        }
    }

    unshift @bioRows, _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_BIOGRAPHY', $useH,
        IMG_BASE . 'dsc-bio_MTL_icon_person.png', \@bioRows,
        { id => 'sect:BIO', itemActions => _listItemActions($opts, 'sect:BIO') }) if @bioRows;
    @bioRows = () if $singlesTab;    # a true tab: Options + Singles only

    # Search rides here too, as a BUTTON that opens its own page (Simon,
    # 2026-09-24): after any artist browse the app re-opens on that artist (the
    # %lastCtx model), so the Apps-view search would be unreachable without it,
    # but an inline search box got lost among the page's other rows, and
    # Material draws it inline or as a popup depending on the page's size.
    # The local-only toggle is offered whenever the user owns anything by this
    # artist (or the filter is already on, so there is always a way back out).
    my @optRows = (($hasAlbums && $hasSingles) ? (_viewToggleItem($client, $opts, $view)) : (),
                   _sortToggleItem($client, $opts),
                   ((@$local || $localOnly) ? (_localOnlyToggleItem($client, $opts)) : ()),
                   _refreshItem($client, $opts, $mbid),
                   _searchButtonRow($client, $opts));
    my @items = (@bioRows,
        _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_OPTIONS', $useH,
            IMG_BASE . 'dsc-opt_MTL_icon_tune.png', \@optRows,
            { id => 'sect:OPT', itemActions => _listItemActions($opts, 'sect:OPT') }),
        @optRows);

    # Which groups the archive has a cover for, once per page (API::peekCoverFlags).
    my $coverFlags = Plugins::Discography::API->peekCoverFlags($mbid);
    for my $g (_groupOrder($useH)) {
        my ($key, $token, $iconName) = @$g;
        my $rels = $bucket{$key} or next;

        # ISO dates sort lexically; undated entries go LAST in either direction
        # (an unknown date shouldn't float to the top of "newest").
        my @dated   = sort { $a->[0]{date} cmp $b->[0]{date} } grep {  length $_->[0]{date} } @$rels;
        my @undated =                                          grep { !length $_->[0]{date} } @$rels;
        @dated = reverse @dated if $sort eq 'newest';

        my @tiles = map { _releaseItem($client, $opts, $_->[0], $_->[1], $coverFlags) } @dated, @undated;

        # Long sections are capped; the header keeps naming the TRUE total, so
        # "Singles (87)" over 30 rows reads as paging, not as a lost release.
        my ($vis, $pgRows, $all) = _sectionTiles($client, $opts, $useH, $key, \@tiles);
        _wantCovers($vis);

        # The divider row is emitted for EVERY client — only its type differs
        # (real header vs text) — so the tree shape (and item_id indexing) is
        # identical however the feed is rebuilt. The image name maps to
        # Material's own release-type svg (and any image keeps the grid toggle
        # available — image-less items disable it page-wide, LBF lesson).
        my $hdr = {
            name  => cstring($client, $token) . ' (' . scalar(@tiles) . ')',
            type  => $useH ? _sectionHeaderType($useH, $key) : 'text',
            image => IMG_BASE . 'dsc_MTL_svg_' . $iconName . '.png',
        };
        if ($useH) {
            # Older Material forces a drill action onto 'header' items; point
            # it at this section's own tiles rather than a dead page.
            # 'header-basic' ignores the url harmlessly.
            my @kids = @$all;
            $hdr->{id}          = 'sect:' . $key;
            $hdr->{itemActions} = _listItemActions($opts, $hdr->{id});
            $hdr->{url}         = sub { _wantCovers(\@kids); $_[1]->({ items => \@kids }) };
            $hdr->{passthrough} = [{}];
        }

        push @items, $hdr, @$vis, @$pgRows;
    }

    # The Singles view is a true tab: nothing below the release sections.
    return \@items if $singlesTab;

    # Safety net: library albums under this artist that NO release group
    # claimed (MB gaps, odd editions, matcher misses) — nothing owned may
    # silently vanish. Claims run across ALL non-hidden-secondary RGs
    # (including type-filtered ones, so hiding e.g. Singles doesn't resurface
    # a matched single here). These tiles ARE the playable node (their feed is
    # the album tracklist), no MB detail to drill to.
    if ($prefs->get('show_library_extras')) {
        my @rgPool = grep {
            my $rg = $_;
            !grep { $HIDE_SECONDARY{$_} } @{ $rg->{secondary} };
        } @$rgs;
        my $claimed = ($local && @$local)
            ? Plugins::Discography::Sources->claimedLocalIds(\@rgPool, $opts->{artist}, $local, $relMap, $editions)
            : {};
        my @extras  = grep { !$claimed->{ $_->{_albumid} } } @{ $local || [] };

        # NOTE: a band's owned albums are NO LONGER folded in here (they used to
        # land in "Appearances" via Sources::bandAlbums, removed 2026-09-30 as
        # dead code). They now live behind
        # the "Also a member of" links section below — browse the band itself to
        # see its discography, rather than mixing it into this solo spine
        # (Simon's call, 2026-07-11). This section is now the artist's OWN library
        # orphans (odd editions, MB gaps) + VA comps/soundtracks they perform on.

        # Why did each orphan miss? mbid NONE = untagged/multi-disc; mbid present
        # but not in relMap = neither the artist browse nor the targeted lookup
        # has resolved it yet (or it's credited to another artist).
        if (@extras) {
            _dbg('library-extras (orphans): relMap=' . scalar(keys %$relMap) . ' releases'
                . ' | ' . join('; ', map {
                      my $mb = $_->{_mbid};
                      ($_->{_candTitle} // '?') . ' mbid=' . ($mb // 'NONE')
                          . ($mb ? ($relMap && exists $relMap->{$mb}
                                      ? '->rg:' . $relMap->{$mb}
                                      : '(not in relMap)') : '')
                  } @extras));
        }

        # Split into two sections:
        #   "Also in your library" — the artist's OWN albums MB's spine missed
        #      (album artist IS this artist).
        #   "Appearances"          — VA comps/soundtracks they only perform on
        #      (album artist is Various/someone else).
        # The album-artist field is the clean signal (verified: Dylan's own
        # albums read "Bob Dylan"; The Big Lebowski reads "Various Composers").
        my $an = Plugins::Discography::Sources::_norm($opts->{artist} // '');
        my (@own, @appear);
        for my $a (@extras) {
            my $ca = Plugins::Discography::Sources::_norm($a->{_candArtist} // '');
            # No album artist to judge -> keep it in "Also in your library"
            # (fail safe: never demote an unknown to Appearances).
            if (!length $ca || !length $an
                || Plugins::Discography::Sources::_artistMatch($an, $ca)) {
                push @own, $a;
            }
            else {
                push @appear, $a;
            }
        }

        push @items, _extraSection($client, $opts, $useH, $sort,
            'PLUGIN_DISCOGRAPHY_LIBRARY_EXTRAS',
            IMG_BASE . 'dsc-lib_MTL_icon_library_music.png', 'EXTRAS', \@own);
        push @items, _extraSection($client, $opts, $useH, $sort,
            'PLUGIN_DISCOGRAPHY_APPEARANCES',
            IMG_BASE . 'dsc-bio_MTL_icon_person.png', 'APPEAR', \@appear);
    }

    # ---------------------------------------------------------------------
    # "Also on <service>" — the STREAMING safety net.
    #
    # Exactly the same principle as "Also in your library": MusicBrainz is the
    # spine, and anything playable that the spine does not list must not
    # silently vanish. Field case (2026-07-19): MB has ONE release group for
    # the US rapper Manuel Gomez while Deezer carries TEN albums, so nine
    # records were invisible.
    #
    # These rows are the service plugins' OWN rendered nodes, so they browse
    # and play natively — no MB detail page to drill into, same as a library
    # extras tile.
    #
    # Depends on _filterForeignArtist: without it Qobuz's ~20 appears-on
    # entries by OTHER artist ids would land here as this artist's records.
    # ---------------------------------------------------------------------
    # Suppressed in local_only mode: an unclaimed STREAMING record is by
    # definition not owned, so it has no place in a "what you own" view.
    if (!$localOnly && $prefs->get('show_streaming_extras')) {
        my @unclaimed;
        for my $svc (map { $_->{name} } @$sources) {
            next if $svc eq 'Local';
            my $claimed = $claimedSvc{$svc} || {};
            for my $it (@{ $pool->{bySvc}{$svc} || [] }) {
                next unless defined $it->{_albumid};
                next if $claimed->{ $it->{_albumid} };
                # A JOINT artist's record (Sources::_searchQobuz, 0.56.13) is in
                # the pool only to match a release MusicBrainz lists here; one
                # it does not list is that joint act's, not this artist's.
                next if $it->{_joint};

                # CREDIT GATE. The pool is what a service returned for the
                # artist SEARCH, which includes records by other acts with
                # similar names and by bands this artist merely belongs to
                # (field, 2026-07-19: Sonic Boom's section listed Experimental
                # Audio Research releases). A matched release is verified by
                # the MB spine; an UNCLAIMED one has nothing vouching for it,
                # so it must at least be credited to this artist. Token-subset,
                # so "Panda Bear & Sonic Boom" still counts as his.
                #
                # LIMIT (measured 2026-07-19, do not mistake this for a bug to
                # fix here): this gate compares NAMES, so it is powerless when
                # the intruder shares the artist's name. Qobuz files at least
                # five different "Madness" acts under one artist id, all
                # credited "Madness", and 90 of that entity's 139 albums are
                # not the ska band's. Nothing available separates them — see
                # the show_streaming_extras note in Plugin.pm for the three
                # signals tested and why each fails. Hence the pref now
                # defaults OFF and the section is labelled unverified.
                # Credited under another of the artist's MusicBrainz names
                # counts too (C3), as it does for the release matching above.
                next unless Plugins::Discography::Sources::_artistMatch(
                    $artistNorm,
                    Plugins::Discography::Sources::_norm($it->{_candArtist} // ''))
                    || @{ Plugins::Discography::Sources::_otherNamesFor(
                              $artistNorm, $otherNames, $it->{_candArtist}, \%creditMemo) };

                my %t = %$it;
                $t{_svc} = $svc;   # line2 is built after the cross-service merge
                # The service badge (_extid). The merge below keeps the FIRST
                # copy, the preferred service's, so the badge names the one that plays.
                my $extid = _extid(\%t);
                $t{extid} = $extid if defined $extid;
                # Self-identifying go (stale-view fix): WITHOUT this the row
                # sends a positional item_id, the feed is rebuilt, and the click
                # lands on whatever now sits at that index — field 2026-07-19,
                # "Help Me Please" opened Experimental Audio Research's
                # "Phenomena 256". Every other actionable row here is
                # param-addressed; these were not.
                $t{id}          = 'str:' . $svc . ':' . $t{_albumid};
                $t{itemActions} = _listItemActions($opts, $t{id}, $t{play});
                push @unclaimed, \%t;
            }
        }
        # DEDUPE ACROSS SERVICES, as a matched release already does: one row per
        # album naming every service that carries it, not one row per service
        # (field, 2026-07-19: "Bajo Tu Voz · Tidal" directly above "Bajo Tu Voz
        # · Qobuz"). Keyed on title+year, so genuinely different records that
        # share a title stay apart. The FIRST occurrence wins the row, and the
        # loop above runs in source-priority order, so the preferred service
        # supplies the node that plays.
        #
        # TWO keys (2026-09-25). The title must come from _candTitle, not the
        # rendered `name`: only Tidal and Deezer put the bare title in `name`;
        # Qobuz renders "Artist - Title" and Spotty "Title BY Artists" (read in
        # their sources), so a Qobuz or Spotify copy never merged with anything.
        # But `name` stays the key WITHIN a service, so two copies one service
        # lists separately (same title and year, different credit) stay apart,
        # exactly as before. Hence:
        #   1. same name+year as a row already built -> join it (the old rule);
        #   2. else same title+year as a row with NO copy from this service ->
        #      join it (the cross-service merge);
        #   3. else a row of its own.
        # A copy with no _candTitle is keyed on its name, as before.
        # Pinned in tools/t_extras.pl.
        my (@merged, %byName, %byTitle);
        for my $t (@unclaimed) {
            my $year  = $t->{_year} // '';
            my $name  = Plugins::Discography::Sources::_norm($t->{name} // '');
            my $title = Plugins::Discography::Sources::_norm($t->{_candTitle} // '');
            $title = $name unless length $title;
            my $svc   = $t->{_svc} // '';
            my $have  = $byName{"$name|$year"}
                     || (grep { !$_->{_svcHeld}{$svc} } @{ $byTitle{"$title|$year"} || [] })[0];
            if ($have) {
                push @{ $have->{_svcs} }, $t->{_svc} if $t->{_svc};
                $have->{_svcHeld}{$svc} = 1;
                $byName{"$name|$year"} ||= $have;
                next;
            }
            $t->{_svcs}    = [ $t->{_svc} ? $t->{_svc} : () ];
            $t->{_svcHeld} = { $svc => 1 };
            $byName{"$name|$year"} = $t;
            push @{ $byTitle{"$title|$year"} }, $t;
            push @merged, $t;
        }
        for my $t (@merged) {
            delete $t->{_svcHeld};   # merge bookkeeping only
            my %seen;
            my @svcs = grep { !$seen{$_}++ } @{ $t->{_svcs} || [] };
            $t->{line2} = join(" \x{00B7} ",
                grep { length } ($t->{_year} // ''), join('/', @svcs));
        }
        @unclaimed = @merged;

        if (@unclaimed) {
            my @dated   = sort { ($a->{_year} || 0) <=> ($b->{_year} || 0) }
                          grep {  $_->{_year} } @unclaimed;
            my @undated = grep { !$_->{_year} } @unclaimed;
            @dated = reverse @dated if $sort eq 'newest';
            my @tiles = (@dated, @undated);

            my ($vis, $pgRows, $all) = _sectionTiles($client, $opts, $useH, 'STREAM', \@tiles);
            my $hdr = {
                name  => cstring($client, 'PLUGIN_DISCOGRAPHY_STREAM_EXTRAS')
                       . ' (' . scalar(@tiles) . ')',
                type  => $useH ? _sectionHeaderType($useH, 'STREAM') : 'text',
                image => IMG_BASE . 'dsc-lib_MTL_icon_library_music.png',
            };
            if ($useH) {
                my @kids = @$all;
                $hdr->{id}          = 'sect:STREAM';
                $hdr->{itemActions} = _listItemActions($opts, $hdr->{id});
                $hdr->{url}         = sub { $_[1]->({ items => \@kids }) };
                $hdr->{passthrough} = [{}];
            }
            push @items, $hdr, @$vis, @$pgRows;
        }
    }

    # "Also a member of" — LINKS to the discography of each band/project this
    # artist belongs to (MusicBrainz "member of band"; API::peekBands, warmed in
    # the MB chain). Shown regardless of show_library_extras: it's navigation,
    # not library content. Cache-cold on the very first render -> appears on
    # re-entry (same second-load contract as bootlegs/emblems). LAST section, so
    # a cold->warm flip only ever adds trailing rows — nothing above shifts.
    my $bands = Plugins::Discography::API->peekBands($mbid);
    if ($bands && @$bands) {
        push @items, _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_ALSO_MEMBER_OF',
            $useH, IMG_BASE . 'dsc-bio_MTL_icon_person.png',
            [ map { _bandLinkRow($client, $opts, $_) }
                sort { lc($a->{name}) cmp lc($b->{name}) } @$bands ],
            { id => 'sect:BANDS', itemActions => _listItemActions($opts, 'sect:BANDS') });
        push @items, map { _bandLinkRow($client, $opts, $_) }
            sort { lc($a->{name}) cmp lc($b->{name}) } @$bands;
    }

    # "Collaborations" — MusicBrainz collaboration links (a duo or side project
    # the artist is recorded as a COLLABORATOR on, not a member of: Holly
    # Golightly -> "Holly Golightly and The Brokeoffs"). Vetted in the SAME
    # warm as the bands (API::_vetCollabs drops charity supergroups and dead
    # entities), same drill, same second-load contract, and placed after the
    # bands so a cold->warm flip still only adds rows below.
    my $collabs = Plugins::Discography::API->peekCollabs($mbid);
    if ($collabs && @$collabs) {
        my @sorted = sort { lc($a->{name}) cmp lc($b->{name}) } @$collabs;
        push @items, _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_COLLABORATIONS',
            $useH, IMG_BASE . 'dsc-bio_MTL_icon_person.png',
            [ map { _bandLinkRow($client, $opts, $_) } @sorted ],
            { id => 'sect:COLLABS', itemActions => _listItemActions($opts, 'sect:COLLABS') });
        push @items, map { _bandLinkRow($client, $opts, $_) } @sorted;
    }

    # "Similar artists" — MAI/Last.fm related artists, each a DRILL into that
    # artist's discography (identical behaviour to an "Also a member of" link,
    # only resolved by NAME rather than a known mbid). Same second-load contract
    # as the bands section (peek is cache-only; warmed after the first render ->
    # appears on re-entry) and it sits AFTER bands as the LAST section, so a
    # cold->warm flip only adds trailing rows. Kept in MAI's relevance order.
    # NB the CACHE is mbid-keyed but the DATA is not: _warmSimilarArtists asks
    # Last.fm (via MAI) by NAME, so a shared-name act's key holds the prominent
    # act's similar artists. Suppress rather than show the wrong band's peers.
    #
    # AN ARTIST ALREADY LISTED AS A BAND IS DROPPED HERE (0.51.1) — and it is
    # not merely tidiness, it is what makes the BANDS row exist at all.
    #
    # FIELD (Simon, screenshot): Frank Zappa's "Also a member of" showed Ned and
    # Nelda / Ruben and the Jets / The Midnighters, with **The Mothers of
    # Invention missing** — while the identical name rendered fine under
    # Similar artists. The feed was never at fault: the SlimBrowse response
    # carries all four band rows (verified live, `menu:1`, both sections). The
    # row is lost in MATERIAL, and only when the plugin is entered from My Apps:
    #
    #   * `browse-resp.js` sets `isApps` from the parent's section, and every
    #     descendant inherits it — so the whole app path takes the Apps id
    #     ladder: `params.item_id` -> `presetParams.favorites_url` ->
    #     `actions.go.params.item_id` -> **`parent.id + "." + i.title`**.
    #   * OUR link rows carry NONE of the first three. `params.item_id` is
    #     emitted by XMLBrowser only for PLAYABLE items (XMLBrowser.pm: the
    #     `$isPlayable || $touchToPlay` gate), a favurl only for playable ones,
    #     and our self-identifying `go` (the stale-view fix) deliberately sends
    #     artist/mbid INSTEAD of an item_id. So the id falls back to the TITLE.
    #   * Two rows with the same title therefore get the SAME id, and the list
    #     is keyed `:key="item.id"` — duplicate Vue keys, one tile rendered.
    #     The later section wins, which is exactly what the screenshot shows.
    #
    # Album tiles are immune (playable -> real `params.item_id`), so this can
    # only ever bite the non-playable navigation rows, i.e. these two sections.
    # Material can't be changed from here (no-patch constraint), and the drill
    # is IDENTICAL either way, so the duplicate is worth nothing to keep: the
    # BAND row wins, because membership is asserted MusicBrainz data while
    # Last.fm "similar" is a suggestion — and a band the artist is actually IN
    # is a strange thing to file under "similar" in the first place.
    # Collaborations are navigation rows keyed by title too, so they count.
    my $similar = _dropBandDupes(
        ($opts->{shared_name} ? undef : _peekSimilar($mbid)),
        [ @{ $bands || [] }, @{ $collabs || [] } ]);
    if ($similar && @$similar) {
        push @items, _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_SIMILAR_ARTISTS',
            $useH, IMG_BASE . 'dsc-bio_MTL_icon_person.png',
            [ map { _similarLinkRow($client, $opts, $_) } @$similar ],
            { id => 'sect:SIMILAR', itemActions => _listItemActions($opts, 'sect:SIMILAR') });
        push @items, map { _similarLinkRow($client, $opts, $_) } @$similar;
    }

    return \@items;
}

# One "Also a member of" row: a DRILL-IN that renders the band's own discography
# as a nested sub-feed. (An earlier "re-stash %lastCtx + nextWindow refresh"
# design did NOT work: a refresh re-issues the person's TOP command WITH its
# artist params — 0.8.1 — which clobbers the band stash before it's read, so the
# view bounced straight back to the person. A drill-in instead renders the band
# inline via its own coderef, entered by mbid.) Each deeper click re-walks THROUGH
# this coderef, which deterministically re-renders the band, so nested navigation
# (band -> release detail) stays consistent. The band's library contributor id is
# resolved lazily (only on click) for exact local matching; absent when the band
# isn't owned (localAlbums' name fallback covers it).
# KNOWN LIMIT: toggles that refresh the TOP view (bio "Read more", section "Show
# more" paging) land on the PERSON, since a top refresh re-sends the person's
# params. Browse / sort / Refresh / drill-into-a-release all work. A band as a
# true top-level view (all toggles working) needs a fresh top command with the
# band's params, which a feed item can't emit from within — future work.
sub _bandLinkRow {
    my ($client, $opts, $band) = @_;
    return {
        name        => $band->{name},
        type        => _artistRowType($opts->{features}),
        # MAI image-proxy URL: the photo loads asynchronously in-view.
        image       => _artistImg($band->{name}),
        # Self-identifying go (stale-view fix): enters the band as a fresh
        # top-level view via the direct-mbid path — durable and, as a bonus,
        # retires the 0.26.1 known limit (top toggles landing on the person).
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => { mbid => $band->{mbid}, artist => $band->{name},
                (length($opts->{features} // '') ? (features => $opts->{features}) : ()) } } },
        passthrough => [{ band_mbid => $band->{mbid}, band_name => $band->{name},
                          features => $opts->{features} }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            my $bid = Plugins::Discography::Sources::_bandContributorId(
                $p->{band_mbid}, $p->{band_name});
            _dbg("band drill -> '$p->{band_name}' (mbid $p->{band_mbid}, artist_id "
                . ($bid // '-') . ')');
            _discographyView($c, $cb, {
                artist_id => $bid,
                artist    => $p->{band_name},
                mbid      => $p->{band_mbid},
                features  => $p->{features},
                sort      => $prefs->get('sort_order') || 'newest',
                force     => 0,
            });
        },
    };
}

# Similar-artist NAMES minus anything already shown under "Also a member of".
# Compared with the matcher's `_norm`, so a spelling difference between MB and
# Last.fm ("The Mothers of Invention" / "Mothers of Invention") still counts as
# the same act. Undef/empty in, undef/empty out; no bands = unchanged list.
# See the section comment in _buildList for WHY this is load-bearing rather
# than cosmetic (Material keys app rows by title).
sub _dropBandDupes {
    my ($similar, $bands) = @_;
    return $similar unless ref $similar eq 'ARRAY' && @$similar
                        && ref $bands   eq 'ARRAY' && @$bands;
    my %isBand = map { (Plugins::Discography::Sources::_norm($_->{name} // '') => 1) }
                 grep { ref $_ eq 'HASH' } @$bands;
    delete $isBand{''};
    return $similar unless keys %isBand;
    my @sim = grep {
        my $k = Plugins::Discography::Sources::_norm($_ // '');
        $k eq '' || !$isBand{$k};
    } @$similar;
    _dbg('similar: dropped ' . (scalar(@$similar) - scalar(@sim))
         . ' name(s) already shown under "Also a member of"')
        if @sim < @$similar;
    return \@sim;
}

# One "Similar artists" row: the SAME drill-in as a band link, but entered by
# NAME (these come from Last.fm with no mbid). The paramless person path
# (_resolveArtistMbid -> getArtistMbid) resolves the name exactly like a
# top-level entry, so browse / sort / Refresh / drill-into-a-release all work;
# an owned similar artist matches locally via localAlbums' name fallback.
# Image = MAI image-proxy URL, loads asynchronously in-view.
sub _similarLinkRow {
    my ($client, $opts, $name) = @_;
    return {
        name        => $name,
        type        => _artistRowType($opts->{features}),
        image       => _artistImg($name),
        # Self-identifying go (stale-view fix): fresh top-level entry by name.
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => { artist => $name,
                (length($opts->{features} // '') ? (features => $opts->{features}) : ()) } } },
        passthrough => [{ sim_name => $name, features => $opts->{features} }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            _dbg("similar drill -> '$p->{sim_name}'");
            _discographyView($c, $cb, {
                artist   => $p->{sim_name},
                features => $p->{features},
                sort     => $prefs->get('sort_order') || 'newest',
                force    => 0,
            });
        },
    };
}

# One library section ("Also in your library" or "Appearances"): year-sorted
# tiles, paged, with a walk-stable header. A band album names its band in line2,
# everything else says Local. Returns the feed rows (empty list when no albums).
sub _extraSection {
    my ($client, $opts, $useH, $sort, $token, $image, $pageKey, $albums) = @_;
    return () unless $albums && @$albums;

    my @dated   = sort { ($a->{_year} || 0) <=> ($b->{_year} || 0) } grep {  $_->{_year} } @$albums;
    my @undated =                                                    grep { !$_->{_year} } @$albums;
    @dated = reverse @dated if $sort eq 'newest';

    my @tiles = map {
        my %t = %$_;
        $t{line2} = join(" \x{00B7} ", grep { length } ($t{_year} // ''), ($t{_band} // 'Local'));
        # Self-identifying go + play (stale-view fix): the tile IS the playable
        # node (its feed = the album tracklist, play = a core-resolved db: url),
        # so go dispatches by id and play/add/insert carry the db: url directly.
        if ($t{_albumid}) {
            $t{id} = 'lib:' . $t{_albumid};
            $t{itemActions} = _listItemActions($opts, $t{id}, $t{play});
        }
        \%t;
    } @dated, @undated;

    my ($vis, $pgRows, $all) = _sectionTiles($client, $opts, $useH, $pageKey, \@tiles);

    my $hdr = {
        name  => cstring($client, $token) . ' (' . scalar(@tiles) . ')',
        type  => $useH ? _sectionHeaderType($useH, $pageKey) : 'text',
        image => $image,
    };
    if ($useH) {
        my @kids = @$all;
        $hdr->{id}          = 'sect:' . $pageKey;
        $hdr->{itemActions} = _listItemActions($opts, $hdr->{id});
        $hdr->{url}         = sub { $_[1]->({ items => \@kids }) };
        $hdr->{passthrough} = [{}];
    }
    return ($hdr, @$vis, @$pgRows);
}

# Section paging. Sections run long (Singles reaches the hundreds), so each is
# capped at PAGE_SIZE rows and grown a page at a time by a "Show more" row —
# the bio's refresh-toggle with a COUNT in the ctx instead of a boolean.
#
# Two properties this depends on:
#   - The row carries its target as an ABSOLUTE count, never "+= PAGE_SIZE".
#     Every deeper click re-executes the whole item_id path, so a relative
#     bump could advance the page more than once (the plugin-wide idempotence
#     rule). Paging rows are leaves, but absolute targets make that irrelevant.
#   - `page` survives the fresh-entry ctx reset in topLevel (same-artist
#     branch): these rows refresh the TOP view, whose re-fetch carries the
#     artist params, so it lands there.
#
# Cap also keeps typical views under Material's LMS_MAX_NON_SCROLLER_ITEMS
# (100), above which the fixed-row RecycleScroller clips tall text rows (bio).
#
# Returns (visible tiles, paging rows) — both go in the tree in that order.
sub _pageSection {
    my ($client, $opts, $key, $tiles) = @_;

    my $total = scalar @$tiles;
    return ($tiles, []) if $total <= PAGE_SIZE;

    my $ctx   = $lastCtx{ _cid($client) } ||= {};
    my $shown = $ctx->{page}{$key} || PAGE_SIZE;
    $shown = $total if $shown > $total;

    my @rows;
    if ($shown < $total) {
        my $next = $shown + PAGE_SIZE;
        $next = $total if $next > $total;
        push @rows, _pageRow($client, $opts, $key, $next,
            cstring($client, 'PLUGIN_DISCOGRAPHY_SHOW_MORE') . ' (' . ($total - $shown) . ')',
            PAGE_MORE);
    }
    if ($shown > PAGE_SIZE) {
        push @rows, _pageRow($client, $opts, $key, PAGE_SIZE,
            cstring($client, 'PLUGIN_DISCOGRAPHY_SHOW_LESS'), PAGE_LESS);
    }

    return ([ @$tiles[ 0 .. $shown - 1 ] ], \@rows);
}

sub _pageRow {
    my ($client, $opts, $key, $target, $name, $image) = @_;
    my $id = "page:$key:$target";
    return {
        name        => $name,
        type        => 'link',
        image       => $image,
        nextWindow  => 'refresh',
        id          => $id,
        itemActions => _listItemActions($opts, $id),
        passthrough => [{ key => $key, target => $target }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            my $ctx = $lastCtx{ _cid($c) } ||= {};
            # Collapsing back to the cap clears the key rather than storing the
            # default, so an unpaged section leaves no ctx residue.
            if ($p->{target} <= PAGE_SIZE) { delete $ctx->{page}{ $p->{key} } }
            else                           { $ctx->{page}{ $p->{key} } = $p->{target} }
            $cb->({ items => [] });
        },
    };
}

# The Albums | Singles view toggle (Simon, 2026-09-24): ONE cycling row, LBF's
# "Showing ..." pattern — Material gives a plugin list no side-by-side layout,
# so there are no real tabs. The icon shows the CURRENT view, the label names
# both. It flips IN PLACE: the row sets the ctx flag to an ABSOLUTE target
# (idempotent under a re-walk) and nextWindow refreshes the artist's own
# command, whose same-artist fresh entry keeps `view` (like the bio's flag).
# The target rides in the ID too (act:view:<to>, like bio:more / page:<KEY>:<n>):
# a tap is dispatched by rebuilding the page from the SERVER's current view, so a
# fixed id would run the rebuilt row and flip relative to that state. A stale tap
# (double tap, a second window) now misses _findRow and changes nothing.
sub _viewToggleItem {
    my ($client, $opts, $view) = @_;
    my $singles = ($view // '') eq 'singles' ? 1 : 0;
    my $now  = cstring($client, $singles ? 'PLUGIN_DISCOGRAPHY_SINGLES_EPS' : 'PLUGIN_DISCOGRAPHY_ALBUMS');
    my $next = cstring($client, $singles ? 'PLUGIN_DISCOGRAPHY_ALBUMS'      : 'PLUGIN_DISCOGRAPHY_SINGLES_EPS');
    my $to   = $singles ? 'albums' : 'singles';
    return {
        name        => sprintf(cstring($client, 'PLUGIN_DISCOGRAPHY_SHOWING'), $now, $next),
        type        => 'link',
        image       => IMG_BASE . 'dsc_MTL_svg_' . ($singles ? 'release-single' : 'release-album') . '.png',
        nextWindow  => 'refresh',
        id          => "act:view:$to",
        itemActions => _listItemActions($opts, "act:view:$to"),
        passthrough => [{ to => $to }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            $lastCtx{ _cid($c) }{view} = ($p->{to} // '') eq 'singles' ? 'singles' : 'albums';
            $cb->({ items => [] });
        },
    };
}

# Action rows live at the TOP of the feature's own view (fleet convention).
# Both re-enter _discographyView via passthrough with adjusted opts.
sub _sortToggleItem {
    my ($client, $opts) = @_;
    my $newest = ($opts->{sort} || 'newest') eq 'newest';
    my $flip   = $newest ? 'oldest' : 'newest';
    return {
        name        => cstring($client, $newest ? 'PLUGIN_DISCOGRAPHY_SORT_NEWEST'
                                                : 'PLUGIN_DISCOGRAPHY_SORT_OLDEST'),
        type        => 'link',
        image       => MENU_SORT,
        # Self-identifying go (stale-view fix): a FRESH entry with an explicit
        # sort param — same drill-in UX (new level, back returns), and the
        # opened view's own rows/toggles re-issue the sorted command, so the
        # order sticks throughout that view.
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => { _identParams({ %$opts, sort => $flip }) } } },
        passthrough => [{ %$opts, sort => $flip }],
        url         => sub {
            my ($c, $cb, $a, $pass) = @_;
            _discographyView($c, $cb, $pass);
        },
    };
}

# Local-only view toggle — same mechanics as the sort toggle: a FRESH entry
# with an explicit local_only param (drill-in UX; back returns), and the opened
# view's own rows re-issue the command with the flag via _identParams, so it
# sticks. The label names the ACTION (what tapping does), not the current state.
sub _localOnlyToggleItem {
    my ($client, $opts) = @_;
    my $on   = $opts->{local_only} ? 1 : 0;
    my $flip = $on ? 0 : 1;
    return {
        name        => cstring($client, $on ? 'PLUGIN_DISCOGRAPHY_SHOW_ALL_SOURCES'
                                            : 'PLUGIN_DISCOGRAPHY_SHOW_LOCAL_ONLY'),
        type        => 'link',
        image       => MENU_LOCAL,
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => { _identParams({ %$opts, local_only => $flip }) } } },
        passthrough => [{ %$opts, local_only => $flip }],
        url         => sub {
            my ($c, $cb, $a, $pass) = @_;
            _discographyView($c, $cb, $pass);
        },
    };
}

# Refresh is NOT a drill-in (LBF's pattern): clear the cache, return empty
# with nextWindow=>'refresh', and the client re-fetches the PARENT view — which
# still carries the artist params. A drill-in Refresh would also poison later
# navigation: every subsequent item_id walk would pass back through it and
# re-clear the cache on every click.
sub _refreshItem {
    my ($client, $opts, $mbid) = @_;
    return {
        name        => cstring($client, 'PLUGIN_DISCOGRAPHY_REFRESH'),
        type        => 'link',
        image       => MENU_REFRESH,
        nextWindow  => 'refresh',
        id          => 'act:refresh',
        itemActions => _listItemActions($opts, 'act:refresh'),
        passthrough => [{ mbid => $mbid, artist => $opts->{artist},
                          artist_id => $opts->{artist_id} }],
        url         => sub {
            my ($c, $cb, $a, $pass) = @_;
            # Full "re-check MusicBrainz": drop EVERY cached layer for this
            # artist — resolution (mbid + '' miss sentinel), release groups,
            # bootleg map, band members, bio, MusicBrainz's name and aliases,
            # the owned releases' groups, and streaming candidates — so the
            # re-entry re-pulls the lot. (A person view re-resolves by name; a
            # band view keeps its stashed mbid, so it re-pulls by mbid.)
            # refresh => 1: the re-entry takes MusicBrainz's own list,
            # awaited, not the first list from ListenBrainz and the community
            # API (0.56.7).
            Plugins::Discography::API->clearArtistCache(
                name => $pass->{artist}, mbid => $pass->{mbid},
                artist_id => $pass->{artist_id}, refresh => 1);
            Plugins::Discography::Sources->clearCandidates($pass->{artist}, $pass->{mbid})
                if defined $pass->{artist} && length $pass->{artist};
            $cb->({ items => [] });
        },
    };
}

# ---------------------------------------------------------------------------
# Global artist search — the plugin-view entry point that doesn't need the
# Material artist context menu.
#
# SUBMISSION IS PARAM-ADDRESSED (0.37.1 — the stale-walk fix, verified live:
# with an artist ctx stashed, the 0.37.0 positional submission walked into the
# artist view's Biography row and rendered "Empty"). The row is a `type =>
# 'search'` item WHOSE go ACTION IS OVERRIDDEN via itemActions: XMLBrowser's
# search branch builds its positional item_id+search action first, but the
# itemActions pass runs AFTER it and replaces `go` while keeping the `input`
# field (Control/XMLBrowser.pm:1188 vs :1274). Material types a row as a
# search input purely from its go-action params carrying the literal
# `__TAGGEDINPUT__` under `search` (browse-resp.js:279) and substitutes the
# typed term into those params on submit (browse-functions.js:2885) — so the
# submitted command is `search:<text>` + features, NO item_id, and topLevel's
# search dispatch renders the results directly: no positional walk, immune to
# whatever ctx is stashed. The url coderef stays for legacy (classic web skin)
# walks, which deliver the text as $args->{search} (XMLBrowser.pm:493).
# The row sits on the home page (_rootView), which the artist view's Options
# button (_searchButtonRow) also opens, so it is reachable in both ctx states.
# ---------------------------------------------------------------------------
sub _searchRow {
    my ($client, $opts) = @_;
    my $features = $opts->{features} // '';
    # line2 names what the search actually covers (the enabled sources, in
    # priority order — same names the result rows use).
    my @srcs = map { $_->{name} } Plugins::Discography::Sources::orderedSources();
    return {
        name        => cstring($client, 'PLUGIN_DISCOGRAPHY_SEARCH'),
        type        => 'search',
        image       => MENU_SEARCH,
        (@srcs ? (line2 => join(" \x{00B7} ", @srcs)) : ()),
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => { search => '__TAGGEDINPUT__',
                (length $features ? (features => $features) : ()) } } },
        passthrough => [{ features => $features }],
        url         => \&_artistSearch,
    };
}

# The artist page's way into search (Simon, 2026-09-24): a plain button that
# opens the plugin's HOME page (_rootView: banner, Find an artist, About, Works
# best with), rather than the search box sitting among the artist page's rows.
# The home page is small, so Material draws its box inline (on a big artist
# page it went popup; see CLAUDE.md, "renders inline OR as a click-to-popup").
# The tap is param-addressed (item:act:search, the Refresh row's route); the
# search row keeps its own param-addressed submission; the home page's other
# rows are display-only (banner, prose, status rows; headers too on Material
# 6.4.3+), so a search never depends on a positional walk.
sub _searchButtonRow {
    my ($client, $opts) = @_;
    my $features = $opts->{features} // '';
    return {
        name        => cstring($client, 'PLUGIN_DISCOGRAPHY_SEARCH'),
        type        => 'link',
        image       => MENU_SEARCH,
        id          => 'act:search',
        itemActions => _listItemActions($opts, 'act:search'),
        passthrough => [{ features => $features }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            $cb->(_rootView($c, $p->{features}));
        },
    };
}

# Decorative banner row: random library ALBUM COVERS as a centred strip
# (0.40.1 — was MAI artist photos, but an artist MAI has no image for
# rendered as a blank/silhouette tile; covers are filtered to albums that
# HAVE artwork, so a blank is impossible, and need no MAI). Cover URLs are
# root-absolute so they resolve from Material's /material/ page. Fresh
# server-side random roll per render. Returns undef (no row) when the
# library has no artwork.
#
# RESPONSIVE COUNT (0.41.0): the server can't know the viewport (one feed
# serves every client; Material's PWA breakpoints never reach plugin rows),
# so the row carries MORE tiles than any screen needs (BANNER_MAX) at a
# FIXED size, and pure CSS shows exactly as many complete tiles as fit:
# flex-wrap pushes what doesn't fit onto a second row, which the one-row
# max-height + overflow:hidden clips. Phone ~3, tablet ~5-6, desktop ~9+,
# self-adjusting on resize/rotation. Hidden tiles cost only local thumbnail
# fetches (LMS-resized, cached).
sub _coverCollageRow {
    my ($client) = @_;
    my $covers = Plugins::Discography::Sources->randomAlbumCovers(BANNER_MAX);
    return undef unless @$covers;
    my $html = "<div style='display:flex;justify-content:center;align-items:center;"
             . "gap:12px;flex-wrap:wrap;max-height:" . BANNER_TILE_PX . "px;"
             . "overflow:hidden;margin:6px 8px'>";
    for my $src (@$covers) {
        $html .= "<img src='$src' style='width:" . BANNER_TILE_PX . "px;height:"
               . BANNER_TILE_PX . "px;border-radius:8px;flex:0 0 auto'/>";
    }
    $html .= '</div>';
    return { name => $html, type => 'text' };
}

# The app-root view — album-cover banner, search, about, and a live
# plugin-status list, in the artist view's own visual language:
# _sectionHeader dividers (real headers under Material w/ features:hi, text
# dividers elsewhere), _proseRow indent for the about text, MTL/_svg icons
# throughout. Status rows are type 'text' + image: XMLBrowser styles text
# rows itemNoAction, so they render as dead one-liner rows with the plugin's
# icon — a status readout, not a control.
sub _rootView {
    my ($client, $features) = @_;
    my $useH = _wantHeaders($features);
    my @items;

    # --- Decorative album-cover banner, re-rolled every open ---
    # A single NON-clickable text row whose v-html is a strip of <img> tags
    # (Simon: decorative only, no drill). The BROWSER composes the collage —
    # no server-side image work (fleet rule: no GD/Imager). Skipped when the
    # library has no artwork. Being a text row it cannot affect grid state
    # beyond what the About prose already does.
    if (my $banner = _coverCollageRow($client)) {
        push @items, $banner;
    }

    # --- Find an artist: under the banner, above About (0.56.24) ---
    # Simon, 2026-10-02: "The search needs to be below the banner but above
    # about discography", and "needs a header too". Was banner -> About ->
    # "Find an artist" (0.39.0). 0.56.22 had put the box first with no header so
    # Material would put the cursor in it: an inline search box is focused only
    # as the list's FIRST row, on a computer (browse-page.js `<text-field
    # :focus="index==0 && !IS_MOBILE">`, read in the 6.4.10.8 the rig serves),
    # and a header is a row. So here it is never focused on arrival.
    my @search = ( _searchRow($client, { features => $features }) );
    push @items,
        _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_SEARCH_HDR', $useH, MENU_SEARCH, \@search),
        @search;

    # --- About ---
    # The second prose row carries bottom padding: a visual gap before the
    # next section, "Works best with" (Simon: the sections butted together).
    # Padding INSIDE the row keeps the item count/shape untouched (walk stability).
    my @about = (
        _proseRow(cstring($client, 'PLUGIN_DISCOGRAPHY_ABOUT_1')),
        _proseRow(cstring($client, 'PLUGIN_DISCOGRAPHY_ABOUT_2'), ';padding-bottom:24px'),
    );
    push @items,
        _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_ABOUT_HDR', $useH, ICON, \@about),
        @about;

    # --- Works best with (live detection) ---
    # ONE dead text row holding a strip of tiles (Simon, 2026-09-24: five
    # stacked rows took too much of the screen). Each tile is the plugin's OWN
    # icon as a badge over its name and a green tick (installed) or muted cross;
    # the role ("Streaming source", ...) is the tile's hover tooltip only (his
    # pick). The strip wraps (flex-wrap), so a phone gets two lines and a wider
    # screen one. A not-installed plugin has no local logo to serve, so its tile
    # shows a grey placeholder and the whole tile is dimmed. Ticks/crosses are
    # HTML entities (the no-non-ASCII-literals rule). These are the LAST rows on
    # the page, so 5 -> 1 moves no row above them (positional walks unaffected).
    # Badge src normalisation (0.42.1, field): _pluginDataFor('icon') is not
    # always a relative path — MAI returns a FULL REMOTE URL (herger.net
    # mai.svg), which a blind '/' prefix mangled into '/https://...' (broken
    # img). Remote icons go through LMS's imageproxy (server-cached,
    # same-origin — verified live: 200 image/svg+xml); relative paths get
    # root-anchored; already-absolute paths pass through.
    my $badgeSrc = sub {
        my ($icon) = @_;
        return undef unless $icon;
        if ($icon =~ m{^https?://}) {
            require URI::Escape;
            return '/imageproxy/' . URI::Escape::uri_escape($icon) . '/image_96x96_f.png';
        }
        return $icon =~ m{^/} ? $icon : "/$icon";
    };
    my $status = sub {
        my ($name, $installed, $roleToken, $img) = @_;
        my $mark = $installed
            ? "<span style='color:#4caf50'>&#10003;</span>"
            : "<span style='opacity:.6'>&#10007;</span>";
        # Tooltip: the role, plus "not installed" when it is not. Built into a
        # single-quoted attribute, so a quote is escaped too (_escHtml leaves it).
        my $tip = cstring($client, $roleToken);
        $tip .= " \x{00B7} " . cstring($client, 'PLUGIN_DISCOGRAPHY_SVC_NOT_DETECTED') unless $installed;
        $tip = _escHtml($tip);
        $tip =~ s/'/&#39;/g;
        my $src   = $badgeSrc->($img);
        my $badge = $src
            ? "<img src='$src' style='width:42px;height:42px;border-radius:8px'/>"
            : "<div style='width:42px;height:42px;border-radius:8px;background:rgba(128,128,128,.25)'></div>";
        return "<div title='$tip' style='width:96px;display:flex;flex-direction:column;align-items:center;"
             . 'gap:6px;text-align:center;font-size:.85em;line-height:1.25'
             . ($installed ? '' : ';opacity:.55') . "'>"
             . $badge
             . '<div>' . _escHtml($name) . " $mark</div>"
             . '</div>';
    };
    # ONE capability probe for the whole section: adapters() walks every
    # service plugin's ->can() surface, and both the icon map and the
    # installed/not-installed status derive from that same list.
    my @adapters = Plugins::Discography::Sources::adapters();
    my %icon     = map { $_->{name} => $_->{icon} } @adapters;
    my @tiles;
    for my $s (@{ Plugins::Discography::Sources::serviceStatus(\@adapters) }) {
        push @tiles, $status->($s->{name}, $s->{installed},
            'PLUGIN_DISCOGRAPHY_ROLE_STREAM', $icon{ $s->{name} });
    }
    my $mai = eval { Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin') } ? 1 : 0;
    push @tiles, $status->('Music & Artist Information', $mai,
        'PLUGIN_DISCOGRAPHY_ROLE_MAI',
        $mai ? Plugins::Discography::Sources::_pluginIcon('Plugins::MusicArtistInfo::Plugin') : undef);
    # Material Skin exposes no plugin icon (_pluginDataFor('icon') is undef) —
    # use the skin's own served asset (verified live: 200).
    my $mat = eval { Slim::Utils::PluginManager->isEnabled('Plugins::MaterialSkin::Plugin') } ? 1 : 0;
    push @tiles, $status->('Material Skin', $mat,
        'PLUGIN_DISCOGRAPHY_ROLE_MATERIAL',
        $mat ? '/material/html/images/icon.png' : undef);
    my @plugins = ({ type => 'text', name =>
        "<div style='display:flex;flex-wrap:wrap;gap:12px 8px;margin:12px 8px 12px 16px'>"
      . join('', @tiles) . '</div>' });
    push @items,
        _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_PLUGINS_HDR', $useH,
            IMG_BASE . 'dsc-opt_MTL_icon_tune.png', \@plugins),
        @plugins;

    return { items => \@items };
}

# Legacy positional entry (classic web skin walk): same view, text from
# $args->{search}.
sub _artistSearch {
    my ($client, $callback, $args, $pt) = @_;
    my $features = ref $pt eq 'HASH' ? ($pt->{features} // '') : '';
    _artistSearchView($client, $callback, $features, $args->{search});
}

# Search every source, merge, render result rows. The MERGED list is cached
# briefly (SEARCH_TTL) so a re-issued identical query (view refresh, legacy
# re-walk) sees the identical ordering even if a service times out the second
# time.
# The spelling to hand a streaming service's artist SEARCH: a name with
# typographic punctuation folded to ASCII, because the services match the plain
# forms. Measured live (2026-07-23): Qobuz's artist search returns "The La's"
# for the STRAIGHT apostrophe (U+0027) but only unrelated junk for MusicBrainz's
# canonical "The La’s" (U+2019). Deliberately NOT _norm — that strips the
# punctuation the services key on (folding "The Las"/"The La's"/"The La’s" all to
# "the las"); this keeps letters, spacing and case and only normalises the marks.
sub _svcQueryName {
    my ($s) = @_;
    return $s unless defined $s;
    $s =~ tr/\x{2018}\x{2019}\x{201A}\x{201B}\x{2032}/'/;      # curly/prime -> '
    $s =~ tr/\x{201C}\x{201D}\x{201E}\x{2033}/"/;              # curly double -> "
    $s =~ s/[\x{2010}-\x{2015}\x{2212}]/-/g;                   # dashes -> hyphen
    $s =~ s/\x{2026}/.../g;                                    # ellipsis
    $s =~ s/\x{00A0}/ /g;                                      # nbsp -> space
    return $s;
}

# THE NAME A PAGE'S STREAMING POOL IS SEARCHED UNDER (0.56.13). The pool is
# keyed by the MusicBrainz artist, so it is built from that artist's own name:
# MusicBrainz's canonical name, folded to the plain marks the services key on
# (_svcQueryName), with the browsed name retried after it. Field (Simon,
# 2026-10-01): "James Yorkston & The Big Eyes Family Players" resolves to James
# Yorkston (a joint credit, API::_creditHead); searched under its own name it
# found Qobuz's joint artist (2 albums) and stored them as James Yorkston's
# pool, and every James Yorkston page then matched only the user's own albums.
# "James Yorkston and friends" (a library name) and a renamed act ("British Sea
# Power" -> "Sea Power") are the same case the other way round.
#
# NOT when the canonical name has no Latin letter and the browsed one does
# ("Кино" for the library's "Kino"): the services file those acts under the
# Latin name, so the browsed name stays first and the canonical one is retried,
# as before. Cache only (peekArtistName); with no canonical name cached, the
# browsed name is searched as before.
# Returns (query or undef, \@aliases). _poolQuery below adds the English name.
sub _poolQueryCanon {
    my ($artist, $mbid, $aliases) = @_;
    my @alias = @{ $aliases || [] };
    my $canon = $mbid ? Plugins::Discography::API->peekArtistName($mbid) : undef;
    return (undef, \@alias) unless defined $canon && length $canon;
    my $an = Plugins::Discography::Sources::_norm($artist // '');
    my $cn = Plugins::Discography::Sources::_norm($canon);
    return (undef, \@alias) if $cn eq $an;
    my @rest = grep { my $n = Plugins::Discography::Sources::_norm($_ // '');
                      $n ne $cn && $n ne $an } @alias;
    # The third value: a Latin name stands in for MusicBrainz's own, so both are
    # asked (getCandidates' `compare`; see _poolQuery below). 0.56.20: the page
    # opened as "Faye Wong" got 4 Qobuz matches where 王菲 got 29, and the pool
    # is the MusicBrainz artist's, so whichever page built it decided both.
    return (undef, [ $canon, @rest ], 1) if $cn !~ /[a-z]/ && $an =~ /[a-z]/;
    return (_svcQueryName($canon), [ $artist, @rest ]);
}

# AND WHEN THE NAME IT WOULD SEARCH HAS NO LATIN LETTER, MusicBrainz's primary
# English alias goes first, that name second (0.56.18). Field (rig, 2026-10-01):
# "米津玄師" is both the page's name and MusicBrainz's, so the rule above had
# nothing to swap; Qobuz settled on another act ("DAOKO × 米津玄師", 0 spine
# titles), Tidal found nothing, and the page read "No releases found" and was
# recorded empty for 7 days, while the "Kenshi Yonezu" page had 5 albums. The
# aliases are fetched only for a name several acts share, so "Kenshi Yonezu" was
# never tried. The Кино rule above, for a name the browse already spells in
# Latin. The native name stays the first retry: an account in Japan may well
# list him as 米津玄師 (Simon, 2026-10-01). Cache only, as above.
# A third value, 1, says a Latin name stands in for one with no Latin letter,
# here or by the Кино rule above: the services then ask BOTH and keep the better
# (getCandidates' `compare`, 0.56.19; 王菲 is two Qobuz artists, one per name).
sub _poolQuery {
    my ($artist, $mbid, $aliases) = @_;
    my ($query, $alias, $compare) = _poolQueryCanon($artist, $mbid, $aliases);
    my $en = $mbid ? Plugins::Discography::API->peekArtistEnglishName($mbid) : undef;
    return ($query, $alias, $compare) unless defined $en && length $en;
    my $first = defined $query ? $query : ($artist // '');
    my $fn = Plugins::Discography::Sources::_norm($first);
    my $nn = Plugins::Discography::Sources::_norm($en);
    return ($query, $alias, $compare) if $fn =~ /[a-z]/ || $nn !~ /[a-z]/;
    my @rest = grep { my $n = Plugins::Discography::Sources::_norm($_ // '');
                      $n ne $nn && $n ne $fn } @$alias;
    return (_svcQueryName($en), [ $first, @rest ], 1);
}

# THE STREAMING LOOKUP'S OPTIONS, the same for the artist page and the release
# page (C5, 2026-10-01): $cb->(\%opt) for Sources::getCandidates. The release
# page used to ask without the shared-name flag and MusicBrainz's aliases, so a
# release page opened after the 3-day pool had expired, for a name several acts
# share, took a lone same-name service artist unchecked (the 0.43.7 shortcut)
# and wrote the pool both pages read.
sub _poolOpts {
    my ($artist, $mbid, $spine, $cb) = @_;

    # FETCHED, not peeked. The same-name set was only ever populated by the
    # plugin's own SEARCH, so an artist entered from the Material context menu
    # - the main entry point - was never known to be ambiguous: no strict
    # verification and no alias retry (field, 2026-07-19: Sonic Boom, FOUR MB
    # artists of that name, resolved to a Qobuz entity holding 2 albums and
    # nothing checked it). Cached 14 days, so this is one MB request per artist
    # per fortnight.
    Plugins::Discography::API->getArtistCandidates($artist, sub {
        my ($cands) = @_;
        my $ambig = ($mbid && $cands && @$cands > 1) ? 1 : 0;

        my $go = sub {
            my ($names) = @_;
            # MB's CANONICAL name is SEARCHED FIRST (0.56.13), the browsed name
            # retried after it (_poolQuery). Before, the canonical name was only
            # the first retry: a renamed act is filed by the services under its
            # CURRENT name ("British Sea Power" must reach Qobuz's "Sea Power"),
            # so it rescued those; but a browsed name that DID find a service
            # artist was kept even when it was another act's, and stored as this
            # artist's pool.
            my ($query, $alias, $compare) = _poolQuery($artist, $mbid, $names);
            $cb->({ spine => $spine, mbid => $mbid,
                    (@$alias ? (aliases => $alias) : ()),
                    ($query ? (query => $query) : ()),
                    ($compare ? (compare => 1) : ()),
                    ambiguous => $ambig });
        };

        # Aliases only for an AMBIGUOUS name, where a failed resolution is
        # expected and the retry is what rescues it. The canonical name above is
        # added regardless -- it is already cached, so it costs no request
        # either way.
        if ($ambig) {
            Plugins::Discography::API->warmArtistAliases($mbid, $go);
        }
        else { $go->(undef) }
    });
}

sub _artistSearchView {
    my ($client, $callback, $features, $q, $part) = @_;

    $q //= '';
    $q =~ s/^\s+|\s+$//g;
    # An unsubstituted placeholder means the client sent the action verbatim
    # without collecting input — treat as empty, never search for the literal.
    $q = '' if $q eq '__TAGGEDINPUT__';
    unless (length $q) { $callback->({ items => [] }); return }

    # v2: 0.37.1 gated results — bypass any cached ungated 0.37.0 lists.
    # v3: `mergeArtistHits` buckets by `_norm`, and the decorative-mark change
    # makes "Layo & Bushwacka!" and "Layo & Bushwacka" bucket TOGETHER. A v2
    # entry holds them as separate rows. Only a 10-minute TTL, but that is
    # exactly the window someone tests the fix in.
    # v11: the cached rows now CARRY the ranking keys (`_seq`/`_exact`), which
    # the post-attach re-rank reads. A v10 entry has neither, so every row would
    # re-rank as non-exact — a worse order than before, for the ten minutes
    # someone is testing this in.
    my $ckey = 'dsc:asearch:11:' . lc $q;
    utf8::encode($ckey) if utf8::is_utf8($ckey);

    # Both the cached and the fresh path finish the same way: the Top Result
    # and Artists sections, the MusicBrainz same-name acts among the artists
    # (see _withMbCandidates and _searchSections).
    my $finish = sub {
        my ($merged) = @_;
        _withMbCandidates($client, $callback, $features, $q, $merged, $part);
    };

    if (my $cached = $cache->get($ckey)) {
        _dbg("artist search '$q': cached (" . scalar(@$cached) . ' merged)');
        $finish->($cached);
        return;
    }

    # SECOND PASS UNDER MUSICBRAINZ'S CANONICAL NAME (0.45.2).
    #
    # Field (Simon): searching "British Sea Power" returned the row WITHOUT
    # Qobuz, while entering the same artist from the Artists list resolved all
    # three services. The band renamed to "Sea Power", so the services file it
    # under the NEW name; Tidal and Deezer absorb the old one, Qobuz does not.
    # 0.45.0 fixed exactly this for the BROWSE path (getCandidates) -- but
    # searchArtists is a SEPARATE path and did not get it. Simon's rule, and it
    # is the right one: "we need to ensure all fixes we do for matching are done
    # across matching from the rows in Artists and via our search."
    #
    # So: resolve the TYPED query to an MB artist (cached 30d, and this is the
    # same lookup the rows do anyway), and if MB's canonical name differs, run
    # the service legs again under it and merge both result sets before ranking.
    # Bounded -- ONE extra round, only when the name actually differs, which is
    # the rename/alias case alone.
    my $runMerge = sub {
        my ($bySvc, $failed, $canon) = @_;
        # $canon is passed ONLY when the second pass actually ran, so the
        # relevance gate judges those hits against the name they were fetched
        # under (0.46.4). Without it Deezer's "The B-52's" was discarded from a
        # "b52s" search while Qobuz/Tidal survived on a spelling coincidence.
        my $merged = Plugins::Discography::Sources->mergeArtistHits(
            $q, $bySvc, undef, ($canon ? [$canon] : undef));
        my @bad    = sort keys %{ $failed || {} };
        _dbg("artist search '$q': " . scalar(@$merged) . ' merged from '
            . join(',', map { "$_=" . scalar(@{ $bySvc->{$_} }) } sort keys %$bySvc)
            . (@bad ? ' | FAILED: ' . join(',', @bad) : ''));
        # Only persist a COMPLETE result set. A service that errored or timed
        # out contributed an empty list, so caching here would pin the degraded
        # ordering for SEARCH_TTL and every retry inside the window would be
        # served from cache without re-searching (0.42.2). The user still sees
        # what did come back — it just isn't remembered, so retrying works.
        if (@bad) {
            _dbg("artist search '$q': NOT cached (incomplete)");
        }
        else {
            $cache->set($ckey, $merged, SEARCH_TTL);
        }
        $finish->($merged);
    };

    # THE TYPED QUERY'S MUSICBRAINZ LOOKUP RUNS ALONGSIDE THE SERVICE SEARCH
    # (stage 3 review, 2026-09-30), and the rest waits for BOTH. It needs only
    # the query, never the services' answer; started after them it added its
    # whole time to every new search (a round trip when the name is found at
    # once, 2-3 s when it needs the alias or unquoted pass), where alongside
    # them it is usually done before they are. Each callback fires exactly
    # once, in either order, and either may fire at once (a cached name).
    #
    # ON EVERY SETUP SINCE STAGE 3 (2026-09-30). This was skipped on the
    # public API from 0.45.2, a gate CLAUDE.md's top rule makes a defect:
    # "British Sea Power" found no Qobuz row there (verified live). Asked at
    # NAME_FETCH (15) entries, as a page asks: the same-name acts below
    # reads this very reply, and so does the row check's first pass whenever
    # it is the whole result (API::_nameSearch, _rowBatch).
    my ($svcAns, $mbDone, $mbid, $joined);
    my $both = sub {
        return if !$svcAns || !$mbDone || $joined++;
        my ($bySvc, $failed) = @$svcAns;
        my $canon = $mbid
            ? Plugins::Discography::API->peekArtistName($mbid) : undef;
        # The spelling to actually search the services under (see
        # _svcQueryName): MB's canonical name with typographic marks folded
        # to ASCII. _norm MUST NOT gate this — it discards the very
        # punctuation the services key on, so "The Las" and MB's "The La’s"
        # both fold to "the las" and the pass was skipped as "same as typed",
        # leaving Qobuz (which only matches the straight-apostrophe form)
        # permanently absent from the row.
        my $svcName = _svcQueryName($canon);

        # Nothing to add: no MB artist, or the service spelling of the
        # canonical name IS what the first pass already searched (case-only
        # difference; also the straight-apostrophe query whose first pass
        # already matched). This gate is STRICTLY WIDER than the old _norm
        # one — _norm folds more than _svcQueryName, so _norm-equal implies
        # svcName-equal — hence it can only ADD second passes, never drop one.
        if (!$canon || lc($svcName) eq lc($q)) {
            return $runMerge->($bySvc, $failed);
        }

        _dbg("artist search '$q': MB canonical '$canon' (service spelling "
             . "'$svcName') differs from the query - searching services under it too");
        Plugins::Discography::Sources->searchArtists($client, $svcName, sub {
            my ($bySvc2, $failed2) = @_;
            # Union per service. mergeArtistHits buckets by _norm, so a
            # duplicate hit collapses into the same row rather than
            # doubling it; this only ever ADDS services to that row.
            for my $svc (keys %$bySvc2) {
                push @{ $bySvc->{$svc} ||= [] }, @{ $bySvc2->{$svc} || [] };
            }
            # A failure in EITHER pass makes the set incomplete, so the
            # merged list must not be cached (0.42.2's rule, unchanged).
            $failed->{$_} = 1 for keys %{ $failed2 || {} };
            $runMerge->($bySvc, $failed, $canon);
        });
    };

    Plugins::Discography::API->getArtistMbid(artist => $q,
        fetch  => Plugins::Discography::API::NAME_FETCH(),
        onDone => sub { ($mbid) = @_; $mbDone = 1; $both->() });
    Plugins::Discography::Sources->searchArtists($client, $q, sub {
        $svcAns = [ @_ ];
        $both->();
    });
}

# ---------------------------------------------------------------------------
# SAME-NAME ARTISTS FROM MUSICBRAINZ
#
# THE PROBLEM (field, 2026-07-18): several DIFFERENT acts share one name, and
# only one of them was reachable. Searching "Madness" found the ska band on
# every service; the seven other MB artists called Madness — a horrorcore
# rapper, a US funk rock group, an Indiana black metal band — could not be
# reached at all, and every route into the plugin (name search, or Search Hub
# handing off by name) landed on the SAME prominent act. Wrong discography, no
# way to correct it.
#
# The streaming services cannot fix this: their search returns whichever acts
# they happen to carry, under one indistinguishable name. MusicBrainz can — it
# models them as separate artists WITH disambiguation comments, which is the
# only thing that makes them tellable apart in a list.
#
# So the search results list every MB artist of that name, each labelled with
# its comment ("English pop/ska band" / "Horrorcore rapper, member of Bedlam").
# Each row enters by MBID, skipping name resolution entirely — which is the
# whole point, since the name is exactly what cannot distinguish them. Since
# 0.56.10 they lead the Artists section rather than a section of their own
# ("Other artists with this name"; Simon, 2026-10-01), see _searchSections.
#
# Listed only when MB has MORE THAN ONE artist by the name: a single candidate
# is the act the streaming rows already lead to, and repeating it would just be
# a duplicate row. The MB lookup is cached (14d), so this costs one request per
# name and nothing on a repeat search.
# ---------------------------------------------------------------------------
sub _withMbCandidates {
    my ($client, $callback, $features, $q, $merged, $part) = @_;

    # Every way out of the list: one row per title, as Material counts rows
    # (see _distinctTitles).
    my $reply = sub { $callback->({ items => _distinctTitles($_[0]) }) };

    # Attach owned artists the Local leg could not spell-match, BEFORE anything
    # else looks at the rows (see Sources::attachLibraryArtists for the "The
    # Las" case this exists for). Deliberately here rather than beside the
    # merge: both the cached and the fresh path funnel through this sub, so a
    # row served from the 10-minute search cache is judged against the library
    # as it is NOW. It also runs ahead of filterRowsWithContent, whose MB alias
    # attach is guarded on `!$artist_id` — so this makes that path do LESS
    # work, not more, and it works on public installs where that path bails out.
    $merged = Plugins::Discography::Sources->attachLibraryArtists($merged);

    # SPLIT an owned row into one row per owned IDENTITY (Simon's three "The
    # Bees"): the merge kept only the first same-name contributor id, so distinct
    # owned acts collapsed into one row that drilled into the wrong band. This
    # re-derives the discarded contributors, folds those sharing a MB tag and
    # separates those that differ, and stamps `_ident_mbid` on every owned row
    # for the same-name acts below. Runs on the cached path too (like the
    # attach), so the split is judged against the library as it is NOW.
    $merged = Plugins::Discography::Sources->splitOwnedByIdentity($merged);

    # An owned row with NO tag is the act its own albums named when its page was
    # opened (API::getArtistMbid, resolver plan C2), once a visit has found one:
    # the same id for the same-name acts and the descriptions below as a tag
    # gives. Cache only, no request. A copy, never the row itself: a row the
    # split passed through is the 10-minute search cache's own.
    for my $i (0 .. $#{ $merged || [] }) {
        my $r = $merged->[$i];
        next unless ref $r eq 'HASH' && $r->{artist_id} && !$r->{_ident_mbid};
        my $m = Plugins::Discography::API->peekLibraryMbid($r->{artist_id}, $r->{name})
            or next;
        $merged->[$i] = { %$r, _ident_mbid => $m };
    }

    # RE-RANK, because the attach above is what makes some rows Local at all —
    # "The La's" is not found by the Local leg, so at merge time it ranked as a
    # streaming-only row. Same comparator as the merge (see rankArtistHits);
    # running it here is what makes "Local trumps" true for the rows 0.48.1
    # rescues, and it must stay AFTER the attach for that reason.
    $merged = Plugins::Discography::Sources->rankArtistHits($merged);

    # Drop rows whose page could only be empty BEFORE building any of them —
    # both the row list and the "already covered above" test below must see the
    # same set, or the same-name acts would lose a candidate on the
    # strength of a row that is no longer there. Since 0.56.9 (`known`) the rows
    # are decided from what earlier checks found, at once; a row not checked yet
    # is shown and checked after the reply, for the next search (see
    # API::filterRowsWithContent).
    Plugins::Discography::API->filterRowsWithContent($merged, sub {
    my ($kept) = @_;
    $merged = $kept;

    # RANK ONCE MORE, for the same reason as after the attach above: that
    # filter's own MB-tag pass (0.51.3) is the LAST thing that can make a row
    # Local — it claims a kept row by its resolved mbid and gives it an
    # artist_id + a Local source. Ranked before it, such a row kept the place it
    # had as a streaming-only row, under unowned ones, which is exactly what
    # 0.48.4's "Local trumps" rule exists to prevent (review 2026-09-19). A no-op
    # when the filter attached nothing: same comparator, same `_seq` tiebreak.
    $merged = Plugins::Discography::Sources->rankArtistHits($merged);

    # The same-name acts and the differently spelled ones, both from
    # MusicBrainz; every way out lays the page out from these and the result
    # rows, built only then so they carry the descriptions stamped below.
    my (@same, @distinct);
    my $layout = sub {
        my @hits = @{ _searchResultItems($client, $merged, $features) };
        $reply->(_searchSections($client, $features, $q, $part,
                                 scalar(@{ $merged || [] }), \@hits, \@same, \@distinct));
    };

    Plugins::Discography::API->getArtistCandidates($q, sub {
        my ($cands) = @_;
        $cands ||= [];

        # Every MusicBrainz act of this name, BEFORE the filters below drop the
        # owned ones: a result row that opens one of them says which it is.
        _stampDisambiguation($merged, $cands);

        if (@$cands < 2) {
            _dbg("artist search '$q': " . scalar(@$cands)
                . ' MB same-name artist(s) — none listed');
            return $layout->();
        }

        # THE COUNTS ARE NOT WAITED FOR (0.56.9; Simon, 2026-10-01: the search
        # "should be the quickest part ... just hide them on 2nd search"). An
        # uncounted candidate is shown, and its count is asked after the reply,
        # as background work, so the next search drops one with no releases.
        # This reverses 0.44.5, which waited for them (Simon then: "I dont want
        # users getting confused by stuff showing then disappearing"): nothing
        # leaves a list while it is shown, only a later search's list differs.
        # Same rule as the row check above (API::filterRowsWithContent `known`).
        # COST after the reply: one count per uncounted candidate, cached for
        # RGCOUNT_TTL, the community API first (API::warmCandidateCounts).
        my @uncounted = grep {
            !defined Plugins::Discography::API->peekReleaseGroupCount($_->{mbid})
        } @$cands;
        if (@uncounted) {
            local $Plugins::Discography::API::NET_BG = 1;
            Plugins::Discography::API->warmCandidateCounts(\@uncounted);
        }
        do {

        # A candidate MB has catalogued NO releases for can only ever render an
        # empty page — drop it. undef still means SHOW: an HTTP failure leaves
        # the count uncached (see warmCandidateCounts), and a fetch that failed
        # must never be read as "this artist has nothing".
        my @live = grep {
            my $n = Plugins::Discography::API->peekReleaseGroupCount($_->{mbid});
            !defined $n || $n > 0;
        } @$cands;
        _dbg("artist search '$q': " . (scalar(@$cands) - scalar(@live))
            . ' MB artist(s) dropped as having no releases')
            if @live < @$cands;
        $cands = \@live;

        # AN OWNED ACT IS LISTED ONCE, AS ITS OWN ROW. Every owned identity is
        # now a real row (splitOwnedByIdentity stamps each with its
        # `_ident_mbid`), so drop any MB candidate the user already owns —
        # matched by mbid, which is exact, rather than by the old name heuristic.
        # This is what keeps the same-name acts unowned-only: Simon's three "The
        # Bees" appear as owned rows and none of them reappears among these.
        my %ownedMbid = map { $_->{_ident_mbid} => 1 }
                        grep { $_->{_ident_mbid} } @{ $merged || [] };
        if (keys %ownedMbid) {
            my @keep = grep { !$ownedMbid{ lc($_->{mbid} // '') } } @$cands;
            _dbg("artist search '$q': " . (scalar(@$cands) - scalar(@keep))
                . ' MB same-name artist(s) dropped as OWNED')
                if @keep < @$cands;
            $cands = \@keep;
        }

        # A DIFFERENTLY SPELLED act is not something the user needs help
        # telling apart — "Mädness" reads as its own artist. Those go at the
        # END of the Artists section, after the service and library rows, and
        # because their name is unique the name-keyed artist photo is CORRECT
        # for them (unlike the same-string acts, which would all get the
        # prominent act's picture).
        my @sameString;
        for my $c (@$cands) {
            if (lc($c->{name} // '') eq lc $q) { push @sameString, $c }
            else { push @distinct, _mbCandidateRow($client, $c, $features, 1) }
        }

        $cands = \@sameString;
        if (@$cands < 2) {
            _dbg("artist search '$q': " . scalar(@$cands)
                . ' same-spelling artist(s) after filtering — none listed');
            return $layout->();
        }

        # DROP THE ACT A RESULT ROW ALREADY REACHES. getArtistCandidates sorts
        # by MB score, and the top one is exactly what name resolution picks —
        # so a streaming/library row for this name already drills into it, and
        # listing it again put the ska band on the page TWICE (field, 0.43.2).
        #
        # Only when such a row exists: with no result above (an artist absent
        # from every service and the library), the whole set must stay or the
        # prominent act becomes unreachable.
        #
        # ONLY an UNOWNED row triggers this. An owned row drills by artist_id
        # (its tag), so it reaches its OWN identity — already excluded by mbid
        # above — never the section's top candidate; counting it here would drop
        # a legitimate unowned act on the strength of an owned row that does not
        # reach it. An unowned streaming row named like the query DOES drill by
        # name resolution to the top candidate, so it still shifts it away.
        my $qn = Plugins::Discography::Sources::_norm($q);
        my $covered = grep { !$_->{artist_id}
                             && Plugins::Discography::Sources::_norm($_->{name} // '') eq $qn }
                      @{ $merged || [] };
        my @show = @$cands;
        shift @show if $covered;
        unless (@show) {
            _dbg("artist search '$q': every MB artist is already a result row");
            return $layout->();
        }

        _dbg("artist search '$q': " . scalar(@$cands)
            . ' MB artists share this name — listing ' . scalar(@show)
            . ' other' . ($covered ? ' (top one already a result row)' : ''));

        @same = map { _mbCandidateRow($client, $_, $features) } @show;
        $layout->();
        };    # the same-name acts, from the counts already known
    });
    }, { query => $q, known => 1 });   # filterRowsWithContent
}

# THE SEARCH PAGE'S TWO SECTIONS (Simon, 2026-10-01). "Top Result" holds the
# best-ranked row: an owned act when there is one (rankArtistHits: Local trumps),
# its services merged onto that one row. "Artists" holds everything else in this
# order: the other MusicBrainz acts with the same name (each told apart by its
# description; they were a section of their own, "Other artists with this name",
# until 0.56.10), then the remaining result rows in their ranked order (the
# library's first), then the differently spelled MusicBrainz acts.
#
# LAYOUT (Settings, `layout_search`): the top result is a tile either way, as a
# one-tile row; 'split' lists the artists under it, 'tiles' makes them a tile
# row as well. Tile rows are the artist page's `header-strip` and need the same
# patched Material (_stripsOn); anywhere else both headings are ordinary ones and
# the page looks as Material draws it, whatever the setting. A strip heading
# always carries an action, so Material shows More on it: Top Result's opens the
# artist (the tile's own action), Artists' opens every artist (`$part`
# 'sect:ARTISTS', for the tiles past what the row shows).
#
# Nothing found on the services or in the library ($found 0): `$hits` is the "No
# artists found" line, kept as it was, with any MusicBrainz acts under Artists.
# The row count and order do not depend on the setting, only the heading types,
# so a positional walk sees the same rows either way.
sub _searchSections {
    my ($client, $features, $q, $part, $found, $hits, $same, $distinct) = @_;
    my ($top, @rest) = @{ $hits || [] };
    my @artists = (@{ $same || [] }, ($found ? @rest : ()), @{ $distinct || [] });
    return \@artists if ($part // '') eq 'sect:ARTISTS';

    my $useH   = _wantHeaders($features);
    my $strips = _stripsOn($useH);
    my @rows;
    if ($found && $top) {
        push @rows, _searchHeader($client, 'PLUGIN_DISCOGRAPHY_TOP_RESULT', $useH,
            IMG_BASE . 'dsc-top_MTL_icon_star.png', [ $top ], $strips,
            $top->{itemActions});
    }
    push @rows, $top if $top;    # the top result, or the "No artists found" line
    if (@artists) {
        my $tiles = $strips && ($prefs->get('layout_search') // 'split') eq 'tiles';
        push @rows, _searchHeader($client, 'PLUGIN_DISCOGRAPHY_ARTISTS_HDR', $useH,
            IMG_BASE . 'dsc-bio_MTL_icon_person.png', \@artists, $tiles,
            { items => { command => ['discography', 'items'], fixedParams => {
                search => $q, item => 'sect:ARTISTS',
                (length($features // '') ? (features => $features) : ()) } } });
        push @rows, @artists;
    }
    return \@rows;
}

# THE DESCRIPTION OF THE ACT A RESULT OPENS (0.56.12; Simon, 2026-10-01: "show
# the disambiguation when they are matched so the bees says its the 60's garage
# band etc, you see this before any matches so would be good for a user to see
# it even on a match"). The unowned same-name entries always said which act
# they were; a result row for one of those acts said only where it was found,
# so Simon's three owned "The Bees" read "Local · 4 albums" / "Local · 1 album"
# twice. Now a row that opens a MusicBrainz act sharing its name with another
# act in the list ($cands, getArtistCandidates for the query) carries that act's
# description as `_disamb`, shown last on line2 (_searchResultRow).
#
# WHICH ACT A ROW OPENS, never a guess: an owned row by its library tag
# (`_ident_mbid`, the id its page opens by), an unowned row by the name
# resolver's cached answer for its name (the id a tap by name opens; for the
# typed name it is the lookup the search itself just made). An owned row with
# no tag gets nothing: its page resolves by name, and the top act's description
# on someone's other band would be wrong. A name MusicBrainz has once needs no
# telling apart, so a row gets one only when the list holds 2+ acts of its name.
# Cache reads only: no request.
sub _stampDisambiguation {
    my ($rows, $cands) = @_;
    my (%byMbid, %named);
    for my $c (@{ $cands || [] }) {
        next unless ref $c eq 'HASH' && $c->{mbid};
        $byMbid{ lc $c->{mbid} } = $c;
        $named{ lc($c->{name} // '') }++;
    }
    for my $r (@{ $rows || [] }) {
        next unless ref $r eq 'HASH';
        delete $r->{_disamb};
        next unless %byMbid;
        my $owned = $r->{artist_id}
            || grep { $_ eq 'Local' } @{ $r->{sources} || [] };
        my $mbid  = $r->{_ident_mbid}
            || ($owned ? undef : Plugins::Discography::API->peekArtistMbid($r->{name}));
        my $c = $mbid ? $byMbid{ lc $mbid } : undef;
        next unless $c && $named{ lc($c->{name} // '') } > 1;
        my $d = $c->{disambiguation};
        $r->{_disamb} = $d if defined $d && length $d;
    }
    return;
}

# A search heading: _sectionHeader's, made a tile-row heading when $strip. A
# tile-row heading keeps its actions in Material (unlike header-basic), so it is
# given a param-addressed one; without it, the More would walk by position.
sub _searchHeader {
    my ($client, $token, $useH, $image, $kids, $strip, $itemActions) = @_;
    my $hdr = _sectionHeader($client, $token, $useH, $image, $kids);
    if ($strip) {
        $hdr->{type}        = 'header-strip';
        $hdr->{itemActions} = $itemActions if $itemActions;
    }
    return $hdr;
}

# ONE ROW PER TITLE, AS MATERIAL COUNTS ROWS (stage 3 live check, 2026-09-30).
# Material gives a row with no item_id the id "<parent id>.<title>", the title
# being the name's first line (read in the bundle on plex:9000, 2026-09-30), and
# draws one tile per id: of two rows with one name only the LATER shows (0.51.1,
# the Zappa bands row). This level sends same-named rows by design, the owned
# acts split by MusicBrainz identity (0.50.0) and the "Other artists with this
# name" rows, so searching The Dream Syndicate opened 15 Minutes (Steve Wynn's
# earlier band, one owned album) and the band's own row never showed; Blur,
# Richard Hawley and The Charlatans showed their one- or two-album act, and Air
# an MB-only act instead of the user's. So each REPEAT of a name gets invisible
# WORD JOINERs (U+2060), one more per repeat: a different title to Material, the
# same text on screen. Only the displayed name changes: the rows' params and
# passthrough keep the real name, which is what a tap opens.
sub _distinctTitles {
    my ($rows) = @_;
    my %seen;
    for my $r (@{ $rows || [] }) {
        next unless ref $r eq 'HASH' && defined $r->{name} && length $r->{name};
        my $n = $seen{ $r->{name} }++;
        $r->{name} .= "\x{2060}" x $n if $n;
    }
    return $rows;
}

# One MB artist row. Entered by MBID (fixedParams `mbid`), which _discographyView
# takes as a resolved identity and browses directly — the name would resolve
# back to the prominent act and defeat the entire section.
sub _mbCandidateRow {
    my ($client, $cand, $features, $named) = @_;

    # The ALIAS is the name this artist's records are actually sold under on the
    # services ("Madness" the US rapper sells as "Tony Madness"), so it is often
    # the most recognisable thing on the row — and it explains why a row named
    # "Madness" leads to a catalogue filed elsewhere.
    my $alias = (@{ Plugins::Discography::API->peekArtistAliases($cand->{mbid}) || [] })[0];

    my @bits = grep { defined && length }
               ($cand->{disambiguation}, $cand->{type}, $cand->{country});
    unshift @bits, "aka $alias" if defined $alias && length $alias;
    my $line2 = @bits ? join(" \x{00B7} ", @bits)
                      : cstring($client, 'PLUGIN_DISCOGRAPHY_SAME_NAME_NOINFO');

    my %fixed = (
        mbid   => $cand->{mbid},
        artist => $cand->{name},
        (length($features // '') ? (features => $features) : ()),
    );
    return {
        name        => $cand->{name},
        type        => _artistRowType($features),
        line2       => $line2,
        # _artistImg is keyed by NAME. For an act whose spelling is UNIQUE
        # ($named) that resolves to the right artist, so it gets a real photo.
        # For acts sharing one spelling it would hand every row the prominent
        # act's picture — worse than none on a list whose purpose is telling
        # them apart (field, 0.43.0) — so those keep the person icon.
        # A library artist_id, when the candidate carries one, is BETTER than a
        # unique spelling: it is exact, and it resolves names the name-keyed
        # proxy cannot (0.48.3).
        image       => ($cand->{artist_id} || $named)
                       ? _artistImg($cand->{name}, $cand->{artist_id})
                       : IMG_BASE . 'dsc-bio_MTL_icon_person.png',
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => \%fixed } },
        passthrough => [{ c_mbid => $cand->{mbid}, c_name => $cand->{name},
                          features => $features }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            _dbg("MB same-name drill -> '$p->{c_name}' ($p->{c_mbid})");
            _discographyView($c, $cb, {
                mbid     => $p->{c_mbid},
                artist   => $p->{c_name},
                features => $p->{features},
                sort     => $prefs->get('sort_order') || 'newest',
                force    => 0,
            });
        },
    };
}

sub _searchResultItems {
    my ($client, $merged, $features) = @_;
    return [ { name => cstring($client, 'PLUGIN_DISCOGRAPHY_SEARCH_NONE'),
               type => 'text' } ] unless @$merged;
    return [ map { _searchResultRow($client, $_, $features) } @$merged ];
}

# One artist link row — the SAME drill-in as a similar-artist link, entered by
# name (plus the contributor id when the library knows the artist, so the
# reliable library-tag resolution path applies). line2 names the sources the
# artist was found on — the dedupe means one row can speak for several.
# (The 0.39.0 app-root spotlight also used this row with no sources, hence the
# old conditional line2; that section was replaced by the cover banner in
# 0.40.0, so search results are now the only caller and mergeArtistHits always
# records at least one source per bucket.)
sub _searchResultRow {
    my ($client, $hit, $features) = @_;
    my $name = $hit->{name};
    my %fixed = (
        artist => $name,
        ($hit->{artist_id}  ? (artist_id => $hit->{artist_id}) : ()),
        (length($features // '') ? (features => $features)     : ()),
    );
    return {
        name        => $name,
        type        => _artistRowType($features),
        # For a same-name split act, use LMS's OWN artist icon (folder art):
        # `_img` when LMS holds art, a neutral person icon when it knows the act
        # but has none (`_noart`) — NOT MAI's online guess of the prominent act,
        # which is the "bootleg shows the UK band" bug. Ordinary rows still use
        # the MAI proxy, which resolves a unique name correctly.
        # A STREAMING-ONLY row prefers the photo its own search response
        # carried (0.51.0): it is free, it is the picture that service shows
        # for this exact entity, and it needs no name lookup to find.
        image       => $hit->{_img}
                       || ($hit->{_noart} ? IMG_BASE . 'dsc-bio_MTL_icon_person.png'
                                          : ($hit->{artist_id} ? undef : $hit->{img}))
                       || _artistImg($name, $hit->{artist_id}),
        # A row split from a same-named owned act (Sources::splitOwnedByIdentity)
        # also says how many albums it opens on: the rows share a name and a
        # "Local" line, so the count is what tells them apart ("Local · 5
        # albums" / "Local · 1 album"; The Dream Syndicate and 15 Minutes, stage
        # 3 live check, 2026-09-30). Last, the MusicBrainz description of the act
        # it opens when that act shares its name (_stampDisambiguation), after
        # the sources so "Local" stays visible when a long one is cut.
        line2       => join(" \x{00B7} ", @{ $hit->{sources} || [] },
                            (defined $hit->{_owned}
                             ? ($hit->{_owned} == 1
                                ? cstring($client, 'PLUGIN_DISCOGRAPHY_OWNED_ALBUM')
                                : sprintf(cstring($client, 'PLUGIN_DISCOGRAPHY_OWNED_ALBUMS'),
                                          $hit->{_owned}))
                             : ()),
                            (defined $hit->{_disamb} && length $hit->{_disamb}
                             ? $hit->{_disamb} : ())),
        # Self-identifying go (stale-view fix): fresh top-level entry.
        itemActions => { items => { command => ['discography', 'items'],
            fixedParams => \%fixed } },
        passthrough => [{ q_name => $name, q_aid => $hit->{artist_id},
                          features => $features }],
        url         => sub {
            my ($c, $cb, $a, $p) = @_;
            _dbg("search drill -> '$p->{q_name}'"
                . ($p->{q_aid} ? " (artist_id $p->{q_aid})" : ''));
            _discographyView($c, $cb, {
                artist_id => $p->{q_aid},
                artist    => $p->{q_name},
                features  => $p->{features},
                sort      => $prefs->get('sort_order') || 'newest',
                force     => 0,
            });
        },
    };
}

# One release-group tile: title, "year . Type [. services]" line, CAA art
# (native service art as fallback when a cached match carries one). The
# services part is OPPORTUNISTIC — cache-only (peekMatches never searches, so
# the list build stays sync and fast): before the artist's first drill-in the
# tiles are untagged; afterwards matched tiles name their services.
# A PLAYABLE url for a matched candidate — NOT the favurl. The ListenLater
# favurl (`<svc>://album:<id>`) is a Favorites/handshake reference, and only
# Tidal and Deezer resolve that form to tracks; Qobuz's ProtocolHandler explodes
# an album ONLY when the url ends in `.qbz` (verified live: `qobuz://album:ID`
# enqueues one bogus track titled "album:ID" — Simon's Now-Playing junk id;
# `qobuz://album:ID.qbz` plays the 17-track album). Local carries a real
# db:album.id play string already.
#   Local  -> item's own `play` (db:album.id=N)
#   Qobuz  -> qobuz://album:<id>.qbz
#   Tidal  -> tidal://album:<id>
#   Deezer -> deezer://album:<id>
#   Spotify -> spotify://album:<id>  (Spotty's protocol-handler form; its favurl
#              is spotify:album:<id>. explodePlaylist -> tracksFromURI matches
#              `:album:` -> album(), read in Spotty 4.62.2)
sub _playUrl {
    my ($it) = @_;
    return undef unless ref $it eq 'HASH';
    return $it->{play} if defined $it->{play} && !ref $it->{play};   # Local db: url

    my $svc = lc($it->{_svc} // '');
    my $id  = $it->{_albumid};
    return undef unless length $svc && defined $id && length $id;
    return "qobuz://album:$id.qbz" if $svc eq 'qobuz';
    return "$svc://album:$id"      if $svc eq 'tidal' || $svc eq 'deezer' || $svc eq 'spotify';

    # Unknown service: fall back to the favurl minus our private query params.
    my $u = $it->{favorites_url};
    $u =~ s/\?.*$// if defined $u;
    return $u;
}

# Material's service badge over a streaming version's artwork (Simon, 2026-09-24; the
# LL 1.0.7 / PFR 1.0.2 shape). Material (upstream d3f1d9227, first released in 6.4.10)
# draws an emblem from a row's `extid`, reading only the part before the first ':' and
# looking it up in its misc/emblems.json, whose keys for our three services are their
# names lowercased. The album id rides along as '<svc>:album:<id>', the shape Material's
# own streaming items use. A node that already carries its own extid keeps it. Local has
# no emblem, so a library copy is never badged. Callers set the result on a row COPY,
# never on the cached candidate, so no candidate cache-version bump is needed.
my %EMBLEM = map { $_ => $_ } qw(qobuz tidal deezer spotify);
sub _extid {
    my ($it) = @_;
    return undef unless ref $it eq 'HASH';
    return $it->{extid} if defined $it->{extid} && !ref $it->{extid} && length $it->{extid};
    my $pfx = $EMBLEM{ lc($it->{_svc} // '') } or return undef;
    my $id  = $it->{_albumid};
    return defined $id && length $id ? "$pfx:album:$id" : "$pfx:";
}

# THE ARCHIVE COVER ONLY WHEN THE SERVER ALREADY HOLDS IT (0.56.26; Simon
# 2026-10-02: build it, and decide later when to fetch the missing covers). A
# tile no source gives a cover to used to point at the Cover Art Archive, and
# the image proxy then fetched it from archive.org while the user browsed.
# Measured on the rig that day: about 3 s a cover with the whole server stalled
# about 0.65 s each (LBF's "Slow artwork / server freezes": an LMS core HTTPS
# read blocks the event loop); 13 at once held a status request 11 s; an
# archive.org 500 held the server 14 s, and a failed cover is never cached, so
# it was fetched (and stalled) again on every visit. Such a tile now shows its
# release-type icon unless the proxy's own cache holds the cover, and the cover
# is fetched in the background after the visit (0.56.27, Covers.pm), so the
# NEXT visit shows it.
#
# THE KEY IS THE PROXY'S, NOT proxiedImage's: Slim::Web::HTTP strips the leading
# slash and URL-decodes the path before getImage caches under it (pinned live by
# LBF 1.0.17); the extension is the url's (`.jpg` since 0.56.27, API::caaImage;
# an extensionless url is proxied as `.png`, proxiedImage). The specs: the unsized request Material 6.4.10 sends for an `icon` row, then the
# sizes it asks once that is fixed (list 150/300, grid 300/600). A held cover a
# device asks at ANOTHER size is still fetched once, from a source known to
# answer. A failed fetch is never cached (`_artworkError` sends no-cache), so a
# hit is always a real cover. A read costs ~0.05 ms (LBF measured 6,543 reads).
my @CAA_HELD_SPECS = ('', '_300x300_f', '_150x150_f', '_600x600_f');
my $proxyCache;
sub _caaHeld {
    my ($url) = @_;
    return 0 unless defined $url && length $url;
    $proxyCache ||= eval { require Slim::Web::ImageProxy; Slim::Web::ImageProxy::Cache->new() }
        or return 0;
    # The extension exactly as proxiedImage picks it (LMS 9.1).
    my $ext = $url =~ /(\.(?:jpg|jpeg|png|gif))/ ? $1 : '.png';
    $ext =~ s/jpeg/jpg/;
    for my $spec (@CAA_HELD_SPECS) {
        my $hit = eval { $proxyCache->get('imageproxy/' . $url . '/image' . $spec . $ext) };
        return 1 if $hit;
    }
    return 0;
}

# Want the archive covers of the tiles a page SHOWS (0.56.27). Called with the
# visible tiles of each section, and with a strip's full list when its header
# is opened; a tile behind "Show more" is wanted when that page is drawn
# (Show more rebuilds the list). Wanting only records: Covers fetches at 05:00
# (0.56.30).
sub _wantCovers {
    my ($tiles) = @_;
    Plugins::Discography::Covers::want($_->{_caaWant})
        for grep { ref $_ eq 'HASH' && $_->{_caaWant} } @{ $tiles || [] };
    return;
}

sub _releaseItem {
    my ($client, $opts, $rg, $sections, $coverFlags) = @_;

    my $year = ($rg->{date} =~ /^(\d{4})/) ? $1 : '';
    my $type = _displayType($client, $rg);
    my $image;

    my ($favurl, $playUrl, $svcTag, $extid);
    if ($sections && @$sections) {
        $svcTag = join('/', map { $_->{svc} } @$sections);

        # Tile play = the PREFERRED source's play string — Local now has one
        # (db:album.id=N, core-resolved like album Favorites), so local-first
        # priority genuinely plays the library copy. The tile's own `play`
        # attr is advisory; the real mechanism is the detail feed's first
        # play-string row (XMLBrowser play collects those — see 0.9.4 log),
        # which _releaseDetail keeps in the same priority order.
        my $best = $sections->[0]{items}[0];
        $playUrl = _playUrl($best);

        # The badge names the source the tile PLAYS (Simon, 2026-09-24): a
        # Local-first tile gets none, even when a streaming favurl rides along
        # below. One badge cannot show every source; line2 still lists them.
        $extid = _extid($best);

        # favurl (the LL add handshake) stays streaming-only — no service
        # scheme exists for a library album. The badge is _extid, not the favurl.
        my ($stream) = grep { $_->{svc} ne 'Local' } @$sections;
        $favurl = $stream->{items}[0]{favorites_url} if $stream;

        # A matched source (Local file art or the service's CDN cover, in
        # priority order) ALWAYS has art; the Cover Art Archive frequently 404s
        # even on dated releases (verified: Marc Almond "Against Nature" /
        # "The Dancing Marquis" — matched, but CAA-less -> blank tile). We can't
        # detect a CAA 404 server-side, and the source cover is already in the
        # candidate cache (no extra fetch, faster CDN load), so PREFER it.
        my ($cover) = grep { defined && length } map { $_->{items}[0]{_cover} } @$sections;
        $image = $cover if defined $cover && length $cover;
    }

    # No source cover: the archive's, only if the server holds it (_caaHeld),
    # else the type icon. Never an archive fetch from browsing (0.56.26); a
    # tile that shows the icon names its archive url in `_caaWant`, and the
    # page wants the ones it shows for the 05:00 run (_wantCovers, 0.56.27;
    # night only since 0.56.30). A private key, like the `_svc` on streaming
    # rows: XMLBrowser sends none of them to the client. NOT when ListenBrainz
    # says the archive has no cover for the group ($coverFlags 0, 0.56.30):
    # the icon is then the final answer and nothing is ever fetched. No flags
    # (ListenBrainz never answered for this artist) = maybe, as before.
    my $caaWant;
    unless (defined $image) {
        my $caa = Plugins::Discography::API->caaImage($rg->{mbid});
        my $none = $coverFlags && defined $coverFlags->{ lc($rg->{mbid} // '') }
                   && !$coverFlags->{ lc($rg->{mbid} // '') };
        if (_caaHeld($caa)) { $image = $caa }
        else                { $image = _typeIcon($rg); $caaWant = $caa unless $none }
    }

    # Service names stay in line2 (Simon, 2026-09-24): the badge (_extid) shows
    # only the playing source, and line2 is the one place every source, Local
    # included, is listed.
    my $line2 = join(" \x{00B7} ", grep { defined && length } $year, $type, $svcTag);

    # Matched tiles are type 'playlist': tap still drills (go -> detail page),
    # but play/add work on the whole tile via the play URL — AND XMLBrowser
    # only forwards favorites_url into presetParams for playable types
    # (verified live: identical favurl on a 'link' tile is dropped, on a
    # 'playlist' row forwarded), so this is also what makes the
    # ListenLater Add possible on tiles. Item COUNT is unchanged either way
    # (walk-stable tree; only the type differs as the cache warms).
    #
    # itemActions = SELF-IDENTIFYING clicks (the stale-view fix): the go action
    # carries rg + full artist identity as explicit params instead of a
    # positional item_id, so a tap works no matter what was browsed in between
    # (topLevel's rg: dispatch renders the detail directly and re-stashes ctx).
    # play/add/insert route to the explicit ['discography','playcmd'] dispatch
    # for the same reason — XMLBrowser's default play action is positional too.
    # The url coderef stays for the legacy walk path and non-menu skins.
    return {
        name        => $rg->{title},
        line2       => $line2,
        type        => defined $playUrl ? 'playlist' : 'link',
        image       => $image,
        (defined $playUrl ? (play => $playUrl)           : ()),
        (defined $favurl  ? (favorites_url => $favurl)   : ()),
        (defined $extid   ? (extid => $extid)            : ()),
        (defined $caaWant ? (_caaWant => $caaWant)       : ()),
        itemActions => _rgItemActions($opts, $rg->{mbid}, undef, defined $playUrl),
        passthrough => [{ %$opts, rg => $rg }],
        url         => sub {
            my ($c, $cb, $a, $pass) = @_;
            _releaseDetail($c, $cb, $pass);
        },
    };
}

# The artist-identity params every self-addressed action carries — enough to
# rebuild the view from scratch (no %lastCtx needed).
sub _identParams {
    my ($opts) = @_;
    return (
        ($opts->{artist_id}              ? (artist_id => $opts->{artist_id}) : ()),
        (defined $opts->{artist} && length $opts->{artist}
                                         ? (artist    => $opts->{artist})    : ()),
        # ENTRY mbid ONLY (a band link enters by mbid; a person/name entry has
        # none) — deliberately NOT the resolved mbid, which would desync the
        # mbid-less refresh command and wipe the toggle ctx (0.8.1). Detail
        # actions add the resolved mbid explicitly via _rgIdent.
        ($opts->{entry_mbid}             ? (mbid      => $opts->{entry_mbid}) : ()),
        (length($opts->{features} // '') ? (features  => $opts->{features})  : ()),
        # The list view's sort rides the params end-to-end (a toggle-opened
        # view re-issues its own command on refresh, keeping its order).
        (($opts->{sort} // '') =~ /^(?:newest|oldest)$/
                                         ? (sort      => $opts->{sort})      : ()),
        # local_only rides the params the same way sort does: a view opened
        # with the filter on re-issues its own command (toggles/paging) with
        # local_only=1 still set, so the filter sticks throughout that view.
        ($opts->{local_only}             ? (local_only => 1)                 : ()),
    );
}

# Identity + the release group (detail-view actions). Detail dispatch (_rgView)
# needs the RESOLVED artist mbid to fetch the RG list, so add it explicitly here
# — _identParams intentionally carries only the ENTRY mbid (see _buildList). For
# a band view the entry and resolved mbid are equal, so the duplicate key is
# harmless; for a person view _identParams omits mbid and this supplies it.
sub _rgIdent {
    my ($opts, $rgMbid) = @_;
    return { rg => $rgMbid,
             ($opts->{mbid} ? (mbid => $opts->{mbid}) : ()),
             _identParams($opts) };
}

# A LIST-view row's self-identifying actions: go re-enters topLevel with the
# artist identity + item:<id>, dispatched through _listItemDispatch (which
# rebuilds the list privately and invokes the row's own coderef). $playUrl
# (optional, whitelisted in playcmd) adds direct play/add/insert for the
# library-extras tiles (their play string is a core-resolved db: url — no
# resolution step needed).
sub _listItemActions {
    my ($opts, $id, $playUrl) = @_;
    my %ident = (_identParams($opts), item => $id);
    my %a = (
        items => { command => ['discography', 'items'], fixedParams => { %ident } },
    );
    if (defined $playUrl && length $playUrl) {
        for my $cmd (qw(play add insert)) {
            $a{$cmd} = {
                command     => ['discography', 'playcmd'],
                fixedParams => { %ident, cmd => $cmd, url => $playUrl },
            };
        }
    }
    return \%a;
}

# itemActions for a release tile or a detail-page row. $item = the row id
# within the detail view (undef for the tile itself -> go opens the detail).
# $playable adds explicit play/add/insert actions via the playcmd dispatch.
sub _rgItemActions {
    my ($opts, $rgMbid, $item, $playable) = @_;
    my $ident = _rgIdent($opts, $rgMbid);
    $ident->{item} = $item if defined $item;
    my %a = (
        items => { command => ['discography', 'items'], fixedParams => $ident },
    );
    if ($playable) {
        for my $cmd (qw(play add insert)) {
            $a{$cmd} = {
                command     => ['discography', 'playcmd'],
                fixedParams => { %$ident, cmd => $cmd },
            };
        }
    }
    return \%a;
}

# Primary type, with a meaningful secondary appended LBF-style
# ("Album / Soundtrack"); a secondary "Compilation" replaces the primary label
# since that's what the release IS to a listener.
sub _displayType {
    my ($client, $rg) = @_;
    my $type = $rg->{type} // '';
    my @sec  = @{ $rg->{secondary} };
    return 'Compilation' if grep { $_ eq 'Compilation' } @sec;
    return @sec ? join(' / ', grep { length } $type, $sec[0]) : $type;
}

# ---------------------------------------------------------------------------
# Album review (detail page): MAI's albumreview when the plugin is installed
# (same direct-function pattern LBF uses for artist bios), else a Qobuz
# editorial description riding the match candidates. Cached per release group;
# a cached '' means "confirmed none" (don't re-ask every open).
# ---------------------------------------------------------------------------

# Raw MAI/Qobuz text -> cleaned prose (see `_cleanBio`), or undef when nothing
# worth a section is left (`_proseHasBody`). The ONE entry point for all three
# fetch sites, so a MAI answer and a Qobuz description are judged the same way.
sub _cleanProse {
    my ($raw) = @_;
    return undef unless defined $raw && !ref $raw && length $raw;
    my $text = _cleanBio($raw);
    return _proseHasBody($text) ? $text : undef;
}

# Is this MAI item its NOT-FOUND answer rather than a biography or review?
#
# READ IN MAI's SOURCE (michaelherger/MusicArtistInfo, 2026-09-24): with nothing
# to offer, getBiography and getAlbumReview do NOT call back empty — they hand
# over ONE item whose `name` is the error text, which is the localised string
# PLUGIN_MUSICARTISTINFO_NOT_FOUND ("I'm sorry, didn't find any relevant
# information.") and, for a web client, is wrapped as "<p>…</p>" + the "More
# online sources" link list (AlbumInfo::renderReview, ArtistInfo::_getBioItems).
# MEASURED on the live server: 10 of 12 albums sampled answered this way. Until
# this check, that sentence was rendered AS the review and the Qobuz fallback
# never ran (present since reviews were added in 0.7.0).
#
# The test is MAI's OWN: its CLI wrapper classifies an item as an error when the
# text starts with that string (ArtistInfo::getBiographyCLI, AlbumInfo). We strip
# the markup first, which MAI's check does not, so the web-wrapped form is caught
# too. The item TYPE is not used: a review error is `text` and a real review
# `textarea`, but a bio error goes through the same textarea path as a real bio.
# cstring($client) resolves the same language MAI rendered with.
sub _maiNotFound {
    my ($client, $raw) = @_;
    return 0 unless defined $raw && !ref $raw && length $raw;
    my $nf = eval {
        Slim::Utils::Strings::stringExists('PLUGIN_MUSICARTISTINFO_NOT_FOUND')
            ? cstring($client, 'PLUGIN_MUSICARTISTINFO_NOT_FOUND') : '';
    } // '';
    return 0 unless length $nf;
    (my $plain = $raw) =~ s/<[^>]+>//g;
    $plain =~ s/^\s+//;
    return index($plain, $nf) == 0 ? 1 : 0;
}

sub _fetchAlbumReview {
    my ($client, $artist, $album, $rgMbid, $sections, $cb) = @_;

    # v2 (2026-09-24): the cached text is `_cleanBio` output (setext headings,
    # bullets) — v1 held the old flattened `_stripHtml` shape.
    my $key = 'dsc:rev:2:' . $rgMbid;
    if (defined(my $c = _cacheGetText($key))) {
        $cb->(length $c ? $c : undef);   # '' = confirmed none
        return;
    }

    my $qobuzFallback = sub {
        my $desc;
        for my $sec (@{ $sections || [] }) {
            ($desc) = grep { defined && length } map { $_->{_desc} } @{ $sec->{items} };
            last if $desc;
        }
        $desc = _cleanProse($desc);
        _cacheSetText($key, $desc, (defined $desc && length $desc) ? REVIEW_FOUND_TTL : REVIEW_EMPTY_TTL);
        $cb->( (defined $desc && length $desc) ? $desc : undef );
    };

    # MAI's albumreview as a direct function (LBF's bio pattern): guarded via
    # can() — a signature/shape change in MAI degrades to the Qobuz fallback,
    # never an error. Callback items carry the review text in `name`.
    my $reviewFn;
    eval {
        $reviewFn = Plugins::MusicArtistInfo::AlbumInfo->can('getAlbumReview')
            if Slim::Utils::PluginManager->isEnabled('Plugins::MusicArtistInfo::Plugin');
        1;
    };
    unless ($reviewFn && length($artist // '') && length($album // '')) {
        _dbg("review '$album': MAI " . ($reviewFn ? 'skipped (missing artist/album)' : 'unavailable') . " -> Qobuz fallback");
        $qobuzFallback->();
        return;
    }

    my $ok = eval {
        $reviewFn->($client, sub {
            my $items = shift || [];
            my $text;
            for my $it (@$items) {
                next unless ref $it eq 'HASH';
                my $t = $it->{name};
                if (_maiNotFound($client, $t)) { _dbg("review '$album': MAI not-found answer"); next }
                if (defined(my $c = _cleanProse($t))) { $text = $c; last }
            }
            if (defined $text && length $text) {
                _dbg("review '$album': MAI len=" . length $text);
                _cacheSetText($key, $text, REVIEW_FOUND_TTL);
                $cb->($text);
            }
            else {
                _dbg("review '$album': MAI empty -> Qobuz fallback");
                $qobuzFallback->();
            }
        }, {}, { artist => $artist, album => $album });
        1;
    };
    unless ($ok) {
        $log->warn("MAI albumreview threw: $@");
        $qobuzFallback->();
    }
}

# Summary cut at a word boundary; returns (summary, wasTruncated).
sub _reviewSummary {
    my ($text) = @_;
    (my $flat = $text) =~ s/\s+/ /g;
    return ($flat, 0) if length($flat) <= REVIEW_SUMMARY_CHARS;
    my $cut = substr($flat, 0, REVIEW_SUMMARY_CHARS);
    $cut =~ s/\s+\S*$//;
    return ($cut . " \x{2026}", 1);
}

# Detail page: MB metadata header, review summary (tap through to the full
# text), the playable version row(s), a Refresh-matches action, and the
# external links (MB + AllMusic/Discogs/... from MB url-relationships). All
# fetches are cache-backed and therefore IDEMPOTENT — this page is re-executed
# on every deeper item_id walk (the 0.2.1 design rule).
sub _releaseDetail {
    my ($client, $callback, $pass) = @_;
    my $rg     = $pass->{rg};
    my $artist = $pass->{artist} // '';

    # The list view's same-name guard, applied here too (review 2026-09-19).
    # Only the tile's url coderef passes the list's $opts, which carry
    # shared_name; _rgView (Material) and playCommand rebuild $pass from action
    # params, which do not. Resolve it the same way the list did (a cache hit
    # once the list or search has run) before anything is fetched.
    return Plugins::Discography::API->sharesNameWithProminentAsync($artist, $pass->{mbid}, sub {
        $pass->{shared_name} = $_[0] ? 1 : 0;
        _releaseDetail($client, $callback, $pass);
    }) unless exists $pass->{shared_name};

    # Meta as an indented prose row (the view header already shows the
    # artwork; an image here would mutate the row to a clamped one-liner).
    my $metaTitle = _escHtml($rg->{title} . ($artist ? " \x{2013} $artist" : ''));
    my $metaSub   = _escHtml(join(" \x{00B7} ", grep { length } $rg->{date}, _displayType($client, $rg)));
    my $meta = {
        name => "<div style='margin-left:" . PROSE_INDENT . "'><b>$metaTitle</b>"
              . (length $metaSub ? "<br/>$metaSub" : '') . '</div>',
        type => 'text',
    };
    my $mbLink = {
        name    => cstring($client, 'PLUGIN_DISCOGRAPHY_VIEW_ON_MB'),
        type    => 'link',
        image   => MENU_WEBLINK,
        weblink => 'https://musicbrainz.org/release-group/' . $rg->{mbid},
    };

    # $compose MUST be assigned before the fetches fire: with every cache warm
    # the whole callback chain runs SYNCHRONOUSLY, and an undef $compose would
    # crash. Composed exactly once, when both legs (url-rels; candidates ->
    # review) have settled — each leg's guard checks the other's completion.
    my ($links, $reviewDone, $review, $sectionsDone, $sections);
    my $compose = sub {

        my $useHdr = _wantHeaders($pass->{features});
        my @rows;

        # Review under the artwork header. Material has NO inline expander for
        # browse rows (its v-list-group accordion is context-menu-only), so
        # "Read full review" is a REFRESH TOGGLE: it flips a per-release flag
        # in the player ctx and returns nextWindow=>'refresh' — Material
        # re-fetches this same view, which now renders the full text inline
        # (_proseSection: LBF's parser, one styled row per heading/bullet/
        # paragraph) with everything below pushed down; "Show less" flips it
        # back. Walk-safe: the flag only changes via these toggle rows, and
        # each flip immediately re-renders the very view whose shape it changes.
        if (defined $review && length $review) {
            my $expanded = $lastCtx{ _cid($client) }{rev}{ $rg->{mbid} };
            my ($prose, $truncated) = _proseSection($review, $expanded);
            push @rows, @$prose;
            if ($expanded && $truncated) {
                push @rows, {
                    name        => cstring($client, 'PLUGIN_DISCOGRAPHY_SHOW_LESS'),
                    type        => 'link',
                    image       => MENU_REVIEW,
                    nextWindow  => 'refresh',
                    id          => 'rev:less',
                    itemActions => _rgItemActions($pass, $rg->{mbid}, 'rev:less'),
                    passthrough => [{ mbid => $rg->{mbid} }],
                    url         => sub {
                        my ($c, $cb, $a, $p) = @_;
                        delete $lastCtx{ _cid($c) }{rev}{ $p->{mbid} };
                        $cb->({ items => [] });
                    },
                };
            }
            else {
                if ($truncated) {
                    push @rows, {
                        name        => cstring($client, 'PLUGIN_DISCOGRAPHY_FULL_REVIEW'),
                        type        => 'link',
                        image       => MENU_REVIEW,
                        nextWindow  => 'refresh',
                        id          => 'rev:more',
                        itemActions => _rgItemActions($pass, $rg->{mbid}, 'rev:more'),
                        passthrough => [{ mbid => $rg->{mbid} }],
                        url         => sub {
                            my ($c, $cb, $a, $p) = @_;
                            $lastCtx{ _cid($c) }{rev}{ $p->{mbid} } = 1;
                            $cb->({ items => [] });
                        },
                    };
                }
            }
        }

        # Header above the review block (walk-stable: present iff review rows
        # are, and the review is cache-fixed for the visit).
        if (@rows) {
            my @kids = @rows;
            splice @rows, 0, 0, _sectionHeader($client, 'PLUGIN_DISCOGRAPHY_REVIEW', $useHdr,
                MENU_REVIEW, \@kids,
                { id => 'hdr:review',
                  itemActions => _rgItemActions($pass, $rg->{mbid}, 'hdr:review') });
        }

        my $preVersionRows = scalar @rows;
        my $keptPlay = 0;
        my $totalVersions = 0;
        $totalVersions += scalar @{ $_->{items} } for @$sections;
        my $showAll = $prefs->get('show_all_versions')
            || $lastCtx{ _cid($client) }{ver}{ $rg->{mbid} };
        if (!$showAll) {
            # Default: ONE row — the preferred service's best version (the
            # same node tile-play uses). Cuts the drill-in to a single
            # thumbnail; the all-services view stays behind the pref.
            if (@$sections) {
                my %row = %{ $sections->[0]{items}[0] };
                $row{line2} = $sections->[0]{svc}
                    . ($row{_track} && $row{_fromAlbum} ? " \x{00B7} from $row{_fromAlbum}" : '');
                # The service badge, on this copy only (see _extid).
                my $extid = _extid(\%row);
                $row{extid} = $extid if defined $extid;
                # A WORKING play string (Qobuz needs .qbz; the native url coderef
                # still handles drill + row Play, but tile-play-via-expansion
                # collects this string).
                my $p = _playUrl(\%row);
                $row{play} = $p if defined $p;
                $keptPlay = 1;
                $row{id} = 'v:' . $sections->[0]{svc} . ':0';
                $row{itemActions} = _rgItemActions($pass, $rg->{mbid}, $row{id}, 1);
                push @rows, \%row;

                # Inline expand to the full per-service layout (the same
                # refresh-toggle pattern as reviews/bios) — only offered when
                # there IS more than the one row.
                if ($totalVersions > 1) {
                    push @rows, {
                        name        => cstring($client, 'PLUGIN_DISCOGRAPHY_OTHER_VERSIONS'),
                        type        => 'link',
                        image       => IMG_BASE . 'dsc-ver_MTL_icon_unfold_more.png',
                        nextWindow  => 'refresh',
                        id          => 'ver:show',
                        itemActions => _rgItemActions($pass, $rg->{mbid}, 'ver:show'),
                        passthrough => [{ mbid => $rg->{mbid} }],
                        url         => sub {
                            my ($c, $cb, $a, $p) = @_;
                            $lastCtx{ _cid($c) }{ver}{ $p->{mbid} } = 1;
                            $cb->({ items => [] });
                        },
                    };
                }
            }
        }
        else {
            # One Material header divider per service, its playable versions
            # below. Same divider rules as the list view: emitted for every
            # client (only the type differs) so the tree is walk-stable; no
            # image on detail-page headers (nothing to brand — LBF's
            # detail-page convention; service icons are plain .png anyway,
            # which dividers never render).
            for my $sec (@$sections) {
                my @svcRows;
                my $vidx = 0;
                for my $it (@{ $sec->{items} }) {
                    my %row = %$it;
                    # Native node from the service plugin's own renderer (url
                    # coderef + passthrough), so play/add/insert work natively.
                    $row{line2} = $sec->{svc}
                        . ($row{_track} && $row{_fromAlbum} ? " \x{00B7} from $row{_fromAlbum}" : '');
                    my $extid = _extid(\%row);
                    $row{extid} = $extid if defined $extid;
                    # Tile play collects EVERY play-string row in this feed
                    # (XMLBrowser one-level collection) — only the FIRST
                    # (preferred) version gets a WORKING play string (Qobuz
                    # needs .qbz) or tile play would enqueue every service's
                    # copy. The stripped rows still play via their url feeds.
                    if ($keptPlay) {
                        delete $row{play};
                    }
                    else {
                        my $p = _playUrl(\%row);
                        $row{play} = $p if defined $p;
                        $keptPlay = 1;
                    }
                    $row{id} = 'v:' . $sec->{svc} . ':' . $vidx++;
                    $row{itemActions} = _rgItemActions($pass, $rg->{mbid}, $row{id}, 1);
                    push @svcRows, \%row;
                }
                my $hdr = {
                    name => $sec->{svc} . ' (' . scalar(@svcRows) . ')',
                    type => $useHdr ? _headerType() : 'text',
                };
                if ($useHdr) {
                    my @kids = @svcRows;
                    $hdr->{id}          = 'hdr:' . $sec->{svc};
                    $hdr->{itemActions} = _rgItemActions($pass, $rg->{mbid}, $hdr->{id});
                    $hdr->{url}         = sub { $_[1]->({ items => \@kids }) };
                    $hdr->{passthrough} = [{}];
                }
                push @rows, $hdr, @svcRows;
            }

            if (!$prefs->get('show_all_versions') && $totalVersions > 1) {
                push @rows, {
                    name        => cstring($client, 'PLUGIN_DISCOGRAPHY_HIDE_VERSIONS'),
                    type        => 'link',
                    image       => IMG_BASE . 'dsc-ver_MTL_icon_unfold_more.png',
                    nextWindow  => 'refresh',
                    id          => 'ver:hide',
                    itemActions => _rgItemActions($pass, $rg->{mbid}, 'ver:hide'),
                    passthrough => [{ mbid => $rg->{mbid} }],
                    url         => sub {
                        my ($c, $cb, $a, $p) = @_;
                        delete $lastCtx{ _cid($c) }{ver}{ $p->{mbid} };
                        $cb->({ items => [] });
                    },
                };
            }
        }

        unless (@rows > $preVersionRows) {
            push @rows, _proseRow(cstring($client, 'PLUGIN_DISCOGRAPHY_NO_MATCH'));
        }

        # Side-effecting row -> nextWindow refresh (never a drill-in): clear
        # this artist's candidate caches and let the client re-fetch this very
        # page, which re-resolves fresh.
        push @rows, {
            name        => cstring($client, 'PLUGIN_DISCOGRAPHY_REFRESH_MATCHES'),
            type        => 'link',
            image       => MENU_REFRESH,
            nextWindow  => 'refresh',
            id          => 'act:refresh',
            itemActions => _rgItemActions($pass, $rg->{mbid}, 'act:refresh'),
            # The ARTIST's mbid as well as the name (0.56.15): since 0.43 the
            # pool this page reads is keyed by it (getCandidates above, `mbid =>
            # $pass->{mbid}`), and with only the name the row cleared the
            # name-keyed copy nothing reads - so "Refresh matches" changed
            # nothing on any artist with an mbid.
            passthrough => [{ artist => $artist, mbid => $pass->{mbid} }],
            url         => sub {
                my ($c, $cb, $a, $p) = @_;
                Plugins::Discography::Sources->clearCandidates($p->{artist}, $p->{mbid});
                $cb->({ items => [] });
            },
        };

        # External links: MB always, then whatever url-relationships MB has
        # for this release group (AllMusic, Discogs, Wikipedia, ...).
        my @linkRows = ($mbLink,
            map { { name => $_->{label}, type => 'link', weblink => $_->{url}, image => MENU_WEBLINK } }
            @{ $links || [] });

        $callback->({ items => [ $meta, @rows, @linkRows ], cachetime => 0 });
    };

    Plugins::Discography::API->getReleaseGroupUrls(
        mbid   => $rg->{mbid},
        onDone => sub { $links = shift; $compose->() if $sectionsDone && $reviewDone },
    );

    # Same spine as the list view, or the detail page resolves a DIFFERENT
    # service artist than the tile did and the two disagree — the exact class of
    # bug 0.18.0 fixed for the rival/MBID context.
    my $dSpine = _spineTitles(
        Plugins::Discography::API->peekReleaseGroups($pass->{mbid}));

    my $withCands = sub {
        my $bySvc = shift;
        # Same gate as the list's $local (_discographyView): a secondary act
        # with no library id of its own gets no name lookup, or the prominent
        # act's owned album reads Local on a detail page whose tile did not.
        my $local = ($pass->{shared_name} && !$pass->{artist_id}) ? []
                  : Plugins::Discography::Sources->localAlbums(
                        $pass->{artist_id}, $artist, $pass->{mbid},
                        { fallback => _idFallback($pass) });
        # Lazy owned-track pool, so the drill agrees with the tile for a release
        # owned only as a compilation track (same suppression as $local).
        my $ltCache;
        my $localTracks = sub {
            return $ltCache if defined $ltCache;
            $ltCache = ($pass->{shared_name} && !$pass->{artist_id}) ? []
                     : Plugins::Discography::Sources->localTracks($pass->{artist_id}, $artist,
                           { fallback => _idFallback($pass), mbid => $pass->{mbid} });
            return $ltCache;
        };
        my $ambid = $pass->{mbid};   # artist MBID (carried on the tile)

        # Rebuild the SAME context the list used, so drill-in agrees with the
        # tile: tier-0 identity (the Local/Esher row that only matches by MBID)
        # and the same-title rival rule (a compilation must not show the album's
        # streaming versions). Falls back to plain title matching if a stale
        # passthrough (pre-mbid) or a cold cache leaves the maps unavailable.
        my $relMap = { %{ $ambid ? (Plugins::Discography::API->peekReleaseMap($ambid) || {}) : {} },
                       %{ Plugins::Discography::API->peekLocalReleaseMap(
                              [ map { $_->{_mbid} } grep { $_->{_mbid} } @$local ] ) } };

        my $finish = sub {
            my ($rivalBucket, $eds, $idGroups) = @_;
            $sections = Plugins::Discography::Sources->matchesFor(
                $bySvc, $artist, $rg->{title}, $local, $rg->{mbid}, $relMap, $rivalBucket,
                { aliases => $rg->{aliases}, rgType => $rg->{type}, editions => $eds,
                  idGroups => $idGroups, localTracks => $localTracks,
                  # The artist's other MusicBrainz names, as the tile's (C3).
                  otherNames => _otherNames($ambid, $artist) });
            $sectionsDone = 1;
            # Review needs $sections (Qobuz-description fallback rides the match).
            _fetchAlbumReview($client, $artist, $rg->{title}, $rg->{mbid}, $sections, sub {
                $review = shift;
                $reviewDone = 1;
                $compose->() if defined $links;
            });
        };

        # Rivals need every same-title release-group; the RG list is cached from
        # the list view, so this is a cache hit. No mbid (stale passthrough) ->
        # skip the rival rule rather than force a fetch.
        if ($ambid) {
            Plugins::Discography::API->getReleaseGroups(
                mbid   => $ambid,
                onDone => sub {
                    my $rgs = shift;
                    # Same type filter as the list view — the detail page must
                    # compute the SAME owner, or a drill-in disagrees with the
                    # tile that opened it (the 0.18.0 class of bug).
                    my $rivals = _rivalsByTitle($rgs,
                        Plugins::Discography::API->peekOfficial($ambid),
                        _shownTypes());
                    # ... and the same edition titles, or the drill-in drops a
                    # match the tile shows.
                    my $eds = _editionTitles($rgs, Plugins::Discography::API->peekEditions($ambid));
                    $finish->($rivals->{ Plugins::Discography::Sources::_norm($rg->{title}) },
                              $eds->{ $rg->{mbid} }, _idGroups($rgs));
                },
                onError => sub { $finish->(undef) },
            );
        }
        else {
            $finish->(undef);
        }
    };

    # The list page's options (_poolOpts), or a cold detail page would build the
    # pool under a different name, or with a looser check, than its tile's page.
    _poolOpts($artist, $pass->{mbid}, $dSpine, sub {
        Plugins::Discography::Sources->getCandidates($client, $artist, 0, $withCands, $_[0]);
    });
}

1;
