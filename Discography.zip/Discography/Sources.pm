package Plugins::Discography::Sources;

# Streaming-source resolution — a port of the Pitchfork Reviews plugin's
# trimmed ListenBrainz engine, restructured for discography scale:
#
#   * PFR resolves ONE album per search (artist query, first-priority winner).
#     Here ONE artist-level search per service is cached and serves EVERY
#     release group of that artist — resolving a 50-release discography costs
#     the same 3 searches as resolving one album.
#   * ALL matching services are kept (the detail page lists every service's
#     version); priority only orders the sections (and later, tile play).
#
# The matcher (_norm/_albumMatches/_artistMatch and helpers) is verbatim from
# the Pitchfork/ListenBrainz plugins — keep in sync if those change.
#
# Candidate cache: dsc:cand:<v>:<svc>:<norm-artist> holds the service's raw
# artist-search results (rendered native album nodes, url coderef stripped —
# Storable can't serialise it — and reattached on read). Per-release matching
# is then a local filter: no API call, safe in sync paths (tile badges).

use strict;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::PluginManager;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Time::HiRes ();

# The FUNCTION form (0.56.16): LMS's logger() takes the category as its first
# argument, so `Slim::Utils::Log->logger(...)` filed this file's lines under
# "Slim::Utils::Log" and dropped everything below WARN (Slim/Utils/Log.pm).
my $log   = logger('plugin.discography');
my $prefs = preferences('plugin.discography');
# The plugin's own store (DB.pm), version-scoped -- see the note in API.pm.
# MUST match API.pm exactly (asserted by tools/syntax_check.sh).
use Plugins::Discography::DB;
use constant CACHE_VERSION => '0.56.70';
my $cache = Plugins::Discography::DB->store(CACHE_VERSION);

sub _dbg { Plugins::Discography::Plugin::dbg(@_) }

use constant CAND_FOUND_TTL => 3 * 86400;   # service discography is stable-ish
use constant CAND_EMPTY_TTL => 1 * 86400;   # artist not on the service
use constant CAND_ERR_TTL   => 3600;        # couldn't query -> retry soon
use constant SVC_TIMEOUT    => 20;          # per-service fetch watchdog (s).
                                            # Sized for the artist-first chain:
                                            # an artist search THEN the artist's
                                            # album list (Tidal: 3 paginated
                                            # bucket pulls). The old 8s was
                                            # sized for a single 50-item search.
# Copies kept per service per release (0.56.51: was 4, which cut real editions
# and, as a copy past the cap counts as unclaimed, sent them to "Also on
# streaming"). A bound against a generic title pulling in a long tail, not a
# display choice: every edition a service lists for a release fits under it.
use constant MAX_PER_SVC    => 20;
use constant POOL_LOG_MAX   => 25;          # log a pool this small IN FULL

# PERFORMANCE roles — the artist must PERFORM (solo, primary, band member or
# guest), not merely have WRITTEN a song that appears. 0.19.0 added this to the
# library album query after Bob Dylan's page filled with albums he only wrote a
# track on (Richard Hawley, George Harrison, Ladysmith Black Mambazo).
#
# ONE constant, used by BOTH the library album query AND the artist SEARCH's
# Local leg, because the two disagreeing is itself a bug: 0.19.0 filtered the
# PAGE and left the SEARCH unfiltered, so a writer-only contributor was offered
# as a "Local" search row and then opened a page that found nothing under them
# (field, Simon: "several artists that claim are local but show no entries" —
# John Bush / Steven Bush / David Bush, composer credits in his library).
# Library rows are also EXEMPT from the dead-end filter, so nothing downstream
# could catch it either. Spelling the policy once is what stops it drifting
# apart again — widen this if composer support is ever built, and both call
# sites widen together.
use constant PERFORMANCE_ROLES => 'ARTIST,ALBUMARTIST,BAND,TRACKARTIST';
use constant CAND_CACHE_V   => '5';         # bump on shape/matcher changes (5: _size)
                                            # v2: flush octet-query poisoned pools
                                            # v3: artist-first pools (search-cap
                                            #     lottery dropped e.g. Valtari)
                                            # v4: candidates carry _year (needed
                                            #     by the same-title rival rule)
use constant SEARCH_TIMEOUT => 10;          # artist-search watchdog (s) — one
                                            # request per service, not the full
                                            # artist-first candidate chain
use constant SEARCH_MAX     => 15;          # artist hits kept per source
use constant PUNCT_PROBE_MAX     => 2;      # term probes on a Local miss
use constant PUNCT_PROBE_MIN_LEN => 4;      # skip "the"/"of" as probe terms
use constant SEARCH_MERGED_MAX => 30;       # merged result rows shown
use constant LOCAL_TRACKS_MAX  => 2000;     # owned tracks scanned for track-linking

# ---------------------------------------------------------------------------
# Adapters (ported from PFR; Qobuz/Tidal/Deezer, plus Spotify via Spotty (0.55.0) — no Bandcamp by scope)
# ---------------------------------------------------------------------------

sub _pluginIcon {
    my ($class) = @_;
    return eval { $class->_pluginDataFor('icon') } || undef;
}

sub adapters {
    my @adapters;

    # query_enc: what the service plugin's OWN URL layer expects for the search
    # string (verified in each plugin's source, 2026-07-10). Qobuz escapes
    # query params with uri_escape_utf8 and Tidal transliterates them with
    # Text::Unidecode — both need CHARACTER strings (feeding UTF-8 octets
    # double-encodes: "Sigur Rós" searched as "Sigur RÃ³s" -> junk/empty
    # pools). Deezer's complex_to_query percent-encodes bytes -> OCTETS.
    push @adapters, {
        name => 'Qobuz', icon => _pluginIcon('Plugins::Qobuz::Plugin'),
        run  => \&_searchQobuz, artists => \&_artistsQobuz, query_enc => 'chars',
        rebuild => Plugins::Qobuz::Plugin->can('QobuzGetTracks'),
    } if Plugins::Qobuz::Plugin->can('getAPIHandler')
      && Plugins::Qobuz::Plugin->can('_albumItem')
      && Plugins::Qobuz::Plugin->can('QobuzGetTracks');

    push @adapters, {
        name => 'Tidal', icon => _pluginIcon('Plugins::TIDAL::Plugin'),
        run  => \&_searchTidal, artists => \&_artistsTidal, query_enc => 'chars',
        rebuild => Plugins::TIDAL::Plugin->can('getAlbum'),
    } if Plugins::TIDAL::Plugin->can('getAPIHandler')
      && Plugins::TIDAL::Plugin->can('getAlbum')
      && Plugins::TIDAL::Plugin->can('_renderAlbum');

    push @adapters, {
        name => 'Deezer', icon => _pluginIcon('Plugins::Deezer::Plugin'),
        run  => \&_searchDeezer, artists => \&_artistsDeezer, query_enc => 'bytes',
        rebuild => Plugins::Deezer::Plugin->can('getAlbum'),
    } if Plugins::Deezer::Plugin->can('getAPIHandler')
      && Plugins::Deezer::Plugin->can('_renderAlbum')
      && Plugins::Deezer::Plugin->can('getAlbum');

    # Spotify via Spotty (docs/spotify-adapter-plan.md). Probes exactly the
    # three Spotty subs it calls. Spotty ships its OWN working favurl
    # (`spotify:album:<id>`), and decorating it would break a saved favourite:
    # its album() takes the id with a greedy /album:(.*)/ (native_favurl).
    # Kept out of the artist-photo walk (artist_image => 0): the walk runs with
    # no client, which Spotty's getAPIHandler refuses, and _svcArtistImage has
    # no Spotify branch, so an exact Spotify artist without a photo would only
    # veto another service's.
    push @adapters, {
        name => 'Spotify', icon => _pluginIcon('Plugins::Spotty::Plugin'),
        run  => \&_searchSpotify, artists => \&_artistsSpotify, query_enc => 'chars',
        rebuild       => Plugins::Spotty::OPML->can('album'),
        native_favurl => 1,
        artist_image  => 0,
    } if Plugins::Spotty::Plugin->can('getAPIHandler')
      && Plugins::Spotty::OPML->can('_albumItem')
      && Plugins::Spotty::OPML->can('album');

    return @adapters;
}

# Enabled adapters in ascending svc_priority_<name> order, dropping 0 (= off).
sub orderedAdapters {
    my @out;
    for my $a (adapters()) {
        my $prio = $prefs->get('svc_priority_' . lc $a->{name});
        $prio = 1 unless defined $prio;
        next unless $prio > 0;
        push @out, { %$a, priority => $prio };
    }
    return sort { $a->{priority} <=> $b->{priority} } @out;
}

# All sources (Local + streaming) in priority order — the ordering matchesFor
# uses. Local is a pseudo-source: its candidates come from the library DB
# (localAlbums), not a search adapter; svc_priority_local 0 disables it.
sub orderedSources {
    my @out;
    my $lp = $prefs->get('svc_priority_local');
    $lp = 1 unless defined $lp;
    push @out, { name => 'Local', icon => undef, priority => $lp, local => 1 } if $lp > 0;
    push @out, orderedAdapters();
    return sort { $a->{priority} <=> $b->{priority} } @out;
}

# ---------------------------------------------------------------------------
# Local library albums for an artist — SYNC (LMS DB access is synchronous, the
# fleet's accepted pattern) and NOT cached (the library is live; a rescan must
# show immediately). One `albums` CLI query per call; candidates are decorated
# exactly like streaming ones so the matcher treats them identically.
# ---------------------------------------------------------------------------
# Encode BEFORE folding, so a key cannot depend on which shape the name arrived
# in (a CLI param and a decoded JSON string differ). Mirrors API::_nameKey.
#
# DEFENSIVE, NOT A FIX -- and worth stating, because I first believed otherwise:
# I expected raw _norm to disagree across encodings (the 0.43.3 trap) and wrote
# a test control asserting it. The control DISPROVED it -- 0.44.26's %FOLD
# extension already handles both shapes (tools/t_local.pl). The real defect was
# only ever the missing ASCII-folded QUERY below.
sub _normKey {
    my ($s) = @_;
    $s = defined $s ? $s : '';
    utf8::encode($s) if utf8::is_utf8($s);
    return _norm($s);
}

# ---------------------------------------------------------------------------
# ONE LOCAL ARTIST LOOKUP FOR BOTH ENTRY PATHS.
#
# Simon, 2026-07-22: "we need to ensure all fixes we do for matching are done
# across matching from the rows in Artists and via our search." The &/and retry
# (0.44.23) and the punctuation probe (0.44.26) were built into searchArtists'
# Local leg ONLY; localAlbums' name fallback never got them, so the same "you
# do not own this artist" bug was still live whenever an artist was reached BY
# NAME -- a search drill-in, a similar-artist link or a band link.
#
# Measured before writing this (browse by name, 0.45.1):
#   Björk 0 local · Röyksopp 0 · The B‐52's 0 · Sigur Rós 5
# against browse by artist_id, which is correct for all four. LMS itself finds
# every one of them, so the library was never the problem.
#
# The ladder, cheapest first, each step only on a total miss:
#   1. the text as typed
#   2. the &/and variant          (LMS does not fold "&" against "and")
#   3. the ASCII-FOLDED spelling  (LMS's index DOES fold accents -- verified
#      live: `search:Bjork` returns Björk -- and this is the step that recovers
#      a SINGLE-WORD accented name, which the term probe below cannot)
#   4. the most selective terms   (recovers apostrophes/hyphens: `search:Jane`
#      finds "Jane's Addiction")
# Rows from the recovery steps are norm-verified by the CALLER, so widening the
# net here cannot adopt a wrong artist.
# ---------------------------------------------------------------------------
# LMS'S OWN QUERIES MATCH CHARACTER STRINGS, NEVER OCTETS (0.51.2)
#
# Every `search:` we hand to `executeRequest` ends up in a DBI query whose
# handle has unicode ON, so DBI encodes what it is given: a CHARACTER string
# matches, and a UTF-8 OCTET string is encoded a second time and matches
# nothing. Measured live against Simon's library, same query both ways:
#
#     search string          as CHARACTERS   as OCTETS
#     ---------------------------------------------------------
#     Bjork/Björk                  1               0
#     Sigur Rós                    1               0
#     Röyksopp                     1               0
#     \x{a27a}\x{10da}             1               0
#
# So the ladder below was ENCODING ITS WAY OUT OF EVERY NON-ASCII MATCH, and
# the "the ASCII fold rescued Björk/Röyksopp/ROSALÍA" result recorded in
# 0.45.1 was that bug wearing a disguise: the fold only ever won because it
# produces pure ASCII, where octets and characters are the same bytes. For an
# artist whose name has NO ASCII to fold to (Simon's braille/Yi/Georgian act,
# field 2026-07-31) nothing in the ladder could ever match, the search row got
# no Local source, and the album he owns resolved to a streaming service.
#
# NB the OPPOSITE rule applies to `$cache` (Slim::Utils::DbCache): it dies
# "Wide character in subroutine entry" on a character string, so cache KEYS and
# raw string VALUES are encoded — see `_candKey` and API::_mbNameKey. Two
# neighbouring LMS APIs, two opposite requirements; neither is negotiable.
sub _cliChars {
    my ($s) = @_;
    return $s unless defined $s && !utf8::is_utf8($s);
    my $d = $s;
    # Octets that are not valid UTF-8 are left exactly as they are: a failed
    # decode must not mangle a name that might still match as-is.
    return utf8::decode($d) ? $d : $s;
}

# ---------------------------------------------------------------------------
# $opt->{no_probe} skips the TERM PROBES only (the spelling ladder still runs).
# The probes are the widest net and exist to rescue a MANGLED USER-TYPED string
# ("b52s"); when the caller already holds a canonical artist name — as
# attachLibraryArtists does, straight off a service row — they cost two extra
# CLI queries per lookup and cannot add a hit the spelling ladder would miss.
# Measured 2026-07-22: they were 20 of the 30 queries a 10-row search made.
# DEFAULT IS UNCHANGED, so localAlbums and the search Local leg keep the net.
sub _localArtistRows {
    my ($text, $opt) = @_;
    $opt ||= {};
    return [] unless defined $text && length $text;

    my $enc = _cliChars($text);

    my @tries = ($enc);
    my $alt   = $enc;
    if    ($alt =~ s/\s*&\s*/ and /g)  { push @tries, $alt }
    elsif ($alt =~ s/\s+and\s+/ & /gi) { push @tries, $alt }

    # ASCII fold: strip combining marks, then drop anything still non-ASCII.
    my $dec = $text;
    utf8::decode($dec) unless utf8::is_utf8($dec);
    my $fold = $dec;
    if (eval { require Unicode::Normalize; 1 }) {
        $fold = Unicode::Normalize::NFD($fold);
        $fold =~ s/\p{NonspacingMark}//g;
    }
    # TYPOGRAPHIC PUNCTUATION MUST BE TRANSLITERATED, NOT STRIPPED. It is not a
    # combining mark, so NFD leaves it intact, and deleting it JOINS the words:
    # "Yo‐Yo Ma" (U+2010 HYPHEN) became "YoYo Ma", which LMS cannot match --
    # measured, this is why The B‐52's and Yo‐Yo Ma still failed after the fold
    # recovered Björk/Röyksopp/ROSALÍA. Map to the ASCII the library actually
    # holds, THEN drop anything still non-ASCII.
    $fold =~ tr/\x{2010}\x{2011}\x{2012}\x{2013}\x{2014}\x{2015}\x{2212}/\-\-\-\-\-\-\-/;
    $fold =~ tr/\x{2018}\x{2019}\x{201A}\x{201B}\x{2032}/'''''/;
    $fold =~ tr/\x{201C}\x{201D}\x{201E}\x{201F}\x{2033}/"""""/;
    $fold =~ s/\x{2026}/.../g;
    $fold =~ s/[^\x00-\x7F]//g;
    $fold =~ s/\s+/ /g;
    $fold =~ s/^\s+|\s+$//g;
    push @tries, $fold if length $fold && $fold ne $enc;

    my $run = sub {
        my ($q) = @_;
        my $req = eval { Slim::Control::Request::executeRequest(undef,
            ['artists', 0, SEARCH_MAX, "search:$q", 'role_id:' . PERFORMANCE_ROLES]) };
        return () unless $req;
        return grep { defined $_->{name} && length $_->{name} }
               map  { { name => $_->{artist}, artist_id => $_->{id} } }
               @{ $req->getResult('artists_loop') || [] };
    };

    # $opt->{how} (a scalar ref) is told which step answered: 'typed' for the
    # spelling as given, 'variant' for the &/and or ASCII-fold spelling, 'probe'
    # for a term probe. The search keeps every hit of the typed spelling and
    # narrows only the recovery steps' (searchArtists).
    my $how = sub { ${ $opt->{how} } = $_[0] if ref $opt->{how} eq 'SCALAR' };
    for my $try (@tries) {
        my @hits = $run->($try);
        if (@hits) {
            _dbg("Local lookup '$text': matched " . scalar(@hits)
                 . ($try eq $enc ? '' : " via variant '$try'"));
            $how->($try eq $enc ? 'typed' : 'variant');
            return \@hits;
        }
    }

    # Term probes last -- widest net, so it runs only when everything else missed.
    if ($opt->{no_probe}) {
        _dbg("Local lookup '$text': no library artist found (tried "
             . scalar(@tries) . ' spelling(s), term probes skipped)');
        return [];
    }
    # The length floor drops a probable ASCII STOPWORD ("the"/"of") -- but only
    # when the token is ASCII. A short NON-ASCII token is a whole word in a dense
    # script (CJK/Yi/Georgian/Tamil...), never a stopword, and is often the ONLY
    # handle LMS indexes for a name it cannot match whole. Field 2026-07-23: an
    # artist whose name is symbols + combining marks whose sole searchable token
    # is "\x{a27a}\x{10da}" (2 chars) -- the exact spelling AND the ASCII fold
    # both return nothing, so this probe is the only route to the owned album,
    # which otherwise resolves to a streaming service instead of Local.
    my @terms = sort { length($b) <=> length($a) || $a cmp $b }
                grep { length($_) >= PUNCT_PROBE_MIN_LEN || /[^\x00-\x7f]/ }
                split /[^\p{Alnum}]+/, $dec;
    for my $term (grep { defined } @terms[0 .. PUNCT_PROBE_MAX - 1]) {
        my @hits = $run->(_cliChars($term));
        if (@hits) {
            _dbg("Local lookup '$text': matched " . scalar(@hits) . " via term probe '$term'");
            $how->('probe');
            return \@hits;
        }
    }
    _dbg("Local lookup '$text': no library artist found (tried "
         . scalar(@tries) . ' spelling(s) + term probes)');
    return [];
}

# THE PARTS OF A JOINT CREDIT (0.48.6) — canonical for the whole plugin.
# API::_creditHead delegates here, so "what counts as a joint credit" has ONE
# definition and the MB side and the library side cannot drift apart.
#
# Separators need spaces around them, so an ampersand INSIDE a name survives
# ("AC/DC", "Hall & Oates").
#
# NO LENGTH RULE HERE, deliberately — and the first cut had one, which broke
# `_creditHead`'s "Stan Getz / A / B" case (it only ever checked the HEAD). Each
# caller already applies a test far stronger than a character count: the
# resolver requires its head to be >= 3 and to resolve on MusicBrainz, and the
# library lookup requires EVERY part to resolve to a real contributor by exact
# normalised name. "A" is refused because no contributor is called "A", not
# because it is one letter.
our $CREDIT_SPLIT = qr{\s+(?:/|&|\+|feat\.?|featuring|with|and|vs\.?|versus)\s+}i;

sub _creditParts {
    my ($name) = @_;
    return () unless defined $name && $name =~ $CREDIT_SPLIT;
    my @p = split $CREDIT_SPLIT, $name;
    for my $x (@p) { $x =~ s/^\s+|\s+$//g }
    @p = grep { length } @p;
    return () unless @p >= 2;
    return @p;
}

# TWO INDEPENDENT INCONSISTENCIES, so a joint credit needs matching from BOTH
# ends (Simon, 2026-07-22: *"some users might tag it as Robert Plant & Alison
# Krauss, same as they might for Panda Bear and Sonic Boom ... MB isn't itself
# consistent with doing this, some are new artists entirely"*).
#
#                     | library: separate contributors | library: one joint
#   ------------------+--------------------------------+--------------------
#   MB HAS a joint    | the duo's page finds NOTHING   | works (name matches)
#   artist (Plant &   | <- Simon's Raising Sand        |
#   Krauss, 38eb4af8) |                                |
#   ------------------+--------------------------------+--------------------
#   MB has NO joint   | works (0.47.0 splits to the    | album INVISIBLE: the
#   artist (Cave &    | head act, who IS a contributor)| head act has no
#   Ellis, PB & SB)   |                                | contributor at all
#
# Only the diagonal worked. Measured on Simon's library, both contributors hold
# the record — LMS honours a `;`-separated ALBUMARTIST correctly, and it is the
# `albums` query's single DISPLAY string that collapses, not the join:
#     artist_id 56743 Robert Plant  -> 19127 Raising Sand
#     artist_id 56744 Alison Krauss -> 19127 Raising Sand
# while MusicBrainz models a THIRD artist his library has no contributor for.
#
# ONE symmetric rule fixes both corners, treating a joint name as the SET of
# its parts whichever side it appears on:
#   * browsed name is joint, the library has the parts -> INTERSECT their album
#     sets. The intersection IS the duo's catalogue by construction, so no
#     amount of solo work can leak in and "Also in your library" stays honest.
#   * browsed name is single, a library contributor is joint AND NAMES IT as
#     one of its parts -> that contributor counts too.
sub _jointRows {
    my ($an, $rows) = @_;
    return grep {
        my @p = _creditParts($_->{name} // '');
        @p >= 2 && grep { _normKey($_) eq $an } @p;
    } @$rows;
}

# (B) on its own, for the identity-first path (review 2026-09-19): when the
# library's MusicBrainz tag has already said WHO the artist is, the name may
# only ADD joint credits naming them, and (since 2026-10-07) the artist's own
# UNTAGGED exact-name entries (_untaggedNamesakes) — never a same-name
# contributor TAGGED with another id, which the tag rules out. Without this the
# tag path dropped every collaboration the name ladder used to add (live: Holly
# Golightly lost the two albums owned under "Holly Golightly and The Brokeoffs").
sub _jointArtistIds {
    my ($artist, $exclude) = @_;
    return () unless defined $artist && length $artist;
    my @rows = grep { !$exclude || ($_->{artist_id} // '') ne $exclude }
               @{ _localArtistRows($artist, { no_probe => 1 }) };
    return grep { $_ } map { $_->{artist_id} } _jointRows(_normKey($artist), \@rows);
}

sub _localArtistIds {
    my ($artist, $exclude) = @_;
    my $an = _normKey($artist);
    my @rows = @{ _localArtistRows($artist) };
    # A fallback from an EMPTY contributor must not pick that contributor again
    # (localAlbums' fallback; it can be the first exact hit LMS lists).
    @rows = grep { ($_->{artist_id} // '') ne $exclude } @rows if $exclude;
    my ($exact) = grep { _normKey($_->{name}) eq $an } @rows;

    # (B) Joint contributors naming this artist as a part. Deliberately NOT
    # gated on a miss, unlike (A): a user owning BOTH a plain "Nick Cave"
    # contributor and a "Nick Cave & Warren Ellis" one must get both, or the
    # collaboration silently disappears from the page it belongs on. The test
    # is part EQUALITY, never substring, so "Nick Cave" cannot pick up
    # "Nick Cavendish & Friends".
    my @joint = _jointRows($an, \@rows);

    if ($exact || @joint) {
        my @ids = map { $_->{artist_id} }
                  grep { $_ && $_->{artist_id} } ($exact ? ($exact) : ()), @joint;
        my (%seen, @uniq);
        push @uniq, $_ for grep { !$seen{$_}++ } @ids;
        return (\@uniq, 0) if @uniq;
    }

    # (A) The browsed name is itself a joint credit and the library files it as
    # its members. EVERY part must resolve to a contributor, or there is no
    # intersection to take and a half-match could speak for the wrong act.
    my @parts = _creditParts($artist);
    return ([], 0) unless @parts >= 2;
    my @pid;
    for my $p (@parts) {
        my $pn = _normKey($p);
        my ($hit) = grep { _normKey($_->{name}) eq $pn }
                    @{ _localArtistRows($p, { no_probe => 1 }) };
        return ([], 0) unless $hit && $hit->{artist_id};
        push @pid, $hit->{artist_id};
    }
    return (\@pid, 1);
}

sub localAlbums {
    my ($class, $artistId, $artist, $mbid, $opt) = @_;
    $opt ||= {};
    return [] unless ($prefs->get('svc_priority_local') // 1) > 0;

    my $explicitId = $artistId;
    my @ids      = $artistId ? ($artistId) : ();
    my $intersect = 0;

    # IDENTITY FIRST (0.51.3): the MusicBrainz artist we are browsing, matched
    # against the library's own contributor tag. Exact, spelling-proof, one
    # local DB read, and it runs BEFORE the name ladder — which stays exactly
    # as it was for every untagged library, and still runs whenever this finds
    # nothing. An explicit artist_id (an Artists row, a search row that already
    # attached) still outranks it: that is the user pointing at a contributor —
    # UNLESS it performs on no album at all and the caller opted in to a
    # fallback (see the end of this sub).
    if (!@ids && $mbid) {
        # The tag's contributors + the artist's own untagged entry (2026-10-07,
        # localArtistIdsByIdentity: a joint credit carrying the tag must not
        # stand in for the artist's own albums).
        my @byMbid = localArtistIdsByIdentity($mbid, $artist, $opt->{exclude});
        if (@byMbid) {
            my %have = map { $_ => 1 } @byMbid;
            my @joint = grep { !$have{$_}++ } _jointArtistIds($artist, $opt->{exclude});
            @ids = (@byMbid, @joint);
            _dbg("localAlbums: mbid $mbid -> artist_id " . join('+', @byMbid)
                 . ' (library MusicBrainz tag)'
                 . (@joint ? ' + joint credit(s) ' . join('+', @joint) : ''));
        }
    }

    # No artist_id (non-library entry surface): resolve by name, norm-verified
    # so a fuzzy `artists search:` can't adopt the wrong artist.
    if (!@ids && defined $artist && length $artist) {
        my ($found, $needAll) = _localArtistIds($artist, $opt->{exclude});
        @ids       = @$found;
        $intersect = $needAll;
        _dbg("localAlbums: name '$artist' -> "
             . (@ids ? 'artist_id ' . join('+', @ids)
                       . ($intersect ? ' (joint credit, intersected)' : '')
                     : 'NO library artist'));
        return [] unless @ids;
    }
    return [] unless @ids;
    $artistId = $ids[0];

    # PERFORMANCE roles only — the artist must PLAY on the album, not merely
    # have written a song that appears on it. The default `albums artist_id:`
    # query spans ALL contributor roles (LMS Queries.pm: contributorRoles()),
    # so a covers/compilation album drags in every writer: under Bob Dylan it
    # surfaced Richard Hawley, George Harrison, Ladysmith Black Mambazo — albums
    # Dylan only WROTE a track on (Simon, 2026-07-10). role_id restricts the
    # contributor_album join to these roles (LMS adds ARTIST automatically for
    # ALBUMARTIST when the artists list isn't unified).
    #   ARTIST / ALBUMARTIST -> solo + primary credits
    #   BAND / TRACKARTIST   -> band membership + guest performances (kept:
    #                           "appears on" is fine per the user)
    # KNOWN LIMIT: a band album whose member is tagged ONLY as COMPOSER (no
    # performer credit) drops too — e.g. Marc Almond is COMPOSER-only on Soft
    # Cell's "Non-Stop Erotic Cabaret" in Simon's library, indistinguishable
    # from a write-only cover credit. Separating those needs a MusicBrainz
    # "member of band" lookup (future); no library signal exists (track-fraction
    # fails: that album tags Almond on just 2/18 tracks).
    #
    # ONE query per contributor (normally exactly one). With $intersect the
    # album must appear under EVERY part of the joint credit — that is what
    # makes the result the duo's catalogue rather than the union of two solo
    # discographies. Without it the sets are merged, deduped by album id.
    my (@rows, %seenAlbum, %hits, %listedUnder);
    for my $id (@ids) {
        my $r = eval {
            Slim::Control::Request::executeRequest(undef,
                ['albums', 0, 500, "artist_id:$id",
                 'role_id:' . PERFORMANCE_ROLES, 'tags:ljyaWS']);
        };
        next unless $r;
        for my $e (@{ $r->getResult('albums_loop') || [] }) {
            next unless $e->{id};
            # The contributor that LISTED this album (the first, when a name
            # resolved to duplicates): the id "Filter album tracks" narrows by,
            # the same id and roles that found it here.
            $listedUnder{ $e->{id} } //= $id;
            $hits{ $e->{id} }++;
            push @rows, $e unless $seenAlbum{ $e->{id} }++;
        }
    }
    @rows = grep { $hits{ $_->{id} } == scalar @ids } @rows if $intersect;

    # AN EXPLICIT ID THAT PERFORMS ON NOTHING (field, The B-52's, 2026-09-19).
    # LMS's own search lists every contributor, including one that exists only
    # as a COMPOSER credit ("The B-52's", one track's composer tag) while the
    # band's albums sit under "The B-52s". Tapping it opened a page with nothing
    # Local. An id with no album cannot be what the user meant, so a caller may
    # opt in ($opt->{fallback}) to resolve again WITHOUT it: the MB tag first,
    # then the name — 'name' mode only; a same-name page passes 'mbid' so it
    # never borrows the other act's catalogue. The empty id is excluded so the
    # name ladder cannot land on it again. An id owning even one album never
    # gets here, so it costs nothing.
    if (!@rows && $explicitId && $opt->{fallback}) {
        _dbg("localAlbums: artist_id $explicitId performs on no album - falling back ("
             . $opt->{fallback} . ')');
        return $class->localAlbums(undef,
            ($opt->{fallback} eq 'name' ? $artist : undef), $mbid,
            { exclude => $explicitId });
    }
    return [] unless @rows;

    # ONE ALBUM NEVER CLAIMS ANOTHER (0.56.43; Simon, 2026-10-03, on Dean
    # Martin's "Greatest Hits" tile reading Local off Nancy Sinatra's "Greatest
    # Hits", where he sings one duet: "all that needs to happen is to not try
    # and claim tracks from one album for another"). The performance-role join
    # also returns albums the artist is only CREDITED ON (someone else's album,
    # a compilation), and matchesFor gates every Local candidate on the browsed
    # artist, so one of those could claim a same-titled tile. An album credited
    # TO the artist - he is one of its album artists or its band (Raising Sand:
    # Robert Plant AND Alison Krauss), or LMS files it under him (no album
    # artist tag) - keeps that gate. Any other is marked `_otherArtist` and
    # matched under its OWN album artist, as a streaming copy is, so it claims
    # nothing here and stays under Appearances, where it is listed today. The
    # two roles are asked together: `role_id:ALBUMARTIST` alone makes LMS add
    # ARTIST (measured 2026-10-03: Dean Martin 4 albums, two of them Various
    # Artists compilations; ALBUMARTIST,BAND 2, his own). Credits that cannot
    # be read mark nothing: today's matching, never a co-credit demoted.
    my (%credited, $creditsRead);
    $creditsRead = 1;
    for my $id (@ids) {
        my $r = eval {
            Slim::Control::Request::executeRequest(undef,
                ['albums', 0, 500, "artist_id:$id", 'role_id:ALBUMARTIST,BAND', 'tags:l']);
        };
        unless ($r) { $creditsRead = 0; last }
        $credited{ $_->{id} } = 1 for grep { $_->{id} } @{ $r->getResult('albums_loop') || [] };
    }
    my %isId = map { $_ => 1 } @ids;

    # MUSICBRAINZ_ALBUMID off the tags, read straight from the schema: the
    # `albums` CLI query exposes no MusicBrainz tag (verified against LMS 9.0
    # Queries.pm), but Slim::Schema::Album carries musicbrainz_id. It holds a
    # RELEASE mbid, which API::peekReleaseMap turns into a release-GROUP mbid —
    # an exact identity match, no title matching. Guarded: an untagged library
    # or a schema change just falls through to the matcher.
    my $mbidOf = sub {
        my $albumId = shift;
        return eval { require Slim::Schema; Slim::Schema->find('Album', $albumId)->musicbrainz_id } || undef;
    };

    my @out;
    for my $e (@rows) {
        my $id    = $e->{id}    or next;
        my $title = $e->{album} // next;
        my $img   = $e->{artwork_track_id} ? "/music/$e->{artwork_track_id}/cover" : undef;
        my $mbid  = $mbidOf->($id);
        push @out, {
            name        => $title,
            type        => 'playlist',
            ($img ? (image => $img) : ()),
            # Playable two ways: `play` is a core db: URL (Commands.pm
            # _parseDbItem resolves album.id -> the album's tracks — the exact
            # path album Favorites replay through), and the row's url feed is
            # the tracklist (drill = track view). The play string is ALSO what
            # makes local-first TILE play work: XMLBrowser's play collects the
            # detail feed's play-string rows (verified in 9.0 source).
            play        => 'db:album.id=' . $id,
            url         => \&_localAlbumTracks,
            # The library artist this album was listed under (_listedUnder, below)
            # rides the passthrough too, for the drill-in that is not Material's
            # (_localAlbumTracks).
            passthrough => [{ album_id => $id,
                              (($intersect || !$listedUnder{$id}) ? () : (artist_id => $listedUnder{$id})) }],
            _svc        => 'Local',
            _albumid    => $id,
            # The contributor that listed this album, for "Filter album tracks"
            # (libraryAlbumActions). None for a joint credit matched by
            # intersection: those albums are the duo's own, every track is theirs.
            (($intersect || !$listedUnder{$id}) ? () : (_listedUnder => $listedUnder{$id})),
            _cover      => $img,
            _year       => $e->{year},
            _mbid       => ($mbid ? lc $mbid : undef),
            _candTitle  => $title,
            _candArtist => $e->{artist} // $artist,
            _reltype    => $e->{release_type},   # RELEASETYPE tag (LMS default ALBUM) - _localSize
            # Credited to someone else (above): matched under its own album
            # artist. `artist_id` is the album's contributor (tags:S).
            ((!$creditsRead || $credited{$id}
              || grep { $isId{$_} } split /,/, ($e->{artist_id} // ''))
                ? () : (_otherArtist => 1)),
        };
    }
    _dbg("local albums for artist_id=" . join("+", @ids) . ": " . scalar @out
        . (@out ? ' | ' . join('; ', map {
              ($_->{_candTitle} // '?') . ' mbid=' . ($_->{_mbid} // 'NONE')
                  . ($_->{_otherArtist} ? ' (credited to ' . ($_->{_candArtist} // '?') . ')' : '')
          } @out) : ''));
    return \@out;
}

# Owned TRACKS for the artist — the track-level twin of localAlbums, for a
# release the user owns only as a VARIOUS ARTISTS COMPILATION TRACK (Simon: an
# act's single he owns only via a Nuggets/Pushin'-Too-Hard comp; VA-only since
# 0.51.9). Same PERFORMANCE-role gate as localAlbums, applied to the per-role
# ids because `titles` ignores role_id; same id-vs-name resolution, including
# the empty-id fallback (gated on the id owning no album, 0.51.11). Each track carries a direct
# `db:track.id` play string and the comp it lives on (for the row hint). Fetched
# LAZILY by the caller (only when a release goes otherwise-unmatched), so an
# artist owned as albums never pays for it.
sub localTracks {
    my ($class, $artistId, $artist, $opt) = @_;
    $opt ||= {};
    return [] unless ($prefs->get('svc_priority_local') // 1) > 0;

    my @ids = $artistId ? ($artistId) : ();
    # The tag, when a fallback hands one over (localAlbums' identity-first).
    if (!$artistId && $opt->{mbid}) {
        # The tag's contributors + the artist's own untagged entry, as localAlbums.
        @ids = localArtistIdsByIdentity($opt->{mbid}, $artist, $opt->{exclude});
        # Joint credits naming the artist, as localAlbums' tag path adds them.
        if (@ids) {
            my %have = map { $_ => 1 } @ids;
            push @ids, grep { !$have{$_}++ } _jointArtistIds($artist, $opt->{exclude});
        }
    }
    if (!@ids && !$artistId && defined $artist && length $artist) {
        my ($found) = _localArtistIds($artist, $opt->{exclude});
        @ids = @$found;
        return [] unless @ids;
    }
    return [] unless @ids;

    # `titles` IGNORES role_id once any tag is requested (measured live on LMS
    # 9.1, 2026-09-19: BAND, COMPOSER, a number or no role_id at all return the
    # same rows), so the gate never held here: a composer-only contributor got
    # the tracks it WROTE, and any artist's pool carried other people's covers
    # of his songs. The role_id stays (harmless, and right if LMS ever honours
    # it); the gate is applied to the per-role ids `tags:S` returns. A row
    # carrying no role ids at all cannot be judged and is kept, as before.
    my @perfKeys = qw(artist_ids albumartist_ids trackartist_ids band_ids);
    my (@out, %seen);
    for my $id (@ids) {
        my $r = eval {
            Slim::Control::Request::executeRequest(undef,
                ['titles', 0, LOCAL_TRACKS_MAX, "artist_id:$id",
                 'role_id:' . PERFORMANCE_ROLES, 'sort:album', 'tags:ulJCS']);
        };
        next unless $r;
        for my $e (@{ $r->getResult('titles_loop') || [] }) {
            next unless $e->{id} && defined $e->{title} && length $e->{title};
            # VARIOUS ARTISTS COMPILATIONS ONLY (Simon, 2026-09-19). A track on
            # the act's OWN album or own compilation linked every same-titled
            # single ("Rock Lobster" off The B-52's) and a two-album set off a
            # title track, reading Local for records he does not own. Those
            # albums match their own release groups; only a VA comp (LMS's
            # compilation flag, `tags:C`) holds a song nothing else can reach.
            next unless ($e->{compilation} // '') eq '1';
            if (grep { defined $e->{$_} } @perfKeys, 'composer_ids', 'conductor_ids') {
                next unless grep { $_ eq $id }
                            map  { split /,/, ($e->{$_} // '') } @perfKeys;
            }
            next if $seen{ $e->{id} }++;
            my $img = $e->{artwork_track_id} ? "/music/$e->{artwork_track_id}/cover" : undef;
            push @out, {
                name        => $e->{title},
                type        => 'audio',
                ($e->{url} ? (url => $e->{url}) : ()),
                play        => 'db:track.id=' . $e->{id},
                _svc        => 'Local',
                _track      => 1,
                _trackid    => $e->{id},
                _candTitle  => $e->{title},
                _candArtist => $artist,
                ($img ? (_cover => $img) : ()),
                _fromAlbum  => $e->{album},
            };
        }
    }
    # Same fallback as localAlbums, so the linked singles come back with the
    # albums rather than leaving the page half-restored. Gated on the id owning
    # NO ALBUM, not on an empty pool: since the pool keeps only VA-comp tracks,
    # "no tracks" is the normal state of an artist owned as albums, and falling
    # back then borrowed other contributors' tracks by name (review, 0.51.10).
    if (!@out && $artistId && $opt->{fallback} && !_albumCountFor($artistId)) {
        return $class->localTracks(undef,
            ($opt->{fallback} eq 'name' ? $artist : undef),
            { mbid => $opt->{mbid}, exclude => $artistId });
    }
    _dbg("local tracks for artist_id=" . join('+', @ids) . ": " . scalar @out);
    return \@out;
}

# ---------------------------------------------------------------------------
# IDENTITY BEFORE SPELLING (0.51.3)
#
# The library contributors carrying this MusicBrainz artist tag — an EXACT
# identity match that never touches the name, so it works for a name no index
# can hold (Simon's braille/Yi/Georgian act, whose whole name normalises away)
# and for every typographic variant that has cost this plugin releases:
# "The La’s" vs "The La's", "The B‐52s" vs "The B-52s", "B52's".
#
# ALL matching contributors, not the first: a duplicate contributor is a real
# tagging artefact in Simon's library (two "The La's", one holding the albums),
# and _localArtistIds already unions them for the name path. Returning one id
# here would reintroduce the empty-artist trap that fix exists for.
#
# This is the SAME read `getArtistMbid` trusts ahead of any MB search
# (API::getArtistMbid) — one direction of it was simply never wired to the name paths.
# Untagged library / schema change -> empty list, and every caller falls
# through to the name ladder exactly as before.
sub localArtistsByMbid {
    my ($mbid) = @_;
    return [] unless defined $mbid && $mbid =~ /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
    # Case-insensitively: MB hands us lowercase, but the tag in the file is
    # whatever the tagger wrote, and the column is compared exactly.
    my %seen;
    my @try = grep { !$seen{$_}++ } ($mbid, lc $mbid, uc $mbid);
    my $rows = eval {
        require Slim::Schema;
        [ map { { artist_id => $_->id, name => $_->name } }
          Slim::Schema->rs('Contributor')->search({ musicbrainz_id => { -in => \@try } })->all ];
    };
    return ref $rows eq 'ARRAY' ? $rows : [];
}

# Ids alone — the shape the album/band lookups want.
sub localArtistIdsByMbid {
    my ($mbid) = @_;
    return map { $_->{artist_id} } @{ localArtistsByMbid($mbid) };
}

# A contributor's MusicBrainz artist tag: '' when it carries none, undef when the
# schema cannot be read (callers treat both as untagged, the name ladder's view).
sub _contributorTag {
    my ($id) = @_;
    return undef unless defined $id && $id =~ /^\d+$/;
    return eval {
        require Slim::Schema;
        my $c = Slim::Schema->find('Contributor', $id);
        $c ? ($c->musicbrainz_id // '') : undef;
    };
}

# THE ARTIST'S OWN UNTAGGED ENTRY STANDS BESIDE THE TAG (field, Simon 2026-10-07).
# LMS gives a joint credit's contributor the FIRST id of its files'
# MUSICBRAINZ_ARTISTID list, so "Suzanne Vega & Joe Jackson", off one tagged
# compilation, carries Suzanne Vega's id, while her own entry, off untagged
# rips, carries none. The identity read then answered with the duo ALONE, the
# name ladder never ran, and her own albums read Qobuz on every page reached
# without her library id: a Similar artists row (name only), a band row, an
# mbid entry. Measured live on 0.56.58: Suzanne Vega (3 owned albums), Julien
# Baker (2), The Cinematic Orchestra (4); the search's owned rows carry no tag
# for all three (`_ident_mbid` none), the by-id pages read Local. The same shape
# is the review's "tagged contributor that owns nothing" (CLAUDE.md §B).
#
# An UNTAGGED contributor of the artist's own exact name cannot contradict the
# tag, and the name ladder takes it anyway, so it counts beside the tagged ones.
# A same-name contributor tagged with ANOTHER id stays out: that is the act the
# tag rules out (0.51.3). Spelling ladder only (no term probes), as the joint
# lookup beside it.
sub _untaggedNamesakes {
    my ($name, $exclude) = @_;
    return () unless defined $name && length $name;
    my $an = _normKey($name);
    return () unless length $an;
    my %seen;
    return grep { !$seen{$_}++ && !length(_contributorTag($_) // '') }
           map  { $_->{artist_id} }
           grep { $_->{artist_id} && (!$exclude || $_->{artist_id} ne $exclude)
                  && _normKey($_->{name} // '') eq $an }
           @{ _localArtistRows($name, { no_probe => 1 }) };
}

# The library entries that ARE this MusicBrainz artist: every contributor carrying
# the tag, then the artist's own untagged exact-name entries (above). EMPTY when
# nothing carries the tag, so an untagged library takes the name ladder as before.
sub localArtistIdsByIdentity {
    my ($mbid, $name, $exclude) = @_;
    my @ids = grep { !$exclude || $_ ne $exclude } localArtistIdsByMbid($mbid);
    return () unless @ids;
    my %have = map { $_ => 1 } @ids;
    return (@ids, grep { !$have{$_}++ } _untaggedNamesakes($name, $exclude));
}

# THE LIBRARY ARTIST A NAME-ONLY PAGE MEANS (2026-10-08; Simon: "lets look to
# fix that so it works for all artists correctly"). A page opened with a name and
# nothing else - a Similar artists row - resolved that name on MusicBrainz alone,
# and for a short name MB's search ranks a famous act above every act really
# called it: "Bob" opened Bob Dylan, "Black" Black Sabbath, "Stan" Stan Getz, "The
# Bad Seeds" Nick Cave & the Bad Seeds (measured, 6 of the 94 library artists with
# a joint credit lost owned albums that way). When the library holds an artist of
# EXACTLY that name (_normKey), the page is that library artist's, as its own
# library page and the search's Top Result already open it: by its id, so its tag
# (or its own albums, C2) says which act it is. Several entries of the name: the
# one holding the most albums (the search's owner rule). None holding an album
# (a composer-only credit): undef, and the name is resolved as before.
sub libraryArtistIdByName {
    my ($name) = @_;
    return undef unless defined $name && length $name;
    my $want = _normKey($name);
    return undef unless length $want;
    # The spelling ladder without its term probes: the name is a canonical one,
    # not a user's typing (the probes' reason, _localArtistRows).
    my $rows = _localArtistRows($name, { no_probe => 1 });
    my %seen;
    my @ids = grep { !$seen{$_}++ }
              map  { $_->{artist_id} }
              grep { $_->{artist_id} && _normKey($_->{name} // '') eq $want } @{ $rows || [] };
    return undef unless @ids;
    my %n = map { ($_ => _albumCountFor($_)) } @ids;
    my ($best) = sort { $n{$b} <=> $n{$a} || $a <=> $b } @ids;
    return $n{$best} > 0 ? $best : undef;
}

# Resolve a MusicBrainz band to a library Contributor id: MB id (exact) first,
# then a normalised name match (same discipline as localAlbums' name path — a
# fuzzy `artists search:` must not adopt the wrong contributor).
sub _bandContributorId {
    my ($mbid, $name) = @_;
    if ($mbid) {
        # Every entry that is this band: the tag's, plus its own untagged one
        # (localArtistIdsByIdentity, 2026-10-07). With several, open the one
        # holding the albums, as the search's tag attach does (API): the first by
        # DB order could be a joint credit carrying the tag, or an empty duplicate.
        my @ids = localArtistIdsByIdentity($mbid, $name);
        return $ids[0] if @ids == 1;
        if (@ids) {
            my %n = map { $ids[$_] => _albumCountFor($ids[$_]) } 0 .. $#ids;
            my ($best) = map { $ids[$_] } sort { $n{ $ids[$b] } <=> $n{ $ids[$a] } || $a <=> $b } 0 .. $#ids;
            return $best;
        }
    }
    return undef unless defined $name && length $name;
    my $an  = _norm($name);
    my $enc = _cliChars($name);      # CHARACTERS - see _cliChars
    my $req = eval { Slim::Control::Request::executeRequest(undef, ['artists', 0, 20, "search:$enc"]) };
    if ($req) {
        for my $e (@{ $req->getResult('artists_loop') || [] }) {
            next unless defined $e->{artist};
            return $e->{id} if _norm($e->{artist}) eq $an;
        }
    }
    return undef;
}

# Material's "Filter album tracks" (its settings, Browse): the SERVER pref
# `noArtistFilter` of plugin.material-skin - 0 is "Only display tracks from
# current artist", 1 "Display all tracks of album" (Material's own default). Its
# client adds artist_id to the tracks request of an album opened from a library
# artist page; our page is a plugin feed, where it cannot, so we read the same
# pref and apply it ourselves (Simon, 2026-10-07). Unset - Material absent, or
# never saved - is Material's default: every track.
sub _filterAlbumTracks {
    my $v = eval { preferences('plugin.material-skin')->get('noArtistFilter') };
    return (defined $v && !$v) ? 1 : 0;
}

# The artist line under each track of an album, as Material's own album page
# draws it (browse-resp.js, "add artist to subtitle"): the track's credit is
# trackartist, else artist, else albumartist; the lines show on EVERY track or on
# none - when the tracks' credits differ from each other, or from the album's
# artist. A single-artist album stays bare, a compilation names each track's
# artist, a joint album names only what differs. Returns one entry per row,
# undef = no line.
sub _trackArtistLines {
    my ($rows) = @_;
    my $key = sub { my $s = lc($_[0] // ''); $s =~ s/\s+/ /g; $s =~ s/^ | $//g; $s };
    my @who = map {
        my ($w) = grep { defined && length } @$_{qw(trackartist artist albumartist)};
        $w;
    } @$rows;
    my ($albumArtist) = grep { defined && length } map { $_->{albumartist} } @$rows;
    my %distinct = map { $key->($_) => 1 } grep { defined } @who;
    my $show = keys %distinct > 1
            || (defined $albumArtist
                && grep { defined && $key->($_) ne $key->($albumArtist) } @who);
    return [ map { $show ? $_ : undef } @who ];
}

# The params that narrow an owned album's tracks to one artist, exactly what
# Material adds for an album opened from a library artist page when "Filter
# album tracks" is on (standarditems.js addParentParams: artist_id, and role_id
# unless the server's noRoleFilter is set). LMS's tracks query honours both with
# tags requested (measured 2026-10-07: role_id COMPOSER -> 0 tracks, the
# performance roles -> the artist's own). PERFORMANCE_ROLES because that is the
# role set localAlbums LISTED the album under. None when the setting is off, or
# no artist is known (a works page, a joint album): every track.
sub _albumNarrowing {
    my ($artistId) = @_;
    return () unless defined $artistId && $artistId =~ /^\d+$/ && _filterAlbumTracks();
    # LMS's own server pref (Slim/Menu/BrowseLibrary.pm reads it too); 0 on Simon's.
    my $noRole = eval { preferences('server')->get('noRoleFilter') };
    return (artist_id => $artistId, ($noRole ? () : (role_id => PERFORMANCE_ROLES)));
}

# The actions of an owned library album, in the shape LMS's own BrowseLibrary
# gives an album row (Slim/Menu/BrowseLibrary.pm `_albums`: items = browselibrary
# mode:tracks, play/add/insert = playlistcontrol). Used instead of a hand-built
# track list so Material draws the album page it draws for any library album
# (Simon, 2026-10-07: *"We need to copy exactly how LMS does this so its not
# different from how it normally displays this data"*):
#   - items: Material rewrites `browselibrary items mode:tracks` into its own
#     `tracks` request with the full tag set (browse-functions.js, "Convert local
#     browse commands into their non-SlimBrowse equivalents"), so the page has
#     track numbers, durations, artist lines, disc headers and the track menu.
#   - play/add/insert: playlistcontrol on the album, so "Play release starting at
#     track" (the clicked row's own play command + play_index) plays the album
#     from that track. material_skin_artist_id is what Material adds so the
#     artist's tracks are highlighted when every track is shown.
#   - info + allAvailableActionsDefined, as BrowseLibrary has them. Not cosmetic
#     (field, Simon 2026-10-07, 0.56.57: under My Apps the first tap drew an EMPTY
#     page and Back showed the tracks; console `Cannot read properties of undefined
#     (reading 'indexOf')` in browseHandleListResponse). Under Apps, Material ids a
#     row `fixId(params.item_id)` = "2", no colon; a `tracks album_id:` page then
#     runs `curitem.id.split(':')[1].indexOf(...)`, throws after drawing, and its
#     catch draws an empty page over the finished one. With every action defined,
#     XMLBrowser sends no positional `params` (its `allAvailableActionsDefined`
#     gate) and the row is id'd from its favourites URL instead ("radio:db:album.id=N",
#     playable rows always carry one); outside Apps "<parent>.<n>". Reproduced and
#     cleared in Material 6.4.12's own code (scratchpad mathar/, jsc). `info` is
#     XMLBrowser's `more`: LMS's own album context menu, as for a library album.
# $artistId: the contributor that listed the album (localAlbums' _listedUnder).
sub libraryAlbumActions {
    my ($albumId, $artistId) = @_;
    return undef unless defined $albumId && $albumId =~ /^\d+$/;
    my %p  = (album_id => $albumId, _albumNarrowing($artistId));
    my %go = (mode => 'tracks', %p,
              (defined $artistId && $artistId =~ /^\d+$/ ? (material_skin_artist_id => $artistId) : ()));
    return {
        allAvailableActionsDefined => 1,
        info  => { command => ['albuminfo', 'items'], fixedParams => { %p } },
        items => { command => ['browselibrary', 'items'], fixedParams => \%go },
        map { my $cmd = $_;
              ($cmd => { command => ['playlistcontrol'],
                         fixedParams => { cmd => ($cmd eq 'play' ? 'load' : $cmd), %p } }) }
            qw(play add insert),
    };
}

# An album holding a classical work, opened on the work's page (plan §10.5
# item 4): the libraryAlbumActions shape, with only the work's tracks.
#   - items: `browselibrary items mode:tracks album_id track_id:<list>
#     work_id:-1`. Material turns it into its own `tracks` request keeping the
#     params (browseBuildCommand); LMS's tracks query narrows by a track id
#     list (Queries.pm `tracks.id IN`; measured on the rig 2026-10-08, the 3
#     tracks asked of the 21 on the album) and work_id:-1 is "any work", the
#     same tracks. The work_id param is what makes Material draw it as LMS's
#     own Works view draws a work's album (browse-resp.js `isWork`: no track
#     numbers).
#   - play/add/insert: playlistcontrol on the same ids, in the album's order
#     (Classical::albumsFor sorts them by disc and track number, as the page's
#     sort:tracknum does), so "Play release starting at track" (the row's play
#     + play_index) starts on the track tapped. work_id:-1 as Material sends
#     for a work's tracks: LMS marks them added from a work, and the track id
#     list is what it plays (Commands.pm playlistcontrol: work_id -1 falls to
#     the track_id branch).
#   - no artist narrowing: a work's album shows the work, whoever plays it.
# Undef without an album id or tracks (the caller keeps its own actions).
sub libraryWorkActions {
    my ($albumId, $trackIds) = @_;
    return undef unless defined $albumId && $albumId =~ /^\d+$/;
    my @t = grep { defined && /^\d+$/ } @{ $trackIds || [] };
    return undef unless @t;
    my %p = (track_id => join(',', @t), work_id => -1);
    return {
        allAvailableActionsDefined => 1,
        info  => { command => ['albuminfo', 'items'], fixedParams => { album_id => $albumId } },
        items => { command => ['browselibrary', 'items'],
                   fixedParams => { mode => 'tracks', album_id => $albumId, %p } },
        map { my $cmd = $_;
              ($cmd => { command => ['playlistcontrol'],
                         fixedParams => { cmd => ($cmd eq 'play' ? 'load' : $cmd), %p } }) }
            qw(play add insert),
    };
}

# An owned album's playable tracks, narrowed by LMS when asked (see
# _albumNarrowing), or to a work's tracks ($trackIds), with the artist,
# credits and url.
sub _albumTrackRows {
    my ($albumId, $artistId, $narrow, $trackIds) = @_;
    my @t = grep { defined && /^\d+$/ } @{ $trackIds || [] };
    my $req = eval {
        Slim::Control::Request::executeRequest(undef,
            ['titles', 0, 999, 'album_id:' . $albumId,
             (@t ? ('track_id:' . join(',', @t)) : ()),
             ($narrow ? _albumNarrowingParams($artistId) : ()),
             'sort:tracknum', 'tags:uaA']);
    };
    return [ grep { $_->{url} } @{ ($req && $req->getResult('titles_loop')) || [] } ];
}
sub _albumNarrowingParams {
    my %n = _albumNarrowing($_[0]);
    return map { "$_:$n{$_}" } sort keys %n;
}

# A library album's tracks as a plain feed: the drill-in for a client that is not
# Material (no native album page), for a legacy positional walk, and for the
# works page's `wka:` rows. $pass: album_id, and artist_id (the contributor that
# listed it, stamped by localAlbums). Under "Filter album tracks" LMS narrows to
# that artist, as Material does; an empty narrowing shows the whole album rather
# than nothing. Each track names its artist where the credits differ, as Material
# draws them.
sub _localAlbumTracks {
    my ($client, $cb, $args, $pass) = @_;
    # A work's tracks on the album (the works page, `track_ids`): those alone,
    # never the artist narrowing; none left (a rescan renumbered them) shows
    # the whole album, as an empty narrowing does.
    if (ref $pass->{track_ids} eq 'ARRAY' && @{ $pass->{track_ids} }) {
        my $rows = _albumTrackRows($pass->{album_id}, undef, 0, $pass->{track_ids});
        $rows = _albumTrackRows($pass->{album_id}) unless @$rows;
        return _trackFeed($cb, $rows);
    }
    my $artistId = $pass->{artist_id};
    my $narrow   = scalar(my @n = _albumNarrowing($artistId));
    my $rows     = _albumTrackRows($pass->{album_id}, $artistId, $narrow);
    $rows = _albumTrackRows($pass->{album_id}) if $narrow && !@$rows;
    _trackFeed($cb, $rows);
}

# The rows of _localAlbumTracks as a feed: each track playable, with its
# artist where the credits differ (Material's rule, _trackArtistLines).
sub _trackFeed {
    my ($cb, $rows) = @_;
    my @rows = @$rows;

    my $lines = _trackArtistLines(\@rows);
    my @items;
    for my $i (0 .. $#rows) {
        my $e = $rows[$i];
        push @items, { name => $e->{title} // '', type => 'audio', url => $e->{url}, play => $e->{url},
                       (defined $lines->[$i] ? (line2 => $lines->[$i]) : ()) };
    }
    $cb->({ items => \@items });
}

# Detection + priority for every known service — for the settings page (step 5)
# and the app-root "Works best with" list. $adapters is an OPTIONAL pre-built
# adapters() list: a caller that already needs the adapters (the root view
# reads their icons) passes its own copy so the capability probe runs once per
# render instead of once per consumer. Omitted = probe here, as before.
sub serviceStatus {
    my ($adapters) = @_;
    my @known = ( [ 'qobuz', 'Qobuz' ], [ 'tidal', 'Tidal' ], [ 'deezer', 'Deezer' ],
                  [ 'spotify', 'Spotify' ] );
    my %installed = map { lc($_->{name}) => 1 }
        (ref $adapters eq 'ARRAY' ? @$adapters : adapters());
    return [ map {
        {   key       => $_->[0],
            name      => $_->[1],
            installed => $installed{ $_->[0] } ? 1 : 0,
            priority  => $prefs->get('svc_priority_' . $_->[0]) // 0,
        }
    } @known ];
}

# ---------------------------------------------------------------------------
# Candidate fetch + cache
# ---------------------------------------------------------------------------

# $mbid scopes the key to ONE MusicBrainz artist. Only same-name-ambiguous
# lookups pass it, so every ordinary artist keeps its existing name-keyed entry
# (no mass cache invalidation) while two acts called Madness get their own.
# The candidate pool is the ONE cache whose contents depend on resolver LOGIC
# rather than on remote data: which service artist we picked, what the foreign-
# artist filter dropped, whether the alias retry ran. So every change to that
# logic can leave a pool that is stale in a way no TTL describes — and it
# persists for CAND_FOUND_TTL (3 days), which during development repeatedly made
# a WORKING fix look broken (Sonic Boom, 2026-07-19: the page only came right
# after a manual clearcache).
#
# Including the plugin VERSION in the key makes every install self-invalidating:
# a new build simply cannot read an old build's pools. Costs one refetch per
# artist actually visited after an update, on demand — not a mass rebuild — and
# removes a whole class of "is this the fix or the cache?" diagnosis. Old keys
# are never read again and expire on their own.
my $_pluginVer;
sub _pluginVersion {
    return $_pluginVer if defined $_pluginVer;
    $_pluginVer = eval {
        Slim::Utils::PluginManager->dataForPlugin('Plugins::Discography::Plugin')->{version};
    };
    $_pluginVer = 'dev' unless defined $_pluginVer && length $_pluginVer;
    return $_pluginVer;
}

sub _candKey {
    my ($svc, $artist, $mbid) = @_;
    my $key = 'dsc:cand:' . CAND_CACHE_V . ':' . _pluginVersion() . ':' . lc($svc) . ':'
            . ($mbid ? "mb:$mbid" : _norm($artist));
    utf8::encode($key) if utf8::is_utf8($key);   # octet key — non-Latin can't crash md5
    return $key;
}

# Native play/browse coderefs can't live in the cache — stripped on write,
# reattached on read from the adapter entry's own `rebuild` sub (PFR's shape;
# it replaced a %REATTACH map keyed by service name, D1 in
# docs/spotify-adapter-plan.md). $adapter is an adapters()/orderedAdapters()
# entry. Every rebuild sub is one adapters() already probed with ->can, and
# both callers rebuild that list per call, so a service that's since been
# disabled or uninstalled is simply not there; an entry without a rebuild sub
# yields nothing, and its items are dropped rather than left without a url.
sub _reattach {
    my ($adapter, $cached) = @_;
    my $code = ref $adapter eq 'HASH' ? $adapter->{rebuild} : undef;
    return [] unless ref $code eq 'CODE';
    return [ map { my %x = %$_; $x{url} = $code; \%x } @{ $cached || [] } ];
}

sub _cacheCands {
    my ($key, $items, $ttl, $unresolved, $meta) = @_;
    my @store = map { my %x = %$_; delete $x{url}; \%x } @{ $items || [] };
    eval { $cache->set($key, { items => \@store,
                               ($unresolved ? (unresolved => 1) : ()),
                               (ref $meta eq 'HASH' ? (meta => $meta) : ()) }, $ttl); 1 }
        or $log->warn("candidate cache set failed: $@");
}

# ONE FETCH PER POOL AT A TIME (0.56.15). Field, 2026-10-01: TIDAL newly on,
# two opens of the same page 0.7 s apart each found no pool and each fetched
# TIDAL (`candidates Tidal/'Madness': 76` logged twice, 13 ms apart). A second
# caller for a pool already being fetched now waits for that fetch's answer.
# The fleet's shared registry (SingleFlight.pm, a byte-identical copy of LBF's,
# kept so by tools/singleflight_sync_check.py there): released on every exit,
# its own watchdog, each waiter answered separately.
#
# Loaded at FIRST USE, not with `use`: a checkout has no Plugins/ parent, so a
# top-level `use` of a sibling dies at BEGIN in every suite. Not loadable means
# no coalescing - each caller fetches for itself, exactly as before 0.56.15 -
# and says so once.
my $candFlight;
sub _candFlight {
    return $candFlight if defined $candFlight;
    $candFlight = eval {
        require Plugins::Discography::SingleFlight;
        Plugins::Discography::SingleFlight->new(
            name => 'candidates', max => SVC_TIMEOUT * 3, log => $log);
    } || do {
        $log->warn("candidate fetches not coalesced (SingleFlight unavailable): $@");
        0;
    };
    return $candFlight;
}

# getCandidates($client, $artist, $force, $cb) -> $cb->({ <svc> => [items] })
# One artist-level search per enabled service, in parallel, each behind its own
# watchdog. Cache hits skip the search entirely. $cb fires exactly once, after
# every service settles (a hung one settles as an error at SVC_TIMEOUT).
sub getCandidates {
    my ($class, $client, $artist, $force, $cb, $opt) = @_;
    $opt ||= {};

    # %opt (all optional): spine => { normalised MB title => 1 }, mbid => '...'
    # The spine is what an ambiguous name's candidates are scored against (see
    # _resolveArtist) and may legitimately be EMPTY. The mbid scopes the cache
    # so two acts sharing a name cannot share a pool, and is independent of the
    # spine — see the write-key note below.
    #
    # query => the name to SEARCH the services under, when it is not $artist
    # (0.56.13). The pool is keyed by the MusicBrainz artist, so it must be
    # built from that artist's name, never from whatever name the page was
    # opened under: field (Simon, 2026-10-01), "James Yorkston & The Big Eyes
    # Family Players" resolved to James Yorkston, found Qobuz's joint artist of
    # that name (2 albums) and stored it as James Yorkston's pool for 3 days, so
    # every James Yorkston page matched nothing but the user's own 3 albums. The
    # caller passes MusicBrainz's name here and $artist among the aliases.
    my $spine   = $opt->{spine};
    my $aliases = $opt->{aliases};
    # The NAME is shared by several MB artists: a lone same-name hit on a
    # service proves nothing and must be checked against the spine too.
    my $strict  = $opt->{ambiguous} ? 1 : 0;
    # compare => 1: the query is MusicBrainz's English name standing in for a
    # name with no Latin letter, and the first alias is that name. Both are
    # asked even when the English one corroborates (_resolveArtist says why).
    my $compare = $opt->{compare} ? 1 : 0;
    # THE WRITE KEY, and it must be derived exactly as the READ keys are.
    #
    # This used to be `($spine && %$spine) ? $opt->{mbid} : undef` — vestigial
    # from 0.43.1, when only ambiguous lookups were mbid-scoped. Both readers
    # (peekPool via _buildList and the cold check) pass the mbid
    # UNCONDITIONALLY, so an EMPTY spine wrote a name-keyed pool that nothing
    # ever read back. Two ways that bit:
    #   - an artist with no MB release groups: _spineTitles is {}, so the pool
    #     was written name-keyed and read mb-keyed — a permanent miss, and with
    #     hide_unmatched on the cold-pool await re-resolved every service on
    #     EVERY visit, never warming.
    #   - _releaseDetail builds its spine from peekReleaseGroups, a cache-ONLY
    #     peek; on a miss the spine is empty, so the detail page resolved
    #     against the name-keyed pool — the prominent same-name act's catalogue
    #     — and disagreed with the tile that opened it.
    # Same class as the 0.43.1/0.43.2 split key: a scope on a cache key must be
    # derived the same way on both sides, or it fails silently.
    my $mbid    = $opt->{mbid};

    my @adapters = orderedAdapters();
    unless (@adapters && defined $artist && length $artist) { $cb->({}); return }

    # Raw artist to the service search (normalisation mangles stylised names —
    # "P!nk" -> "p nk"), in BOTH spellings: character string for adapters whose
    # URL layer escapes/transliterates itself (Qobuz, Tidal), octets for
    # byte-level escapers (Deezer). See the query_enc notes in adapters().
    my $svcName = (defined $opt->{query} && length $opt->{query}) ? $opt->{query} : $artist;
    my $qChars = $svcName;
    utf8::decode($qChars) unless utf8::is_utf8($qChars);   # no-op if not valid UTF-8
    my $qBytes = $svcName;
    utf8::encode($qBytes) if utf8::is_utf8($qBytes);
    # The names tried after it (aliases, the browsed name) in the same two
    # spellings (C5, 2026-10-01): they were handed over raw, so a non-ASCII one
    # reached Deezer, which takes bytes, as characters.
    my @aChars = map { my $c = $_; utf8::decode($c) unless utf8::is_utf8($c); $c } @{ $aliases || [] };
    my @aBytes = map { my $b = $_; utf8::encode($b) if utf8::is_utf8($b); $b } @{ $aliases || [] };
    # leaders => the members a band is named after (Browse::_poolLeaders): their
    # albums are fetched beside the band's, to match its own releases
    # (_resolveWithJoints). Both spellings, as the aliases.
    my $leaders = ref $opt->{leaders} eq 'ARRAY' ? $opt->{leaders} : [];
    my @lChars = map { my $c = $_; utf8::decode($c) unless utf8::is_utf8($c); $c } @$leaders;
    my @lBytes = map { my $b = $_; utf8::encode($b) if utf8::is_utf8($b); $b } @$leaders;

    my %out;
    my $pending = scalar @adapters;

    for my $a (@adapters) {
        my $svc = $a->{name};
        my $key = _candKey($svc, $artist, $mbid);

        if (!$force && (my $c = $cache->get($key))) {
            $out{$svc} = _reattach($a, $c->{items});
            $cb->(\%out) unless --$pending;
            next;
        }

        # This caller's answer for $svc: its own copy of each item, so two pages
        # answered from one fetch never share (and never mutate) one hash.
        my $land = sub {
            $out{$svc} = [ map { ref $_ eq 'HASH' ? { %$_ } : $_ } @{ $_[0] || [] } ];
            $cb->(\%out) unless --$pending;
        };
        # Coalesced on the pool key PLUS everything that shapes the fetch (the
        # name searched, shared-name strictness, the spine's size, the aliases),
        # so two callers share a fetch only when each would have made the same
        # one. A forced fetch (Refresh) neither waits on nor holds a flight.
        # No background flag to carry: a service's answer arrives from the event
        # loop, where it is always off, so a waiter continues exactly as it
        # would have from a fetch of its own.
        my $flight = $force ? 0 : _candFlight();
        my $fkey = join("\x1f", $key, $svcName, $strict,
                        (ref $spine eq 'HASH' ? scalar(keys %$spine) : 0), @{ $aliases || [] },
                        "\x1e", @$leaders);
        if ($flight) {
            next unless $flight->join($fkey, onDone => $land, onError => sub { $land->([]) });
        }

        my $settled = 0;
        my $timer;
        # $meta (Qobuz only): the artist the lookup settled on, kept with the
        # pool for the biography ladder (_searchQobuz, peekPoolMeta).
        my $settle = sub {
            my ($items, $meta) = @_;
            if ($settled) {
                # The watchdog already gave up on this service, but the fetch
                # landed anyway. Keep the result: pinning the error TTL over a
                # pool we actually hold would repeat the same slow fetch on
                # every open. Only the $cb is spoken for — it already fired.
                _cacheCands($key, $items, CAND_FOUND_TTL, 0, $meta)
                    if defined $items && @$items;
                return;
            }
            $settled = 1;
            Slim::Utils::Timers::killSpecific($timer) if $timer;
            my $answer;
            if (!defined $items) {
                # Couldn't query (no handler / timeout / renderer died): cache
                # empty briefly so the next open retries soon, not in 3 days.
                # UNRESOLVED, not "this service has nothing". An empty pool
                # that peekPool counts as `resolved` lets hide_unmatched hide
                # the release — which is precisely what 0.43.1 set out to
                # prevent and did not, because the marker was never stored
                # (field, 2026-07-19: an unresolvable artist's page still read
                # "No releases found").
                _cacheCands($key, [], CAND_ERR_TTL, 1);
                $answer = [];
            }
            else {
                _cacheCands($key, $items, @$items ? CAND_FOUND_TTL : CAND_EMPTY_TTL, 0, $meta);
                $answer = $items;
            }
            # Sample the pool head in the log: a healthy count full of the
            # WRONG artist (mangled query, wrong-artist adoption) is otherwise
            # indistinguishable from a good pool the matcher rejected.
            #
            # A SMALL pool is listed IN FULL (POOL_LOG_MAX), because for a
            # missing release the whole question is "is it in the pool and
            # failing the title match, or was it never fetched?" — and three
            # examples can never answer that. Big pools stay sampled: a single
            # render already writes ~100 match lines and log.txt tails.
            my $n = defined $items ? scalar(@$items) : undef;
            my $show = ($n && $n <= POOL_LOG_MAX) ? $n : 3;
            my $sample = ($n && $n > 0)
                ? (($n <= POOL_LOG_MAX ? ' ALL: ' : ' e.g. ')
                   . join('; ', map { ($_->{_candArtist} // '?') . ' - ' . ($_->{_candTitle} // '?') }
                     @{$items}[0 .. ($n > $show ? $show - 1 : $n - 1)]))
                : '';
            # An UNRESOLVED artist settles undef exactly like a handler error or
            # a timeout does (see the spine branch in _searchQobuz/_searchTidal/
            # _searchDeezer/_searchSpotify), so
            # this line must not claim a cause it cannot know. It read
            # "error (handler/timeout/renderer)" and sent a field diagnosis
            # after a Qobuz timeout that was really "this artist could not be
            # identified under that name".
            _dbg("candidates $svc/'$artist'"
                . ($svcName ne $artist ? " (searched as '$svcName')" : '') . ': '
                . (defined $n ? $n . $sample
                              : 'no pool (artist unresolved, or handler/timeout/renderer error)'));
            # Everyone waiting on this pool, this caller included, answered once.
            if ($flight) { $flight->resolve($fkey, $answer) }
            else         { $land->($answer) }
        };

        $timer = Slim::Utils::Timers::setTimer(undef, time() + SVC_TIMEOUT, sub {
            return if $settled;
            $log->warn("candidates $svc timed out");
            $settle->(undef);
        });

        my $chars = ($a->{query_enc} || 'bytes') eq 'chars';
        my $query = $chars ? $qChars : $qBytes;
        my $names = $aliases ? ($chars ? \@aChars : \@aBytes) : undef;
        my $lead  = @$leaders ? ($chars ? \@lChars : \@lBytes) : undef;
        eval { $a->{run}->($client, $query, $svc, $settle, $spine, $names, $strict, $compare, $lead); 1 } or do {
            $log->warn("candidates $svc failed: $@");
            $settle->(undef);
        };
    }
}

# Drop an artist's candidate caches (the detail page's "Refresh matches" row).
# Clears BOTH scopes: the mbid-keyed pool (what an identified artist actually
# uses) and the legacy/name-keyed one. Refresh must not leave a stale pool
# behind just because the caller didn't know the mbid.
sub clearCandidates {
    my ($class, $artist, $mbid) = @_;
    return unless defined $artist && length $artist;

    # LOGS THE KEYS, and whether each actually held anything. clearcache
    # reported success for a long time while the pool survived (2026-07-19),
    # which silently invalidated every "cold cache" test run against this
    # plugin — including ones that concluded a real bug was unreproducible.
    # A clear that cannot be observed is a clear that cannot be trusted.
    my @report;
    for my $a (adapters()) {
        for my $key (_candKey($a->{name}, $artist),
                     ($mbid ? _candKey($a->{name}, $artist, $mbid) : ())) {
            my $had = defined $cache->get($key) ? 'HIT' : 'miss';
            $cache->remove($key);
            my $now = defined $cache->get($key) ? 'STILL-PRESENT' : 'gone';
            push @report, "$key [$had->$now]";
        }
    }
    _dbg('clearCandidates: ' . (@report ? join(' | ', @report)
                                        : 'NO ADAPTERS - nothing cleared'));
    return \@report;
}

# ---------------------------------------------------------------------------
# Global artist search (the plugin-view "Search for an artist" feature) —
# one artist-TYPE search per enabled service plus the library, results merged
# and deduped by mergeArtistHits. Deliberately NOT cached here (user-initiated,
# one request per service); Browse caches the MERGED list briefly for item_id
# walk determinism.
# ---------------------------------------------------------------------------

# searchArtists($client, $query, $cb) -> cb(\%bySvc, \%failed) where %bySvc is
#   { Local => [{name, artist_id}], Qobuz => [{name}], ... } — every source key
# present once settled — and %failed is { <svc> => 1 } for each service that
# ERRORED or TIMED OUT.
#
# The second arg matters (0.42.2): a failed service settles as an EMPTY list,
# which is indistinguishable from "this service genuinely has no such artist"
# unless the failure is reported separately. Browse caches the merged list for
# SEARCH_TTL, so without this signal one slow/erroring service pinned a
# silently-degraded result set for the full TTL — every retry inside the window
# served the same short list from cache instead of re-searching. Callers must
# treat a non-empty %failed as "these results are incomplete, do not persist".
#
# Same parallel settle-once/watchdog pattern as getCandidates, sized for the
# single request each artist search costs.
sub searchArtists {
    my ($class, $client, $query, $cb) = @_;

    my (%out, %failed);
    return $cb->(\%out, \%failed) unless defined $query && length $query;

    # Local leg — sync CLI query (LMS DB access is synchronous, the fleet's
    # accepted pattern), the same `artists search:` call localAlbums' name
    # fallback uses. Hits keep their contributor id so a drill-in resolves
    # via the reliable library-tag path.
    #
    # role_id MUST match what localAlbums asks for (PERFORMANCE_ROLES). Left
    # unfiltered, `artists` falls back to activeContributorRoles /
    # defaultContributorRoles (verified in LMS 9.0 Queries.pm:1047-1063), which
    # include COMPOSER — so a writer-only contributor was returned here as a
    # Local row while the page it opened filtered them out and showed nothing.
    if (($prefs->get('svc_priority_local') // 1) > 0) {
        # SHARED with localAlbums' name fallback -- one ladder, so the &/and
        # retry, the ASCII fold and the term probes can never again exist on
        # one entry path and not the other (Simon, 2026-07-22).
        my $how = '';
        my @hits = @{ _localArtistRows($query, { how => \$how }) };

        # Recovery steps widen the net, so anything they returned is
        # norm-verified against what the user typed before it is offered as a
        # Local row. An exact-spelling match needs no gate: LMS's own search of
        # what was typed is the fuzzy search the user asked for, and every hit
        # faces mergeArtistHits' relevance gate like any service's. 0.46.0
        # narrowed THOSE hits too, so an exact name pushed out every other
        # library artist containing it (Simon, 2026-10-01: "Elvis Costello" lost
        # the owned "Elvis Costello & The Attractions", which the typo
        # "Elvis Costelllo" found, having no exact hit to narrow to).
        if (@hits && $how ne 'typed') {
            my $qn = _normKey($query);
            my @exact = grep { _normKey($_->{name}) eq $qn } @hits;
            @hits = @exact if @exact;
        }

        $out{Local} = \@hits;
    }

    my @adapters = orderedAdapters();
    return $cb->(\%out, \%failed) unless @adapters;

    # Both query spellings, per the query_enc discipline (see adapters()).
    my $qChars = $query;
    utf8::decode($qChars) unless utf8::is_utf8($qChars);
    my $qBytes = $query;
    utf8::encode($qBytes) if utf8::is_utf8($qBytes);

    my $pending = scalar @adapters;
    for my $a (@adapters) {
        my $svc = $a->{name};
        my $settled = 0;
        my $timer;
        my $settle = sub {
            my ($hits) = @_;
            return if $settled;
            $settled = 1;
            Slim::Utils::Timers::killSpecific($timer) if $timer;
            my $ok = ref $hits eq 'ARRAY';
            $out{$svc}    = $ok ? $hits : [];
            $failed{$svc} = 1 unless $ok;
            # NAMES, not just a count. A count cannot answer "was this artist
            # ever returned?" - and that is the only question that matters when
            # a row the user expected is missing (field: "The Iron Maidens"
            # absent from an Iron Maiden search, present in Tidal's own
            # results). It distinguishes a service/limit gap from the merge
            # relevance gate dropping it downstream.
            _dbg("artist-search $svc/'$query': " . scalar(@{ $out{$svc} })
                . ($ok ? '' : ' (error/timeout)')
                . (@{ $out{$svc} } ? ' | ' . join('; ',
                    map { $_->{name} // '?' } @{ $out{$svc} }) : ''));
            $cb->(\%out, \%failed) unless --$pending;
        };
        $timer = Slim::Utils::Timers::setTimer(undef, time() + SEARCH_TIMEOUT, sub {
            return if $settled;
            $log->warn("artist-search $svc timed out");
            $settle->(undef);
        });
        my $q = ($a->{query_enc} || 'bytes') eq 'chars' ? $qChars : $qBytes;
        eval { $a->{artists}->($client, $q, $svc, $settle); 1 } or do {
            $log->warn("artist-search $svc failed: $@");
            $settle->(undef);
        };
    }
}

# N random library album-cover URLs for the app-root banner — one `albums`
# CLI query using the server's own sort:random (verified live 2026-07-17;
# fresh order every call, no Perl-side shuffling needed). Only albums that
# actually HAVE artwork are kept (tags:j artwork_track_id), so the banner can
# never show a blank tile; the pool is 3x the ask to survive artless albums.
# Empty library / failed query -> [] (the caller skips the banner).
sub randomAlbumCovers {
    my ($class, $n) = @_;
    $n ||= 4;
    my $req = eval { Slim::Control::Request::executeRequest(undef,
        ['albums', 0, $n * 3, 'sort:random', 'tags:j']) };
    return [] unless $req;
    my @ids = grep { defined $_ && length $_ }
        map { $_->{artwork_track_id} } @{ $req->getResult('albums_loop') || [] };
    splice @ids, $n if @ids > $n;
    return [ map { "/music/$_/cover_300x300_f.jpg" } @ids ];
}

# Normalise a service's artist list to [{name, img}], capped. All three
# services carry the display name in {name} (the same field _pickArtist reads);
# `img` is the service's OWN artist photo, kept since 0.51.0 (it arrives in the
# same response, so it costs nothing, and it is what fills the artwork gaps the
# name-keyed MAI route leaves behind — see artistImage).
sub _artistHits {
    my ($list, $svc) = @_;
    return undef unless ref $list eq 'ARRAY';
    my @out;
    for my $a (@$list) {
        next unless ref $a eq 'HASH'
            && defined $a->{name} && !ref $a->{name} && length $a->{name};
        my $img = _svcArtistImage($svc, $a);
        push @out, { name => $a->{name}, ($img ? (img => $img) : ()) };
        last if @out >= SEARCH_MAX;
    }
    return \@out;
}

# The artist-search leg of each adapter, standalone — the same call the
# artist-first candidate fetch opens with (signatures verified against the
# plugin sources, see the Service Plugin APIs table in CLAUDE.md).
sub _artistsQobuz {
    my ($client, $query, $svc, $collect) = @_;
    my $api = Plugins::Qobuz::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }
    $api->search(sub {
        my $res = shift;
        $collect->(_artistHits(
            ref $res eq 'HASH' && ref $res->{artists} eq 'HASH'
                ? $res->{artists}{items} : undef, $svc));
    }, lc($query), 'artists');
}

sub _artistsTidal {
    my ($client, $query, $svc, $collect) = @_;
    my $api = Plugins::TIDAL::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }
    $api->search(sub {
        $collect->(_artistHits(shift, $svc));
    }, { type => 'artists', search => $query, limit => SEARCH_MAX });
}

sub _artistsDeezer {
    my ($client, $query, $svc, $collect) = @_;
    my $api = Plugins::Deezer::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }
    $api->search(sub {
        $collect->(_artistHits(shift, $svc));
    }, { search => $query, type => 'artist', strict => 'off', limit => SEARCH_MAX });
}

# ---------------------------------------------------------------------------
# ARTIST ARTWORK FROM THE SERVICES (0.51.0)
#
# The name-keyed MAI route (imageproxy/mai/artist/<name>) is one hop over
# api.lms-community.org's `/artist/<name>/picture`, which answers with a Deezer
# CDN URL out of a PERIODIC SNAPSHOT. When Deezer's own picture hash has moved
# on, that URL is dead and the row shows a silhouette — measured live
# 2026-07-29, all three still reproducing:
#
#   The Mothers of Invention  snapshot e9cce9d1... -> 302 -> live 32cfa446... OK
#   Pink Floyd                snapshot 6d6d4e14... -> 302 -> live d62a818a... OK
#   B52's                     snapshot 8101b740... -> 302 -> live 35dceb20... OK
#
# 0.46.5 traced this to source and (correctly, then) called it upstream data.
# What is new is that the failure is DETECTABLE without downloading anything:
# a picture-less Deezer entity 302s to the md5 of the EMPTY STRING, and the
# services we already query hold a live photo for the same act. So the gap can
# be filled instead of merely explained — Browse::_resolveArtistImage runs the
# tiers, this end supplies the service one.
# ---------------------------------------------------------------------------

# Deezer's "no picture" sentinel: md5(''). It shows up BOTH as the target of a
# 302 from a stale hash and, sometimes, directly in a live `picture_*` field.
# Its twin is an EMPTY hash segment, `/images/artist//…`, which Deezer's own
# search returns for a picture-less entity and the CDN answers with the same
# placeholder image (live 2026-09-19, "Teddybears feat. CeeLo & B52's").
use constant DEEZER_NO_PIC => 'd41d8cd98f00b204e9800998ecf8427e';

use constant ARTIMG_FOUND_TTL => 30 * 86400;
use constant ARTIMG_EMPTY_TTL =>  1 * 86400;
use constant ARTIMG_TIMEOUT   => 15;    # per-service watchdog for the lookup

# Is this URL a service placeholder rather than a photograph?
sub isPlaceholderImage {
    my ($url) = @_;
    return 0 unless defined $url && !ref $url && length $url;
    return 1 if index($url, DEEZER_NO_PIC) >= 0;
    return $url =~ m{/images/[a-z]+//}i ? 1 : 0;
}

# The artist photo carried by a service's own search hit, via THAT plugin's URL
# builder (never a hand-rolled CDN path — those drift silently):
#   Qobuz   {picture} or the {image} size hash  (API::Common->getImageFromImagesHash)
#   TIDAL   {picture} uuid                      (API->getImageUrl, 'artist' -> 750x750)
#   Deezer  {picture_*}                         (API->getImageUrl, returns the URL as-is)
# The hash is COPIED before it is handed over: both getImageUrl implementations
# write a {cover} key back into it, and these hits go on to be cached.
sub _svcArtistImage {
    my ($svc, $a) = @_;
    return undef unless ref $a eq 'HASH' && defined $svc;
    my $u;
    if ($svc eq 'Qobuz') {
        $u = $a->{picture} if defined $a->{picture} && !ref $a->{picture};
        $u ||= eval {
            Plugins::Qobuz::API::Common->can('getImageFromImagesHash')
                ? Plugins::Qobuz::API::Common->getImageFromImagesHash($a->{image})
                : undef;
        };
    }
    elsif ($svc eq 'Tidal') {
        $u = eval {
            Plugins::TIDAL::API->can('getImageUrl')
                ? Plugins::TIDAL::API->getImageUrl({ %$a }, undef, 'artist') : undef;
        };
    }
    elsif ($svc eq 'Deezer') {
        $u = eval {
            Plugins::Deezer::API->can('getImageUrl')
                ? Plugins::Deezer::API->getImageUrl({ %$a }, undef, 'artist') : undef;
        };
    }
    return undef unless defined $u && !ref $u && $u =~ m{^https?://}i;
    return undef if isPlaceholderImage($u);
    return $u;
}

sub _artImgKey {
    my ($name) = @_;
    my $key = 'dsc:svcartimg:v1:' . _norm($name // '');
    utf8::encode($key) if utf8::is_utf8($key);   # octet key (see _candKey)
    return $key;
}

# A live artist photo from the user's own services, in svc_priority order.
# $cb->($url | undef). Services are asked ONE AT A TIME and the first EXACT
# photo ends the walk: this runs behind a thumbnail the browser has already
# asked for, so the cheapest answer that fills the row is the right one — a
# fan-out would triple the traffic to improve nothing the user can see.
#
# The name gate is the matcher's own: an exact `_norm` match, else
# `_artistMatch` (token subset, so "Mothers of Invention" accepts "The Mothers
# of Invention"). A service's relevance tail is full of neighbours — an
# ungated first hit would confidently show the wrong band's face.
#
# EXACT BEATS LOOSE ACROSS THE WHOLE WALK, not per service. A token-subset
# photo is only REMEMBERED (first in priority order) and served when no
# service knows the exact name at all: a loose "Genesis P-Orridge" on Qobuz
# must not pre-empt the exact "Genesis" on Deezer. And an exact entity with no
# photo anywhere VETOES every loose one — the artist exists, has no picture,
# and a neighbour's face cached for 30 days is worse than the icon. The cost
# is confined to names no service answers exactly, which walk every service.
sub artistImage {
    my ($class, $client, $name, $cb) = @_;
    $cb ||= sub {};
    # $cb->($url, $conclusive). $conclusive is false ONLY when the walk ended
    # without a single service replying, so a caller that caches can tell a
    # real "no photo" from "we never found out" (see $done). These three exits
    # are all real answers: no name to search, a cached verdict, no services.
    return $cb->(undef, 1) unless defined $name && length $name;

    my $key = _artImgKey($name);
    if (defined(my $c = $cache->get($key))) { return $cb->($c || undef, 1) }

    # Only services that can supply a photo (artist_image => 0 opts one out;
    # absent means yes). Filtered BEFORE the walk, so an opted-out service can
    # neither answer nor veto.
    my @adapters = grep { !defined $_->{artist_image} || $_->{artist_image} } orderedAdapters();
    return $cb->(undef, 1) unless @adapters;

    my $want  = _norm($name);
    my $qChars = $name; utf8::decode($qChars) unless utf8::is_utf8($qChars);
    my $qBytes = $name; utf8::encode($qBytes) if     utf8::is_utf8($qBytes);

    # $answered: did ANY service actually reply? The adapters already carry
    # the fleet's inconclusive/miss distinction — `_artistHits` returns undef
    # for a response it could not read, an arrayref otherwise, and the
    # watchdog and the `eval` failure both settle with undef. Without this,
    # "every service timed out" was stored as "nobody has a photo" for a day
    # (ARTIMG_EMPTY_TTL), so one flaky minute pinned the person icon on an
    # artist until the next day. `_vetCollabs` applies the same rule to $ok:
    # a blip caches nothing and is retried on the next visit.
    my $answered = 0;
    my $done = sub {
        my ($url) = @_;
        eval { $cache->set($key, $url // '',
            $url ? ARTIMG_FOUND_TTL : ARTIMG_EMPTY_TTL); 1 }
            if $url || $answered;
        $cb->($url, ($url || $answered) ? 1 : 0);
    };

    my ($loose, $sawExact);
    # Self-passing closure, not a captured lexical — avoids the reference cycle
    # Perl never reclaims (the 0.30.1 leak fix). This one walks the adapters on
    # every COLD artist thumbnail, so the captured form leaked per artist.
    my $next = sub {
        my ($self) = @_;
        my $a = shift @adapters;
        unless ($a) {
            _dbg("artist image '$name': loose fallback $loose")
                if $loose && !$sawExact;
            return $done->($sawExact ? undef : $loose);
        }

        my $svc     = $a->{name};
        my $settled = 0;
        my $timer;
        my $settle = sub {
            my ($hits) = @_;
            return if $settled++;
            Slim::Utils::Timers::killSpecific($timer) if $timer;
            # EXACT spelling first, across the whole result list, before any
            # token-subset hit is considered: the services rank by relevance,
            # not by identity, so "The Mothers" can outrank "The Mothers of
            # Invention" for a query the second one answers exactly.
            #
            # The exact test sees EVERY hit, photo or not. An exact entity with
            # no picture (or a placeholder, dropped by _svcArtistImage) is the
            # artist this tier exists for: it vetoes every token-subset
            # NEIGHBOUR's face ("Genesis P-Orridge" for Genesis), from this
            # service and every other.
            $answered = 1 if ref $hits eq 'ARRAY';   # this service really replied
            my @cands = grep { ref $_ eq 'HASH' && _norm($_->{name} // '') ne '' }
                        @{ ref $hits eq 'ARRAY' ? $hits : [] };
            my @exact = grep { _norm($_->{name}) eq $want } @cands;
            if (my ($h) = grep { $_->{img} } @exact) {
                _dbg("artist image '$name': $svc -> $h->{img}");
                return $done->($h->{img});
            }
            if (@exact) {
                $sawExact = 1;
                _dbg("artist image '$name': $svc has the exact entity but no photo");
            }
            elsif (!$loose) {
                my ($h) = grep { $_->{img} && _artistMatch($want, _norm($_->{name})) } @cands;
                $loose = $h->{img} if $h;
            }
            $self->($self);
        };
        $timer = Slim::Utils::Timers::setTimer(undef, time() + ARTIMG_TIMEOUT, sub {
            return if $settled;
            _dbg("artist image '$name': $svc timed out");
            $settle->(undef);
        });
        my $q = ($a->{query_enc} || 'bytes') eq 'chars' ? $qChars : $qBytes;
        eval { $a->{artists}->($client, $q, $svc, $settle); 1 } or do {
            _dbg("artist image '$name': $svc failed: $@");
            $settle->(undef);
        };
    };
    $next->($next);
}

# Merge per-source artist hits into ONE deduped, deterministically ordered
# list: [ { name, sources => ['Local','Qobuz',...], artist_id? } ].
#
# RELEVANCE GATE (0.37.1 — the Beatles-junk fix, verified live): the services'
# artist searches return their whole RELEVANCE tail, and Tidal's even returns
# RELATED artists — "The Beatles" came back with Led Zeppelin, Pink Floyd,
# The Monkees, Paul McCartney. A hit survives only if it is TEXTUALLY related
# to what was typed:
#   * exact key match (also the only way in for punct-only names), or
#   * the normalised query is a SUBSTRING of the normalised name (covers
#     partial typing: "beatl" -> The Beatles), or
#   * _artistMatch token-subset either way ("Beatles" <-> "The Beatles";
#     "the beatles" <-> "Yesterday - A Tribute To The Beatles").
# So acts CONTAINING the typed text stay (that IS what was asked for — exact
# ranks first anyway), and the services' free-association neighbours drop.
#
# Dedupe key = the matcher's _norm of the name (falling back to _punctNorm for
# names _norm empties, e.g. "( )") — so the same act spelled slightly
# differently across services collapses to one row, while genuinely distinct
# names ("Laetitia Sadier" vs "Laetitia Sadier Source Ensemble") stay apart.
# The display name comes from the FIRST source to introduce the bucket
# (sources iterate in priority order, Local first — the library's spelling
# wins). Ordering: exact-normalised match on the query first, then breadth
# (found on more sources = more likely the act the user meant), then the
# first-seen relevance sequence; capped at SEARCH_MERGED_MAX. Pure function —
# no prefs, no network — the caller passes the source order (defaulting to
# Local + adapter priority).
#
# DELIBERATELY NO ENTITY FOLDING (decided 2026-07-17): services carry
# duplicate artist entities (Qobuz has BOTH "Beatles" and "The Beatles";
# "Chocolate Watchband" / "The Chocolate Watch Band" / a TYPO'd "The
# Chocoloate Watch Band") and an article/spacing/edit-distance fold was
# built, then REVERTED on Simon's call: we should not paper over streaming-
# service catalogue errors, and string similarity alone cannot prove two
# entities are one act ("Beatles"/"Beatless" and "Iron Maiden"/"The Iron
# Maidens" are one edit apart and genuinely distinct). If folding ever
# returns, it must be DISCOGRAPHY-VERIFIED — corroborate that the entities'
# release lists actually overlap (the 0.28.x library-disambiguation
# philosophy) — never inferred from the name.
# ---------------------------------------------------------------------------
# TYPO TOLERANCE FOR THE RELEVANCE GATE
#
# THE BUG (field, 2026-07-21). Simon typed "Layo & Bushwaka" — one letter out —
# and got NOTHING. The services had already done the hard part: Qobuz, Tidal
# and Deezer ALL returned "Layo & Bushwacka!" for that misspelling. Our gate
# then threw all 17 hits away and kept only a vague "Layo" (0 release groups),
# which the dead-end filter correctly dropped. So the search was strictly WORSE
# than the services it queries, and Simon was right that "from a user
# perspective this is broken".
#
# THIS IS NOT THE ENTITY FOLDING DECLINED ON 2026-07-17, and the distinction is
# the whole point. That decision rejected MERGING two service entities into one
# row on string similarity ("Beatles" + "The Beatles"), because a name cannot
# prove two entities are one act. Nothing here merges anything: bucketing is
# still EXACT `_norm` equality. This only decides whether a hit the service
# returned is relevant to what the USER TYPED — a query/result question, not an
# identity claim — and every admitted row still faces the dead-end filter.
#
# PURELY ADDITIVE: it runs only after the three existing tests have all failed,
# so it can never reject something that passes today. The 0.37.1 junk it must
# keep out (Tidal answering "The Beatles" with Led Zeppelin, Pink Floyd, The
# Monkees) is nowhere near the threshold.
#
# THRESHOLDS, measured against the REAL logged service hits (not invented):
#   lowest wanted-KEEP  0.944  (layo and bushwaka -> layo and bushwacka)
#   highest wanted-DROP 0.545  (the beatles -> beatless / the monkees)
# 0.85 sits far above the junk with margin on both sides.
#
# THE LENGTH FLOOR IS NOT DECORATION — it is doing real work. On short names a
# single edit is a DIFFERENT WORD: "eagles"/"beagles" scores 0.857 and
# "slayer"/"player" 0.833, both ABOVE the ratio threshold, and only the floor
# excludes them. Cost of the floor is a genuine miss on short typos
# ("nirvna"), accepted deliberately: no result beats a confidently wrong one.
use constant FUZZY_MIN_SIM => 0.85;
use constant FUZZY_MIN_LEN => 8;

# Levenshtein. NB the parameters are NOT $a/$b: a lexical $a/$b in scope
# silently breaks any sort/min written in terms of them — the 0.44.18 bug, and
# I reproduced it in this very function's first test harness.
sub _editDistance {
    my ($s1, $s2) = @_;
    return length($s2) unless length $s1;
    return length($s1) unless length $s2;
    my @prev = (0 .. length($s2));
    for my $i (1 .. length($s1)) {
        my @cur = ($i);
        for my $j (1 .. length($s2)) {
            my $del = $prev[$j] + 1;
            my $ins = $cur[$j - 1] + 1;
            my $sub = $prev[$j - 1]
                    + (substr($s1, $i - 1, 1) ne substr($s2, $j - 1, 1) ? 1 : 0);
            my $min = $del;
            $min = $ins if $ins < $min;
            $min = $sub if $sub < $min;
            push @cur, $min;
        }
        @prev = @cur;
    }
    return $prev[-1];
}

sub _closeEnough {
    my ($qn, $hn) = @_;
    return 0 unless length($qn) >= FUZZY_MIN_LEN && length $hn;
    my $max = length($qn) > length($hn) ? length($qn) : length($hn);
    # Cheap reject before the O(n*m) matrix: a length gap alone can already put
    # the pair out of reach, and most candidates fail here.
    return 0 if (abs(length($qn) - length($hn)) / $max) > (1 - FUZZY_MIN_SIM);
    return ((1 - _editDistance($qn, $hn) / $max) >= FUZZY_MIN_SIM) ? 1 : 0;
}

# ONE LAST CHANCE to attach a merged search row to the user's OWN library,
# using the row's own name.
#
# FIELD (Simon, 2026-07-22): searching "The Las" renders "The La's" with only
# Tidal/Deezer, although he owns it. Three independent safety nets exist and
# this is the one name that slips past ALL of them:
#
#   1. the Local leg: `artists search:The Las` returns The Last / The Last Word
#      / The Last Dinner Party -- real bands, WRONG ones. `_localArtistRows`
#      returns at the first non-empty step, so a wrong answer actively BLOCKS
#      the fallbacks. ("Las" is a prefix of "Last"; "OJays" is a prefix of
#      nothing, which is why The O'Jays never hits this.)
#   2. the term probes: skipped, because every word is under
#      PUNCT_PROBE_MIN_LEN -- "The" (3) and "Las" (3). Rag'n'Bone Man survives
#      only because "Bone" happens to be 4 letters.
#   3. API::filterRowsWithContent's MB canonical/alias attach: runs ONLY for
#      DUPLICATED mbid groups, and every service spells this one identically,
#      so it is a lone row. (The O'Jays is rescued there purely because the
#      services disagreed -- straight vs curly apostrophe. Luck, not design.)
#
# So it is not really an apostrophe problem: it is a SHORT-NAME problem, where
# the plain spelling collides with other real artists and the services agree.
#
# The row is already labelled with a service spelling the library CAN match
# ("The La's" -> library "The La’s"), so one more lookup settles it. Costs NO
# MusicBrainz request -- which is the cost filterRowsWithContent's alias fetch
# (duplicated groups only) was avoiding -- and runs
# on public installs too, where filterRowsWithContent bails out entirely.
#
# NORM-VERIFIED, the same gate the other attach paths use: an exact `_normKey`
# match, so "The Last" can never adopt "The La's".
use constant LIB_PROBE_MAX => 10;   # rows probed per search (each a local DB hit)

# TYPOGRAPHIC PUNCTUATION ONLY — curly quotes, the non-ASCII dashes, prime and
# ellipsis. NOT diacritics: "Björk" and "Sigur Rós" are correct spellings that
# every name-keyed lookup resolves, and must never be penalised here.
#
# WHY THIS EXISTS (regression I shipped in 0.48.1, caught by Simon the same
# day: "it doesn't have artwork"). 0.46.5 established that the LIBRARY's
# spelling outranks MusicBrainz's, measured on the live image proxy:
#     "The B-52s" (library, ASCII) -> 1,966,381 bytes, a photo
#     "The B‐52s" (MB, U+2010)     ->     5,071 bytes, the silhouette
# But that rule assumed the library holds the CLEANER spelling. Simon's library
# holds "The La’s" with a CURLY apostrophe, so adopting it blindly produced
# exactly the same failure in reverse — measured the same way:
#     "The La's" (ASCII)  -> 2,317,943 bytes, a photo
#     "The La’s" (curly)  ->     5,071 bytes, the SAME placeholder byte-for-byte
# So the rule is not "the library's spelling wins", it is "the spelling that
# RESOLVES wins" — which in 0.46.5's case happened to be the library's.
sub _typoMarks {
    my ($s) = @_;
    return 0 unless defined $s && length $s;
    my $d = $s;
    utf8::decode($d) unless utf8::is_utf8($d);
    my $n = () = $d =~ /[\x{2010}-\x{2015}\x{2018}-\x{201F}\x{2032}\x{2033}\x{2212}\x{2026}]/g;
    return $n;
}

# How many albums a contributor actually holds. Duplicate contributors are a
# real tagging artefact (Simon's library carries BOTH "The La's" and "The La’s"
# as separate artists), and only one of them has the music: 58667 has NO
# albums, 57545 has five. Attaching the empty one would open a blank page.
sub _albumCountFor {
    my ($id) = @_;
    return 0 unless $id;
    my $req = eval { Slim::Control::Request::executeRequest(undef,
        ['albums', 0, 1, "artist_id:$id", 'role_id:' . PERFORMANCE_ROLES]) };
    return 0 unless $req;
    my $n = $req->getResult('count');
    return (defined $n && $n =~ /^\d+$/) ? $n : 0;
}

# The albums a contributor performs on, as ids, AND their count, from ONE query
# (the same filter as _albumCountFor): { count => N, albums => [ids] }. The
# split needs both for the same contributors — the count orders the rows, the
# ids say whether a same-name contributor is its own act or only a credit on the
# main act's albums (splitOwnedByIdentity). `count` is the full total; `albums`
# stops at OWNED_ALBUMS_MAX, so a caller must check the list is whole.
use constant OWNED_ALBUMS_MAX => 500;
sub _albumsFor {
    my ($id) = @_;
    my %none = (count => 0, albums => []);
    return \%none unless $id;
    my $req = eval { Slim::Control::Request::executeRequest(undef,
        ['albums', 0, OWNED_ALBUMS_MAX, "artist_id:$id", 'role_id:' . PERFORMANCE_ROLES]) };
    return \%none unless $req;
    my @ids = map  { $_->{id} }
              grep { ref $_ eq 'HASH' && defined $_->{id} }
              @{ $req->getResult('albums_loop') || [] };
    my $n = $req->getResult('count');
    return { count => ((defined $n && $n =~ /^\d+$/) ? $n : scalar @ids), albums => \@ids };
}

# LMS's OWN per-artist icon URL, keyed by artist_id — the ARTIST art it shows in
# its artist menu (folder artist-art MAI ingests on rescan), NOT an album cover.
# Returns { artist_id => 'contributor/<hash>/image' | '' } for every same-name
# artist LMS lists: a URL when it holds artist art, '' when it knows the artist
# but has none (so the caller shows a neutral icon rather than MAI's online
# guess). Used to give same-name owned acts their OWN correct thumbnails —
# MAI's `imageproxy/mai/artist/<id>` route serves this SAME art when it exists
# (verified byte-identical), but INVENTS an online photo of the prominent act
# when it does not, which is exactly the "bootleg shows the UK band" case
# (Simon, 2026-07-23). Empty client, like every other CLI query here.
sub _artistMenuIcons {
    my ($name) = @_;
    return {} unless defined $name && length $name;
    my $enc = _cliChars($name);      # CHARACTERS - see _cliChars
    my $r = eval { Slim::Control::Request::executeRequest(undef,
        ['browselibrary', 'items', 0, 50, 'mode:artists', "search:$enc", 'menu:1']) };
    return {} unless $r;
    my %icon;
    for my $it (@{ $r->getResult('item_loop') || [] }) {
        my $aid = ($it->{commonParams} && $it->{commonParams}{artist_id})
               // ($it->{params}       && $it->{params}{artist_id});
        next unless $aid;
        $icon{$aid} = (defined $it->{icon} && length $it->{icon}) ? $it->{icon} : '';
    }
    return \%icon;
}

sub attachLibraryArtists {
    my ($class, $rows) = @_;
    return $rows unless $rows && @$rows;
    return $rows unless ($prefs->get('svc_priority_local') // 1) > 0;

    my ($probes, $found) = (0, 0);
    my @out;
    for my $r (@$rows) {
        my $name = $r->{name};
        if ($r->{artist_id} || !defined $name || !length $name
            || $probes >= LIB_PROBE_MAX) {
            push @out, $r;
            next;
        }
        $probes++;
        my $want = _normKey($name);
        my @hits = grep { _normKey($_->{name}) eq $want }
                   @{ _localArtistRows($name, { no_probe => 1 }) };
        if (!@hits) {
            # A COLLABORATION the user OWNS via its members (0.48.8). Field
            # (Simon, screenshot): the "Robert Plant & Alison Krauss" search row
            # read just "Qobuz", with no Local, though he owns Raising Sand —
            # which is tagged under both member contributors, not under a
            # contributor of the duo's name. So the exact probe above finds
            # nothing, but localAlbums' joint-credit intersection (0.48.6) does.
            # Add the Local SOURCE, but NO artist_id: there is no single
            # contributor to navigate to, and the row already drills to the duo
            # correctly by name/mbid. Only for a name that IS a joint credit, so
            # ordinary rows pay nothing.
            if (_creditParts($name) && @{ $class->localAlbums(undef, $name) }) {
                my %row  = %$r;
                my %have = map { $_ => 1 } @{ $row{sources} || [] };
                $row{sources} = [ @{ $row{sources} || [] } ];
                unshift @{ $row{sources} }, 'Local' unless $have{Local};
                $found++;
                _dbg("search rows: '$name' is an OWNED collaboration "
                     . '(intersection of member contributors) - added Local');
                push @out, \%row;
                next;
            }
            push @out, $r;
            next;
        }
        # Duplicate contributors differing only by apostrophe style are a real
        # tagging artefact, and only one of them holds the albums — take that
        # one, or the row opens a blank page. One extra query, and only when
        # the library genuinely has more than one match.
        my $hit = $hits[0];
        if (@hits > 1) {
            my ($best) = sort { $b->{_n} <=> $a->{_n} }
                         map  { { %$_, _n => _albumCountFor($_->{artist_id}) } } @hits;
            $hit = $best;
            _dbg("search rows: '$name' matched " . scalar(@hits)
                 . " library artists; kept '$hit->{name}' ($hit->{_n} album(s))");
        }
        # COPY before decorating: these rows come straight out of the 10-minute
        # search cache on a hit, and the fleet rule is never to decorate a
        # shared cache entry in place.
        my %row  = %$r;
        my %have = map { $_ => 1 } @{ $row{sources} || [] };
        $row{sources}   = [ @{ $row{sources} || [] } ];
        unshift @{ $row{sources} }, 'Local' unless $have{Local};
        $row{artist_id} = $hit->{artist_id};
        # THE SPELLING THAT RESOLVES WINS — not simply the library's.
        #
        # 0.46.5 made the library's spelling outrank MusicBrainz's because the
        # library held the cleaner one. Adopting it BLINDLY shipped the same bug
        # in reverse (0.48.1): Simon's library spells it "The La’s" with a curly
        # apostrophe, and the artist-artwork proxy returned the 5,071-byte
        # silhouette for that name while the ASCII "The La's" the row already
        # carried returned a 2,317,943-byte photo. The artist_id is still the
        # library's — that is where the albums are — only the LABEL is kept.
        $row{name} = $hit->{name} if _typoMarks($hit->{name}) <= _typoMarks($name);
        $found++;
        _dbg("search rows: attached library artist '$hit->{name}' (artist_id "
             . "$hit->{artist_id}) to row '$name'"
             . ($row{name} eq $name && $hit->{name} ne $name
                ? " - KEPT the row's spelling (fewer typographic marks)" : ''));
        push @out, \%row;
    }
    _dbg("search rows: library probe attached $found of $probes row(s)") if $probes;
    return \@out;
}

# A contributor's MusicBrainz artist tag (the SAME read getArtistMbid trusts
# first, in API::getArtistMbid), lowercased, or undef when untagged / not a UUID. Cheap: a
# local DB lookup, no network.
sub _contribMbid {
    my ($id) = @_;
    return undef unless $id;
    my $mbid = eval {
        require Slim::Schema;
        my $c = Slim::Schema->find('Contributor', $id);
        $c ? $c->musicbrainz_id : undef;
    };
    return (defined $mbid && $mbid =~ /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i)
        ? lc $mbid : undef;
}

# The titles of the albums library contributor $id is the ALBUM ARTIST of, a
# compilation excepted, oldest first, one per spelling: what the album lookup
# for an untagged library artist asks MusicBrainz about (API::getArtistMbid,
# resolver plan C2). Its own albums only: a compilation, or an album where it
# is a guest, would ask about other acts' records. One local query.
sub ownAlbumTitles {
    my ($class, $id) = @_;
    return [] unless $id;
    my $r = eval {
        Slim::Control::Request::executeRequest(undef,
            ['albums', 0, 500, "artist_id:$id", 'role_id:ALBUMARTIST', 'tags:lyaSw']);
    };
    return [] unless $r;
    my (%seen, @own);
    for my $e (@{ $r->getResult('albums_loop') || [] }) {
        next if $e->{compilation};
        next unless ($e->{artist_id} // '') eq $id;
        my $t = $e->{album};
        next unless defined $t && length $t;
        my $k = _norm($t);
        next unless length $k && !$seen{$k}++;
        push @own, [ $e->{year} || 9999, $t ];
    }
    return [ map { $_->[1] } sort { $a->[0] <=> $b->[0] || $a->[1] cmp $b->[1] } @own ];
}

# Titles that corroborate WEAKLY for same-name disambiguation, because lots of
# artists have one: a match on "Greatest Hits"/"Live"/etc. is near-coincidence.
# Stored _norm'd so they compare against a _norm'd title. (English-biased, but
# that's where most MB/streaming titles land; self-titled is handled separately
# and universally.) Down-weighted, not excluded — two of them still corroborate.
# Built on first use: _norm's tables further down this file are not filled yet
# while it loads. Moved here from Browse for C2, which weighs titles in API.
my %GENERIC_TITLE;

# Weight of one owned-album title as disambiguation EVIDENCE for a same-name
# artist. A SELF-TITLED album (title == artist name) is worthless here: every
# same-name candidate has one, so it matches them ALL and could hand a wrong one
# the tie-break — so 0.5, never decisive alone. A generic compilation title is
# likewise weak (0.5). A distinctive title is strong (1.0). Sums per candidate;
# Browse::_disambiguateByLibrary adopts at >= DISAMBIG_MIN_WEIGHT so a single
# self-titled/generic collision can't drive a wrong adoption, while ONE
# distinctive album still heals a tag.
sub _titleWeight {
    my ($title, $artist) = @_;
    %GENERIC_TITLE = map { _norm($_) => 1 } (
        'Greatest Hits', 'The Greatest Hits', 'Best Of', 'The Best Of',
        'Very Best Of', 'The Very Best Of', 'Collection', 'The Collection',
        'Anthology', 'Live', 'Unplugged', 'Hits', 'The Hits', 'Singles',
        'The Singles', 'Compilation', 'Essential', 'The Essential', 'Gold',
        'Retrospective', 'Discography', 'Rarities', 'Demos', 'Christmas',
    ) unless %GENERIC_TITLE;
    my $n = _norm($title // '');
    return 0.5 if length $n && $n eq _norm($artist // '');
    return 0.5 if $GENERIC_TITLE{$n};
    return 1.0;
}

# SPLIT AN OWNED SEARCH ROW INTO ONE ROW PER OWNED IDENTITY.
#
# Field (Simon): he owns THREE distinct acts called "The Bees" — the UK band,
# a US garage band and a third with a bootleg-only spine — as three separate
# library contributors, each carrying its own MusicBrainz tag. LMS's own library
# search shows all three; ours showed one, because `mergeArtistHits` buckets by
# `_norm(name)` and keeps only the FIRST contributor id (its `artist_id //=`) — so
# two of the three acts were unreachable, and the surviving row drilled into
# whichever contributor happened to be first (the garage band).
#
# Simon's rule, verbatim: "it should fold them if the same artist but if
# legitimate different acts it should not." The discriminator is MUSICBRAINZ
# IDENTITY, not the name string: contributors sharing a tag mbid are the same
# act (fold into one row); contributors with different tags are different acts
# (a row each). The three Bees carry three different tags, so three rows.
#
# WHY THIS IS A SEPARATE PASS, not part of the merge: `mergeArtistHits` is a
# PURE function (no DB), which is what lets t_fold/t_fuzzy/t_rank run headless
# and what its 10-minute cache stores. Identity needs the library, so it lives
# here, in the DB-aware layer, run by Browse::_withMbCandidates AFTER the merge
# — where the discarded contributor ids are re-derived from `_localArtistRows`.
#
# STREAMING SOURCES ARE DELIBERATELY NOT ATTRIBUTED. A service "The Bees" entity
# carries no MBID, so knowing which owned act it belongs to would mean the
# per-row spine scoring the search path refuses to pay (0.44.7 / 0.46.6). Each
# split row therefore lists only "Local" as its source (with its owned album
# count, `_owned`, to tell the rows apart); the CORRECT streaming catalogue is
# recovered on drill-in, where `_resolveArtist` scores it against that identity's
# spine. The planned library identity index is what makes attributing them cheap
# and safe later — until then, honest "Local" beats a guessed service label.
#
# `_ident_mbid` is stamped on EVERY owned row (single-identity too), for the
# search's same-name acts to exclude owned acts by mbid rather than by the older
# name-match heuristic. It is in-memory only — never rendered, never cached (the
# cache holds the pre-split merged list, same shape as before).
#
# A CONTRIBUTOR FOUND ONLY ON THE MAIN ACT'S ALBUMS IS NOT ANOTHER ACT (Simon,
# 2026-09-30: "Why do we get 2 air?" ... "yes we need a merge"). A different tag
# is not always a different act. One track on Air's own Premiers Symptômes,
# "Gordini Mix (Brakes On mix)", carries "Air" with Alex Gopher's MusicBrainz id
# (MB credits that recording to him), so LMS made a second "Air" and the search
# showed a "1 album" Air that opened Alex Gopher's page under Air's name. The
# Dream Syndicate's second result is the same shape (15 Minutes' id on the
# Expanded Edition's bonus tracks), and so are the rocksteady names with two
# contributors on one compilation. So an identity every one of whose albums the
# main act (the one holding the most) also performs on MERGES into it: a result
# of its own would open nothing that the main act's page does not already hold.
# Measured on the rig's library the same day (by name over JSON-RPC, which
# cannot see tags): 46 names have 2+ performing contributors; this leaves 15 of
# them one result, and the 31 others (The Bees, The Charlatans, Blur...) hold an
# album of their own each and keep their own results. Library
# only, one album query per contributor as before, no MusicBrainz request. An
# identity with no albums is left as it was (Saint Etienne's empty ones), and so
# is one whose list is cut short at OWNED_ALBUMS_MAX: only a whole list proves
# it. Discography-verified in the ledger's sense (A2 `Duplicate streaming
# artist entities are NOT`): shared albums decide it, never the name.
sub splitOwnedByIdentity {
    my ($class, $rows) = @_;
    return $rows unless $rows && @$rows;
    return $rows unless ($prefs->get('svc_priority_local') // 1) > 0;

    my $probes = 0;
    my @out;
    for my $r (@$rows) {
        my $name = $r->{name};
        # Only OWNED rows (an artist_id, from the Local leg or attachLibraryArtists)
        # can be split, and the probe is bounded like attachLibraryArtists'.
        if (!$r->{artist_id} || !defined $name || !length $name
            || $probes >= LIB_PROBE_MAX) {
            push @out, $r;
            next;
        }
        $probes++;

        # All same-name contributors, deduped by id, in LMS's stable order.
        my $want = _normKey($name);
        my (%seenId, @contribs);
        for my $c (grep { _normKey($_->{name}) eq $want }
                   @{ _localArtistRows($name, { no_probe => 1 }) }) {
            next unless $c->{artist_id} && !$seenId{ $c->{artist_id} }++;
            push @contribs, $c;
        }
        # The row's own contributor may not spell-match its label (0.48.1 keeps
        # the row's spelling); make sure it is represented.
        push @contribs, { name => $name, artist_id => $r->{artist_id} }
            unless $seenId{ $r->{artist_id} }++;

        # Group by MusicBrainz identity. An untagged contributor is its own
        # identity, keyed by id, so two untagged same-name contributors are NOT
        # blindly folded (we cannot prove they are one act) — but neither do
        # they masquerade as each other.
        my (%grp, @order);
        for my $c (@contribs) {
            my $key = _contribMbid($c->{artist_id}) // "id:$c->{artist_id}";
            push @order, $key unless $grp{$key};
            push @{ $grp{$key} }, $c;
        }

        # ONE identity -> the row is a single act. Stamp its mbid and keep it.
        if (@order < 2) {
            my %row = %$r;
            $row{_ident_mbid} = _contribMbid($r->{artist_id});
            push @out, \%row;
            next;
        }

        # SEVERAL identities. Each contributor's albums are asked ONCE, before
        # any sort: _albumsFor is a DB query, and inside a comparator it runs
        # O(n log n) times and then again for the winner (what the 0.51.x note
        # already claimed, "no new query", made true 2026-09-20). The same query
        # carries the album ids the merge below reads.
        my %alb = map { ($_->{artist_id} // '') => _albumsFor($_->{artist_id}) } @contribs;
        my $count = sub { $alb{ $_[0]{artist_id} // '' }{count} };
        my @reps;
        for my $key (@order) {
            # Within one identity, the contributor holding the most albums is
            # the one that drills to content (apostrophe-variant duplicates).
            my ($rep) = sort { $count->($b) <=> $count->($a) } @{ $grp{$key} };
            push @reps, [ $rep, ($key =~ /^id:/ ? undef : $key), $count->($rep), $key ];
        }
        # The act holding the most albums FIRST, contributor id breaking ties so
        # the item_id walk stays stable. Field (Simon, Saint Etienne,
        # 2026-09-19): a Various Artists compilation tagged with the curator as a
        # track artist minted ~20 empty same-name contributors, all with LOWER
        # ids than the real act; ordering by id alone put an empty one at the
        # top of the search, and it drilled to a stranger's blank page.
        @reps = sort { $b->[2] <=> $a->[2]
                       || $a->[0]{artist_id} <=> $b->[0]{artist_id} } @reps;

        # MERGE an identity found only on the main act's albums (see the note
        # above the sub): it needs albums, a whole list, and every one of them
        # among the albums the main act performs on.
        my ($main, @others) = @reps;
        my %mainAlbum = map { $_ => 1 }
                        map { @{ $alb{ $_->{artist_id} // '' }{albums} } }
                        @{ $grp{ $main->[3] } };
        my (@keep, @merged);
        for my $p (@others) {
            my @lists = map { $alb{ $_->{artist_id} // '' } } @{ $grp{ $p->[3] } };
            my @ids   = map { @{ $_->{albums} } } @lists;
            my $whole = !grep { $_->{count} > @{ $_->{albums} } } @lists;
            if (@ids && $whole && !grep { !$mainAlbum{$_} } @ids) { push @merged, $p }
            else                                                  { push @keep,   $p }
        }
        _dbg("search rows: '$name' - merged contributor(s) "
             . join(', ', map { $_->[0]{artist_id} } @merged)
             . " into $main->[0]{artist_id}: found only on its albums") if @merged;

        # Only the main act is left: an ordinary owned row again, opening on
        # the main act's contributor (the row may have carried the merged one),
        # with its streaming sources and no album count.
        unless (@keep) {
            my %row = %$r;
            $row{artist_id}   = $main->[0]{artist_id};
            $row{_ident_mbid} = $main->[1];
            push @out, \%row;
            next;
        }

        # Still SEVERAL acts -> one Local row per act, in that order.
        _dbg("search rows: '$name' is " . (1 + @keep)
             . ' distinct owned acts (by MB identity) - splitting into rows');
        # LMS's own per-act artist icons (one browselibrary query), so same-name
        # acts get their OWN artist art instead of MAI's online photo of the
        # prominent one.
        my $icons = _artistMenuIcons($name);
        for my $pair ($main, @keep) {
            my ($rep, $identMbid, $owned) = @$pair;
            # LMS's ARTIST icon for this act: a URL when it has artist art (use
            # it), '' when LMS knows the act but has none (show a neutral icon,
            # NOT MAI's online guess of the prominent act), undef/absent when the
            # act is not in the menu (fall back to MAI as usual).
            my $ic = $icons->{ $rep->{artist_id} };
            push @out, {
                name       => $rep->{name},
                artist_id  => $rep->{artist_id},
                sources    => ['Local'],
                _ident_mbid => $identMbid,
                (defined $ic && length $ic ? (_img   => $ic)
                 : defined $ic             ? (_noart => 1)
                 :                           ()),
                _exact     => $r->{_exact},
                # The albums this act's row opens on (the count the order above
                # used): the row's line2 shows it, because split rows share a
                # name and a "Local" line and are otherwise identical on screen
                # (Browse::_searchResultRow; stage 3 live check, 2026-09-30).
                _owned     => $owned,
                # keep the split rows clustered where the original row sat;
                # rankArtistHits' stable sort preserves the emission order above
                # for equal _seq.
                _seq       => $r->{_seq},
            };
        }
    }
    return \@out;
}

# RANKING — ONE comparator, deliberately applied TWICE.
#
# Simon, 2026-07-22: *"when searching, a Local artist will show ahead of any
# matches that there is no local artist ... local should always be trumps."*
# Ownership was not a rank key at all; the order was exactness, then how many
# services carried the row, then first-seen. Measured live before changing it:
#
#   typed 'bush'     0 Bush        Q·T·D   <- NOT owned, wins on exact name
#                    1 Kate Bush   Local·Q·D
#                    2 Bush Tetras Local·Q·D
#   typed 'The Las'  6 The Last      Local  <- owned, sunk under six streaming
#                    7 The Last Word Local     rows purely on breadth
#
# WHY OWNERSHIP OUTRANKS EXACTNESS, and this was Simon's call after seeing both
# orderings side by side: "exact" is not only what the user typed — 0.46.4 also
# accepts MusicBrainz's canonical name for whatever the query RESOLVED to, so a
# wrong resolution confers exactness on an unrelated artist. Measured: MB
# resolves the query "La's" to *Yo La Tengo*. Ranking ownership below that key
# means the one thing a user can verify (they own the record) loses to an MB
# inference. Owning it is the strongest signal of intent there is.
#
# ACCEPTED COST, stated plainly: typing a name that exactly matches an artist
# you do NOT own now puts owned near-misses above it — 'bush' returns Kate Bush
# and Bush Tetras before Bush. That is the deliberate trade, not an oversight.
#
# artist_id IS the ownership test and cannot be anything else: `_artistHits`
# builds every streaming hit as `{ name => ... }` with no id whatsoever, so an
# artist_id on a merged row can only have come from the Local leg or from
# `attachLibraryArtists`.
#
# APPLIED TWICE because the two facts arrive at different times. The merge
# knows what the LOCAL LEG found; `attachLibraryArtists` (0.48.1) rescues rows
# the Local leg could not spell-match — "The La's" is the whole reason that sub
# exists — and it runs AFTER the merge, in Browse::_withMbCandidates. Ranking
# only inside the merge would therefore miss exactly the rows 0.48.1 was
# written for. Ranking only after it would let SEARCH_MERGED_MAX truncate an
# owned row before it could be promoted. Both calls, one comparator.
#
# `_seq` is preserved rather than recomputed, so the second pass re-ranks
# WITHOUT re-basing the first-seen tiebreak — the order stays deterministic for
# a given library state, which is what the item_id walk depends on.
sub rankArtistHits {
    my ($class, $rows) = @_;
    return $rows unless $rows && @$rows;
    # OWNERSHIP is artist_id OR a Local source. Normally a Local row carries the
    # contributor id, but an OWNED COLLABORATION (0.48.8) is Local with NO id —
    # there is no single contributor for a duo — and it must still trump.
    my $owned = sub {
        return 1 if $_[0]->{artist_id};
        return scalar grep { $_ eq 'Local' } @{ $_[0]->{sources} || [] };
    };
    my $i = 0;
    for my $r (@$rows) {
        $r->{_seq}   = $i unless defined $r->{_seq};
        $r->{_exact} = 0  unless defined $r->{_exact};
        $i++;
    }
    return [ sort {
        ($owned->($b) ? 1 : 0) <=> ($owned->($a) ? 1 : 0)
            || $b->{_exact} <=> $a->{_exact}
            || @{ $b->{sources} || [] } <=> @{ $a->{sources} || [] }
            || $a->{_seq} <=> $b->{_seq}
    } @$rows ];
}

sub mergeArtistHits {
    my ($class, $query, $bySvc, $order, $also) = @_;
    my @order = $order ? @$order
              : ('Local', map { $_->{name} } orderedAdapters());
    my $key = sub {
        my $k = _norm($_[0] // '');
        $k = _punctNorm($_[0] // '') if $k eq '';
        return $k;
    };

    # ACCEPTED QUERIES: what was typed, PLUS any name the caller ALSO searched
    # the services under (0.45.2's canonical-name pass).
    #
    # Field (Simon, 2026-07-22): searching "b52s" produced a row without Deezer
    # while "b-52s" had all three. Deezer was not missing -- it returned two
    # artists and both were thrown away here, because a hit fetched under MB's
    # canonical name was judged against the string the USER typed:
    #   _norm("The B-52's") = 'the b 52s'   vs typed 'b52s'
    #   substring no · token-subset no · fuzzy no (4-char query, floor is 8)
    # Qobuz and Tidal survived only because their result lists happened to also
    # contain "B52's", which folds exactly onto the typed query -- a spelling
    # lottery, not a Deezer difference.
    #
    # A hit returned for the canonical name must be judged against THAT name.
    # This cannot admit an unrelated artist: the extra query is MusicBrainz's
    # own name for the artist the typed query already resolved to, and every
    # admitted row still faces the dead-end filter downstream.
    my @qk = grep { $_ ne '' } map { $key->($_) }  ($query, @{ $also || [] });
    my @qn = grep { $_ ne '' } map { _norm($_ // '') } ($query, @{ $also || [] });
    my $isExact = sub { my $k = shift; scalar grep { $_ eq $k } @qk };

    my (%bucket, @seq);
    for my $svc (@order) {
        for my $h (@{ $bySvc->{$svc} || [] }) {
            next unless ref $h eq 'HASH';
            my $k = $key->($h->{name});
            next if $k eq '';
            # The relevance gate. No usable query norm (a punct-only query)
            # leaves exact key equality as the only way in.
            unless ($isExact->($k)) {
                my $hn = _norm($h->{name} // '');
                next unless $hn ne '' && grep {
                    index($hn, $_) >= 0 || _artistMatch($_, $hn)
                        || _closeEnough($_, $hn)
                } @qn;
            }
            my $b = $bucket{$k};
            unless ($b) {
                $b = $bucket{$k} = {
                    name => $h->{name}, sources => [],
                    _seq => scalar @seq, _exact => $isExact->($k) ? 1 : 0,
                };
                push @seq, $b;
            }
            push @{ $b->{sources} }, $svc
                unless grep { $_ eq $svc } @{ $b->{sources} };
            $b->{artist_id} //= $h->{artist_id} if $h->{artist_id};
            # The first source IN PRIORITY ORDER to carry a photo lends it to
            # the row (0.51.0) — it rode in on the search response, so a search
            # result costs nothing extra to illustrate. Local rows have no
            # `img`; they keep going through the LMS/MAI id route above it.
            $b->{img} //= $h->{img} if $h->{img};
        }
    }
    # Rank BEFORE the cap, or an owned row sitting past SEARCH_MERGED_MAX would
    # be truncated away before Browse's post-attach pass could promote it.
    # `_seq`/`_exact` are deliberately NOT stripped: they are what lets that
    # second pass re-rank consistently, including on the cached path (the rows
    # go into `dsc:asearch` carrying them).
    my $merged = $class->rankArtistHits(\@seq);
    splice @$merged, SEARCH_MERGED_MAX if @$merged > SEARCH_MERGED_MAX;
    return $merged;
}

# ---------------------------------------------------------------------------
# Per-release matching (local filter over the candidate lists)
# ---------------------------------------------------------------------------

# The normalised sides of an "A / B" title — a 45rpm single is titled with both
# sides ("Voices Green and Purple / Trip to New Orleans") while the compilation
# holds only one ("Voices Green and Purple"). Split on a spaced slash so a title
# with an inline "/" ("AC/DC", "9/11") is left whole.
sub _titleSides {
    my ($title) = @_;
    return [] unless defined $title && length $title;
    return [ grep { length } map { _norm($_) } split m{\s+/\s+}, $title ];
}

# Does an owned TRACK correspond to this release group? Title-based and A/B-side
# aware, in BOTH directions (the release may name both sides while the track
# names one, or vice versa). The >= 4-char guard keeps a trivial/generic title
# from linking; the real safety is that the caller only ever passes THIS
# artist's own tracks (id-keyed), so a match is this artist's song either way.
sub _trackLinksRelease {
    my ($rgNorm, $rgTitle, $track) = @_;
    my $tn = _norm($track->{_candTitle} // '');
    return 0 unless length $tn >= 4 && length $rgNorm >= 4;
    return 1 if $tn eq $rgNorm;
    return 1 if grep { $_ eq $tn }     @{ _titleSides($rgTitle) };
    return 1 if grep { $_ eq $rgNorm } @{ _titleSides($track->{_candTitle}) };
    return 0;
}

# THE SAME RELEASES WHICHEVER NAME OPENED THE PAGE (C3, 2026-10-01). A page
# tests each streaming copy's credit against the name it was opened under, so a
# page opened under another of the artist's MusicBrainz names rejected every
# copy: "米津玄師" (MusicBrainz's own name for him) read "No releases found" from
# a healthy pool (Qobuz 73, TIDAL 43) because the services credit "Kenshi
# Yonezu", while the "Kenshi Yonezu" page showed 24 releases; the same mbid, the
# same pool. Genesis Mohanraj / Tommy Genesis (2026-09-30) is the same case.
#
# Returns the artist's other names (normalised; MusicBrainz's canonical name and
# aliases, Browse::_otherNames) that $credit matches when the page's own name
# does not: [] when the page's name matches, or none does. The caller then judges
# the copy under that name, title rules and artist check alike, exactly as the
# page opened under it would, so the page shows what one of the artist's own
# names would show, and a copy credited under the page's own name is judged
# exactly as before. $memo (optional) keeps the answer per credit, as the service
# gives it, for one page's names, so a list build normalises each credit once.
# Call-site logic like 0.24.0's Local gate: the shared matcher subs are
# untouched, so this is not a fleet port.
sub _otherNamesFor {
    my ($artistNorm, $other, $credit, $memo) = @_;
    return [] unless $other && @$other;
    $credit //= '';
    return $memo->{$credit} if $memo && $memo->{$credit};
    my $cn = _norm($credit);
    my $hit = ($cn eq '' || _artistMatch($artistNorm, $cn)) ? []
            : [ grep { _artistMatch($_, $cn) } @$other ];
    $memo->{$credit} = $hit if $memo;
    return $hit;
}

# matchesFor($bySvc, $artist, $albumTitle, $local) ->
#   [ { svc => 'Local'|'Qobuz'|..., icon, items => [nodes] }, ... ]
# in orderedSources priority order, only sources with matches; per-source
# dedupe + cap; streaming items get the ListenLater favurl handshake (Local
# ones don't — there's no service scheme to hand over).
# $opt->{localTracks} (an arrayref OR a lazy coderef) links a release the user
# owns ONLY as a Various Artists compilation track — see the track-link pass below.
sub matchesFor {
    my ($class, $bySvc, $artist, $albumTitle, $local, $rgMbid, $relMap, $rivals, $opt) = @_;
    $opt ||= {};

    # Whole-list builds thread precomputed invariants in via $opt: the artist
    # norm and the source order are IDENTICAL for every release group, yet
    # orderedSources() reads prefs + builds + sorts an array on EACH call and
    # _norm folds Unicode — recomputing both per-RG was pure waste (a big artist
    # calls matchesFor once per release group). The album norm is just the RG
    # title's, which the caller already normed for the rivals lookup. Each falls
    # back to computing here for standalone callers (detail page, unit tests).
    my $artistNorm = defined $opt->{artistNorm} ? $opt->{artistNorm} : _norm($artist);
    my $albumNorm  = defined $opt->{albumNorm}  ? $opt->{albumNorm}  : _norm($albumTitle);
    my $sources    = $opt->{sources} || [ orderedSources() ];
    my $rgSingle   = ($opt->{rgType} // '') eq 'Single';

    # Candidate index (peekPool builds it): STREAMING pools only test the subset
    # sharing a first token with this release group, not the whole pool. Local
    # pools are small AND match by release MBID (not just title), so they always
    # full-scan. A short (<2 char) album norm matches via the raw-punctuation
    # branch (no first token) -> full-scan too. Empty @lkeys => full scan.
    # MB release-group ALIASES (v2 spine): MusicBrainz titles a group in its
    # original language and files other spellings as aliases, which no title
    # normalisation can reach. Tried only AFTER the canonical title, so an
    # alias can rescue a miss but never change a match that already works.
    my @alts;
    for my $al (@{ $opt->{aliases} || [] }) {
        next unless defined $al && length $al;
        my $an = _norm($al);
        next if $an eq '' || $an eq $albumNorm;
        push @alts, [ $an, $al ];
    }

    my $index = $opt->{index};
    my @lkeys = ($index && length $albumNorm >= 2) ? _titleKeys($albumNorm, $artistNorm) : ();
    # An alias routinely starts with a DIFFERENT word than the canonical title
    # ("Computerwelt" vs "Computer World"), and the index buckets by first
    # token — so without folding the aliases' keys in here, the narrowed subset
    # could not contain the very candidate the alias exists to reach.
    if ($index && @lkeys && @alts) {
        my %seenK = map { $_ => 1 } @lkeys;
        for my $a (@alts) {
            next unless length $a->[0] >= 2;
            push @lkeys, grep { !$seenK{$_}++ } _titleKeys($a->[0], $artistNorm);
        }
    }

    # EDITION titles (Browse::_editionTitles): tried last, with the alias
    # pass's strict whole-title shape. An album-only one (it clashes with a
    # single's real title) needs an album-sized copy.
    my @eds = grep { ref $_ eq 'ARRAY' && length($_->[0] // '') } @{ $opt->{editions} || [] };
    if ($index && @lkeys && @eds) {
        my %seenK = map { $_ => 1 } @lkeys;
        for my $e (@eds) {
            next unless length $e->[0] >= 2;
            push @lkeys, grep { !$seenK{$_}++ } _titleKeys($e->[0], $artistNorm);
        }
    }

    # Canonical title first, then each alias, then each edition title.
    # Returns 1 on the first hit. $an: the artist name the copy is judged under
    # (the page's own, unless the copy is credited under another of its names).
    my $titleHit = sub {
        my ($gateArtist, $it, $isLocal, $an) = @_;
        $an //= $artistNorm;
        my $candTitle = $it->{_candTitle};
        return 1 if _albumMatches($an, $albumNorm, $gateArtist, $candTitle, $albumTitle);
        for my $a (@alts) {
            return 1 if _aliasMatches($an, $a->[0], $a->[1], $gateArtist, $candTitle);
        }
        for my $e (@eds) {
            next unless _aliasMatches($an, $e->[0], $e->[1], $gateArtist, $candTitle);
            return 1 unless $e->[2];
            return 1 if (($isLocal ? _localSize($it) : $it->{_size}) // '') eq 'album';
        }
        return 0;
    };
    # The artist's OTHER MusicBrainz names (C3; $opt->{otherNames}, normalised):
    # see _otherNamesFor. $opt->{creditMemo} keeps the per-credit answer for a
    # whole list build.
    my $other = $opt->{otherNames};
    my $memo  = $opt->{creditMemo} || {};
    # { owned album id => group } put there by the track match or by hand.
    my $placed = $opt->{placed};

    my %all = %{ $bySvc || {} };
    $all{Local} = $local if $local && @$local;

    my @sections;
    for my $a (@$sources) {
        my $svc   = $a->{name};
        my $cands = $all{$svc} or next;

        # Narrow to the index subset for a streaming service when we can.
        my $iter = $cands;
        if (!$a->{local} && @lkeys && (my $idx = $index->{$svc})) {
            my (%seenIt, @sub);
            for my $key (@lkeys) {
                push @sub, grep { !$seenIt{$_}++ } @{ $idx->{$key} || [] };
            }
            $iter = \@sub;
        }

        my (%seen, @matched);
        for my $it (@$iter) {
            # A PLACED owned copy (0.56.61, $opt->{placed}: the track match or
            # the user's own match, Browse::_placements) is its group's alone,
            # as an MBID places it: matched there without a title, nowhere else.
            my $pg = ($a->{local} && $placed && defined $it->{_albumid})
                   ? $placed->{ $it->{_albumid} } : undef;
            next if defined $pg && $pg ne ($rgMbid // '');
            # Identity (tier 0) is never second-guessed by the rival rule: an
            # MBID says which group this IS.
            unless (defined $pg || _mbidMatch($it, $rgMbid, $relMap)) {
                # Its id places it in another group on this page: it is that
                # group's, never this one's by title.
                next if defined _idGroup($it, $relMap, $opt->{idGroups});
                # A LOCAL candidate was fetched by artist_id + performance role,
                # so the DB join ALREADY proves the browsed artist performs on
                # this album. The `albums` query then collapses a multi-artist
                # ALBUMARTIST to ONE display string (Robert Plant + Alison Krauss
                # -> "Robert Plant"), which would wrongly fail _albumMatches' MANDATORY
                # artist gate for a co-credited / band-fronted owned album. Trust
                # the join: gate Local on the BROWSED artist (title must still
                # match). _candArtist is left untouched so Browse's "Appearances"
                # split still sees the true album-artist. (Simon: Raising Sand,
                # 2026-07-11.) Only for an album credited TO the artist: one he
                # is only credited ON (`_otherArtist`, localAlbums) is judged
                # under its own album artist, so it never claims another
                # album's tile (0.56.43, Nancy Sinatra's "Greatest Hits").
                my $gateArtist = ($a->{local} && !$it->{_otherArtist}) ? $artist : $it->{_candArtist};
                my $hit = $titleHit->($gateArtist, $it, $a->{local});
                # A copy credited under another of the artist's MusicBrainz names
                # is judged as that name's own page would judge it (C3).
                unless ($hit || $a->{local}) {
                    for my $on (@{ _otherNamesFor($artistNorm, $other, $it->{_candArtist}, $memo) }) {
                        last if $hit = $titleHit->($gateArtist, $it, 0, $on);
                    }
                }
                next unless $hit;
                # AN ALBUM IS NOT A SINGLE (Simon, Kraftwerk, 2026-09-19): his
                # 12-track "Tour De France" read Local on the single "Tour de
                # France (Etape 2) (edit)" on title alone. A copy of unknown
                # size is left to the title, as before.
                next if $rgSingle
                     && (($a->{local} ? _localSize($it) : $it->{_size}) // '') eq 'album';
                # Several same-title groups matched it; only its owner keeps it.
                next if $rivals && @$rivals > 1 && $rgMbid
                     && _rivalOwner($it->{_year}, $rivals) ne $rgMbid;
                # ANOTHER ALBUM ON THIS PAGE IS CALLED EXACTLY THIS (0.56.51;
                # Simon, Stan Getz, 2026-10-07): the edition-suffix rule read
                # "Getz/Gilberto #2" and "Getz / Gilberto '76" as editions of
                # "Getz / Gilberto", though each is its own MusicBrainz album on
                # the same page. A copy whose title is exactly another group's
                # belongs to that group alone. $opt->{pageTitles} is the page's
                # rivals map (Browse::_rivalsByTitle: every group the page can
                # show, by normalised title), so a hidden or bootleg group never
                # takes a copy from a shown one, as for the rival rule above.
                # Only an owner that can TAKE the copy counts: a Single never
                # takes an album-sized one (the gate above), so Kraftwerk's
                # album copy "Radio-Activity", matched through the album's
                # alias, stays the album's although a single has that title.
                if (my $pt = $opt->{pageTitles}) {
                    my $cn = _norm($it->{_candTitle} // '');
                    if (length $cn && $cn ne $albumNorm && (my $own = $pt->{$cn})) {
                        my $size = ($a->{local} ? _localSize($it) : $it->{_size}) // '';
                        next if grep { ($_->{type} // '') ne 'Single' || $size ne 'album' }
                                     @{ ref $own eq 'ARRAY' ? $own : [] };
                    }
                }
            }
            # ONE ROW PER COPY, NOT PER LABEL (0.56.51; Simon, 2026-10-07: "under
            # all services we need to expose the versions they have and not throw
            # them away"). Copies were deduplicated on name|line2, so a service's
            # look-alike editions (three 1964 "Getz/Gilberto" on Qobuz) showed as
            # one. A copy with an album id is now one row per id (%seen is this
            # service's); one without keeps the old key.
            my $k = defined $it->{_albumid} && length $it->{_albumid}
                  ? join('|', 'id', $it->{_albumid})
                  : join('|', $it->{name} // '', $it->{line2} // '');
            next if $seen{$k}++;
            my %item = %$it;   # per-release copy — never decorate the shared cache entry
            # native_favurl (Spotify): the service's own favurl already works, and
            # decorating it would break it — keep it exactly as rendered.
            _attachFavUrl(\%item, $svc, $item{_cover}, $artist)
                unless $a->{local} || $a->{native_favurl};
            push @matched, \%item;
            last if @matched >= MAX_PER_SVC;
        }
        push @sections, { svc => $svc, icon => $a->{icon}, items => \@matched } if @matched;
    }

    # TRACK LINKING — a release the user owns ONLY as a Various Artists
    # compilation track (localTracks keeps VA-comp tracks only, 0.51.9).
    # Runs ONLY when nothing else matched (an orphaned, otherwise-unplayable
    # spine release): if an owned track links to this release's title, add a
    # Local section that plays that track directly (db:track.id). The comp album
    # itself stays under "Appearances" — this only makes the spine tile playable.
    # localTracks is a lazy coderef so an artist owned as ALBUMS never fetches
    # it; resolved here only because we reached an unmatched release.
    #
    # A SINGLE, ONCE (0.56.39; Simon 2026-10-02, on Ella Fitzgerald with only
    # what he owns: "the same track is showing multiple times under compilations
    # and not one gives the album name"). One owned "A-Tisket, A-Tasket" (on the
    # soundtrack The Last Time I Committed Suicide) made THREE compilation
    # ALBUMS named after the song read Local: a song links the release that IS
    # the song, a single, never an album or compilation that only shares its
    # name. And of several same-titled singles only the first (rivals' order,
    # the earliest) gets it; an album sharing the title never takes it from
    # the single (the album is not the song).
    my $trackLinkable = $rgSingle && !$opt->{rgComp};
    if ($trackLinkable && $rivals && @$rivals > 1 && $rgMbid) {
        my ($first) = grep { ($_->{type} // '') eq 'Single' && !$_->{comp} } @$rivals;
        $trackLinkable = 0 if $first && $first->{mbid} ne $rgMbid;
    }
    if (!@sections && $trackLinkable && $opt->{localTracks}) {
        my $lt = ref $opt->{localTracks} eq 'CODE'
               ? $opt->{localTracks}->() : $opt->{localTracks};
        if ($lt && @$lt) {
            my ($localSrc) = grep { $_->{local} } @$sources;
            my (%seen, @tmatch);
            for my $t (@$lt) {
                next unless _trackLinksRelease($albumNorm, $albumTitle, $t);
                next if $seen{ $t->{_trackid} // $t->{_candTitle} }++;
                push @tmatch, { %$t };   # per-release copy, never the shared entry
                last if @tmatch >= MAX_PER_SVC;
            }
            if (@tmatch) {
                unshift @sections, { svc => 'Local',
                    icon => ($localSrc ? $localSrc->{icon} : undef), items => \@tmatch };
                _dbg("track-link '" . ($albumTitle // '') . "' [" . ($artist // '')
                     . "]: " . scalar(@tmatch) . ' owned comp track(s)');
            }
        }
    }

    # The matching-diagnosis line: which services hit, and how big each
    # candidate pool was — a miss with a healthy pool means the matcher
    # rejected everything (title/artist normalisation gap, worth a look with
    # the LBF match_check tooling); an empty pool means the service search
    # itself returned nothing for this artist.
    _dbg("match '" . ($albumTitle // '') . "' [" . ($artist // '') . "]: "
        . (@sections ? join(', ', map { $_->{svc} . '=' . scalar @{ $_->{items} } } @sections) : 'NO MATCH')
        . ' | pool: '
        . (join(', ', map { $_ . '=' . scalar @{ $all{$_} || [] } } sort keys %all) || 'none'));

    return \@sections;
}

# Which local album ids are claimed by ANY release group of this artist —
# pure-CPU matcher pass (no cache reads), used to find the LEFTOVER library
# albums for the "Also in your library" safety-net section. Claims run across
# every RG the caller passes (including type-filtered ones) so a hidden
# section can't resurface its matches as "unmatched".
sub claimedLocalIds {
    my ($class, $rgs, $artist, $local, $relMap, $editions, $placed) = @_;
    my %claimed;
    return \%claimed unless $local && @$local;
    # A placed owned copy (0.56.61, Browse::_placements) has its tile.
    if ($placed) {
        $claimed{ $_->{_albumid} } = 1
            for grep { defined $_->{_albumid} && defined $placed->{ $_->{_albumid} } } @$local;
    }
    my $artistNorm = _norm($artist);
    # The pool's groups, for the same "placed by id elsewhere" rule as matchesFor.
    my %idGroups = map { $_->{mbid} => 1 } grep { $_->{mbid} } @{ $rgs || [] };
    for my $rg (@{ $rgs || [] }) {
        my $albumNorm = _norm($rg->{title});
        # Same alias pass as matchesFor — an owned copy filed under the English
        # title must be claimed by the German-titled release group, or it leaks
        # into "Also in your library" while its own tile sits right above it.
        my @alts;
        for my $al (@{ $rg->{aliases} || [] }) {
            next unless defined $al && length $al;
            my $an = _norm($al);
            next if $an eq '' || $an eq $albumNorm;
            push @alts, [ $an, $al ];
        }
        for my $it (@$local) {
            next if $claimed{ $it->{_albumid} };
            # $local candidates are ALL Local (join-proven for the browsed
            # artist), so gate on $artist not the collapsed _candArtist — same
            # co-credit reasoning as matchesFor. Keeps a co-credited owned album
            # from leaking into "Also in your library" when its tile matched.
            # And the same exception as matchesFor: an album only credited ON
            # the artist is judged under its own album artist (0.56.43).
            my $gate = $it->{_otherArtist} ? $it->{_candArtist} : $artist;
            unless (_mbidMatch($it, $rg->{mbid}, $relMap)) {
                next if defined _idGroup($it, $relMap, \%idGroups);
                next unless _albumMatches($artistNorm, $albumNorm, $gate, $it->{_candTitle}, $rg->{title})
                         || (grep { _aliasMatches($artistNorm, $_->[0], $_->[1], $gate,
                                                  $it->{_candTitle}) } @alts)
                         # Edition titles, as matchesFor tries them.
                         || (grep { _aliasMatches($artistNorm, $_->[0], $_->[1], $gate, $it->{_candTitle})
                                    && (!$_->[2] || (_localSize($it) // '') eq 'album') }
                                  @{ ($editions || {})->{ $rg->{mbid} } || [] });
                # Same size gate as matchesFor, or an album the single no longer
                # shows would ALSO be hidden from "Also in your library".
                next if ($rg->{type} // '') eq 'Single' && (_localSize($it) // '') eq 'album';
            }
            $claimed{ $it->{_albumid} } = 1;
        }
    }
    return \%claimed;
}

# Read + reattach every service's cached candidate pool ONCE per build. The
# artist-first fetch made these pools big (thousands of items), and _reattach
# shallow-copies every item — doing it per release group meant tens of
# thousands of hash copies on the single-threaded event loop for one list
# render. Callers building a whole list hoist this out of their loop and hand
# the result to peekMatches.
# $mbid MUST be passed wherever getCandidates was given one, or the render
# reads a DIFFERENT cache entry than the warm wrote (field, 0.43.1: the warm
# fetched into `mb:<mbid>` while this read the name-keyed pool, so the fix could
# not take effect and the page still matched against the prominent act's
# catalogue). Read key and write key are the same function for exactly this
# reason — keep them that way.
sub peekPool {
    my ($class, $artist, $mbid) = @_;
    return { bySvc => {}, resolved => 0, index => {} }
        unless defined $artist && length $artist;

    my $artistNorm = _norm($artist);
    my (%bySvc, %index, $resolved);
    # COLD = not one service has a cached entry, i.e. streaming was never
    # fetched for this artist. Distinct from "fetched and nothing found"
    # ($resolved==0 with entries present), and the two must not be conflated:
    # the render EXEMPTS unmatched releases from hide_unmatched when streaming
    # is unresolved, which is right for "we asked and the services don't have
    # this artist" but wrong for "we haven't asked yet" — that just renders a
    # page the next visit contradicts (field, 2026-07-19: 85 unmatched releases
    # on the first view of Madness after an update, 0 on the second).
    my $seen = 0;
    for my $a (orderedAdapters()) {
        # An mbid-scoped pool is authoritative for THIS act; fall back to the
        # name-keyed one only when there is no mbid scope in play (ordinary
        # artists), never as a second chance for an ambiguous one — that is the
        # wrong act's catalogue by definition.
        my $rkey = _candKey($a->{name}, $artist, $mbid);
        my $c = $cache->get($rkey);
        # Logged so the READ key can be diffed against the keys clearCandidates
        # reports removing — the pair is the whole diagnosis when a clear does
        # not take effect.
        _dbg("peekPool read $rkey: " . ($c ? 'HIT' : 'miss'));
        $c or next;
        $seen++;
        # An entry cached as UNRESOLVED (no artist could be identified on this
        # service) must NOT count as "streaming was checked" — otherwise an
        # empty pool hides every release behind hide_unmatched.
        $resolved = 1 unless $c->{unresolved};
        my $items = _reattach($a, $c->{items});
        $bySvc{ $a->{name} } = $items;

        # First-token title index for this service's pool, built ONCE per render
        # (matchesFor runs per release group; without this it re-scanned the whole
        # pool each time). A candidate lands under every key its title yields.
        my %idx;
        for my $it (@$items) {
            push @{ $idx{$_} }, $it
                for _titleKeys(_norm($it->{_candTitle}), $artistNorm);
        }
        $index{ $a->{name} } = \%idx;
    }
    return { bySvc => \%bySvc, resolved => $resolved ? 1 : 0, index => \%index,
             cold => $seen ? 0 : 1 };
}

# What one service's cached pool says about the ARTIST it was built from, for
# the biography ladder (Browse::_bioStart). Cache only, read with the very key
# peekPool reads (the 0.43.2 read/write-parity rule). Returns undef when the
# service is not in use or has no pool cached (not asked yet, or the fetch is
# still out), else { unresolved => 0|1, meta => { id, name, score, spine, bio } }
# where meta is present only when the lookup settled on an artist (_searchQobuz).
sub peekPoolMeta {
    my ($class, $svc, $artist, $mbid) = @_;
    return undef unless $svc && ((defined $artist && length $artist) || $mbid);
    return undef unless grep { lc $_->{name} eq lc $svc } orderedAdapters();
    my $c = $cache->get(_candKey($svc, $artist, $mbid));
    return undef unless ref $c eq 'HASH';
    return { unresolved => $c->{unresolved} ? 1 : 0,
             (ref $c->{meta} eq 'HASH' ? (meta => $c->{meta}) : ()) };
}

# Cache-only variant for sync paths (list-tile badges): never searches, never
# needs a client. Returns { sections => [...], resolved => 0|1 } where
# `resolved` means STREAMING candidates were cached (a resolved no-match may
# hide the release). Local matches ride along but deliberately do NOT set
# `resolved` — owning some of an artist's albums must not hide the unowned
# ones before streaming has actually been checked.
#
# $pool is an optional peekPool() result: pass it when peeking many releases
# for one artist. matchesFor copies matched items before decorating them, so
# sharing the pool arrays across releases is safe.
sub peekMatches {
    my ($class, $artist, $albumTitle, $local, $pool, $rgMbid, $relMap, $rivals, $opt) = @_;
    return { sections => [], resolved => 0 }
        unless defined $artist && length $artist;

    $pool ||= $class->peekPool($artist, $opt->{mbid});
    return {
        sections => $class->matchesFor($pool->{bySvc}, $artist, $albumTitle, $local, $rgMbid, $relMap, $rivals, $opt),
        resolved => $pool->{resolved},
    };
}

# ---------------------------------------------------------------------------
# ListenLater favurl handshake (ported from PFR/LBF):
#   <scheme>://album:<nativeId>[?cover=<escaped art>][&a=<escaped artist>]
# XMLBrowser copies favorites_url into presetParams (Material's $FAVURL);
# without it the coderef url leaks as the favurl and ListenLater can't tell
# the service or replay the album.
# ---------------------------------------------------------------------------
sub _attachFavUrl {
    my ($it, $svc, $art, $artist) = @_;
    my $id = $it->{_albumid};
    return unless defined $id && length $id;

    my $fav = lc($svc) . '://album:' . $id;
    my @params;
    if (defined $art && !ref $art && length $art) {
        require URI::Escape;
        push @params, 'cover=' . URI::Escape::uri_escape_utf8($art);
    }
    if (defined $artist && !ref $artist && length $artist) {
        require URI::Escape;
        push @params, 'a=' . URI::Escape::uri_escape_utf8($artist);
    }
    $fav .= '?' . join('&', @params) if @params;
    $it->{favorites_url} = $fav;
}

# ---------------------------------------------------------------------------
# Per-service candidate fetch. Unlike PFR these do NOT filter by album — the
# full candidate list is cached and filtered per release group later. Each
# candidate carries: the native rendered node (playable), _svc, _albumid,
# _cover (native art), _candTitle/_candArtist (raw, for the matcher).
#
# ARTIST-FIRST (2026-07-10): album-search-by-artist-name is a relevance
# lottery — Qobuz caps catalog/search at 200 and 'sigur rós' left Valtari
# outside the top 200 while 193 fuzzy strangers made it in (Tidal/Deezer
# searches were capped at 50, same exposure). Each adapter now resolves the
# ARTIST on the service and pulls that artist's own album list — complete by
# construction. The old album search remains as the fallback when no artist
# resolves (stylised names, artists absent from the service).
# ---------------------------------------------------------------------------

# Best service artist for the query: normalised exact name wins, else the
# first (services rank by relevance) token-subset _artistMatch hit.
# ---------------------------------------------------------------------------
# SAME-NAME ARTIST RESOLUTION AGAINST THE MUSICBRAINZ SPINE
#
# THE BUG THIS EXISTS FOR (field, 0.43.0): browsing a SECONDARY same-name act
# showed an empty page. Diagnosed live — the MB spine was right and everything
# else was wrong:
#
#   topLevel: artist=Madness mbid=5d500d2e-...        (the horrorcore rapper)
#   match 'Open Corpse': NO MATCH | pool: Qobuz=158, Tidal=131, Local=7
#
# The release group is the rapper's; the candidate pool is the SKA BAND's,
# because getCandidates is keyed by artist NAME and _pickArtist picks the first
# exact-name hit — a coin toss when eight artists share the name. Nothing
# matched, hide_unmatched hid it, and the page read "No releases found". The
# matcher was never at fault: it was handed the wrong pool.
#
# THE FIX: when a name is ambiguous, pick the service artist whose CATALOGUE
# corroborates the release groups MusicBrainz already gave us. MB is an
# authoritative title list for THIS mbid, so overlap is a real test of identity
# rather than another name comparison.
#
# Bounded: only engages with a spine AND >1 same-name candidate, probes at most
# SPINE_ARTISTS per service, and the result is cached under the mbid. Ordinary
# artists never reach it and their cache entries are untouched.
#
# NO CORROBORATION = UNRESOLVED, NOT "no match". Settling as undef caches the
# short error TTL and leaves peekMatches' `resolved` false, so hide_unmatched
# does NOT hide the release: the user sees the real discography unplayable
# rather than an empty page. Falling back to the name-keyed album search would
# be worse than nothing — it returns the prominent act's records under the
# wrong artist's page.
# ---------------------------------------------------------------------------
use constant SPINE_ARTISTS => 4;

# HOW MUCH CORROBORATION IS ENOUGH TO STOP LOOKING (0.47.2).
#
# FIELD: browsing "Rossini" adopted a modern rapper on both Tidal and Deezer —
#     Tidal: 'Rossini' is ambiguous - 3637384=1, 51024775=0, 58712447=0, ...
# One title hit against a spine of several HUNDRED release groups is noise, but
# it beat zero and settled the matter. Measured proof a better answer existed,
# same mbid: under MB's canonical name "Gioachino Rossini" the RIGHT Tidal
# artist scores 3, and the page goes from Albums (3) to Albums (19).
#
# So a score below this bar is an answer to be HELD, not one to stop on: the
# resolver buys one more name and keeps whichever corroborates more. Below the
# bar and nothing better turns up, the held pick is returned unchanged — which
# is what keeps an artist whose service titles simply differ from MusicBrainz's
# spellings working exactly as it does today (the very case the verify path was
# deliberately not made the default for).
use constant SPINE_STRONG => 2;

# A weak pick is ALREADY an answer, so it buys exactly ONE more name to compare
# against — Browse puts MB's canonical name at the front of the alias list, and
# that is the rung with the evidence behind it. A total MISS still walks the
# full ALIAS_MAX list, as it always has: there, extra names are the only hope.
use constant WEAK_RETRY_MAX => 1;

sub _sameName {
    my ($query, $artists) = @_;
    my $qn = _norm($query);
    return () if $qn eq '';
    return grep { ref $_ eq 'HASH' && defined $_->{id}
                  && _norm($_->{name} // '') eq $qn } @{ $artists || [] };
}

sub _spineScore {
    my ($albums, $spine) = @_;
    my $hit = 0;
    my %seen;
    for my $al (@{ $albums || [] }) {
        next unless ref $al eq 'HASH';
        my $t = _norm($al->{title} // $al->{name} // '');
        next if $t eq '' || $seen{$t}++;
        $hit++ if $spine->{$t};
    }
    return $hit;
}

# An album whose OWN artist id differs from the one we asked for. Measured on
# the live Qobuz API (2026-07-18): getArtist(85999) returns 139 albums by 85999
# plus about twenty by eighteen OTHER artist ids - appears-on/related entries
# that Qobuz's own app does not show on the artist page. Left in, they pollute
# the candidate pool and (once unclaimed candidates are surfaced) would fill the
# streaming-extras section with other artists' records.
#
# SELF-GUARDING, and it must be: TIDAL's album payloads use a DIFFERENT id space
# from its artist ids - we ask for artist 9130 and not one album reports 9130 -
# so a naive "must equal the requested id" filter would delete TIDAL's entire
# discography. It therefore only engages once the requested id actually appears
# in the response, which proves the two are comparable. Albums carrying no
# artist id are always kept (Deezer sends none, and its endpoint is server-side
# scoped to the artist anyway).
sub _albumArtistId {
    my ($al) = @_;
    return undef unless ref $al eq 'HASH';
    my $a = $al->{artist} || ($al->{artists} && $al->{artists}[0]) || {};
    return (ref $a eq 'HASH' && defined $a->{id}) ? $a->{id} : undef;
}

sub _albumArtistName {
    my ($al) = @_;
    return '' unless ref $al eq 'HASH';
    my $a = $al->{artist} || ($al->{artists} && $al->{artists}[0]) || {};
    return (ref $a eq 'HASH' && defined $a->{name}) ? $a->{name}
         : (!ref $a && defined $a) ? $a : '';
}

# AN ARTIST NAMED AS A MAIN ARTIST, NOT FIRST (0.56.13; Simon: anything
# MusicBrainz lists under his own name "should come through", "across all the
# platforms we support"). Each service lists an album's artists its own way,
# read in its plugin's source:
#   Qobuz   `artists` [{id,name,roles}], "main-artist" in roles (Qobuz's own
#           Plugin.pm, _isMainArtist, makes exactly this test)
#   TIDAL   `artists` [{id,name,type}], type MAIN or FEATURED
#   Spotify `artists` [{id,name}] - every album artist is a main one
#   Deezer  an artist-albums item has no artist list at all (nothing to read;
#           its albums take the artist's own name, _renderAlbums' fallback)
# Only Qobuz is measured live (James Yorkston's "My Yoke Is Heavy", credited
# Adrian Crowley + James Yorkston); the other shapes are the sources' word.
sub _isMainCredit {
    my ($x) = @_;
    return 0 unless ref $x eq 'HASH';
    return scalar grep { ($_ // '') eq 'main-artist' } @{ $x->{roles} } if ref $x->{roles} eq 'ARRAY';
    return lc($x->{type}) eq 'main' ? 1 : 0 if defined $x->{type} && !ref $x->{type};
    return 1;
}

# The name an album credits $wantId under, when its artist list names that id as
# a main artist; else undef.
sub _mainArtistAs {
    my ($al, $wantId) = @_;
    return undef unless ref $al eq 'HASH' && ref $al->{artists} eq 'ARRAY' && defined $wantId;
    for my $x (@{ $al->{artists} }) {
        next unless ref $x eq 'HASH' && defined $x->{id} && $x->{id} eq $wantId && _isMainCredit($x);
        return (defined $x->{name} && length $x->{name}) ? $x->{name} : undef;
    }
    return undef;
}

# The same test BY NAME, for the render: when an album's artist list names the
# artist (the name the pool was fetched for) as a main artist, the album is
# credited to him rather than to whoever is listed first, so the matcher's
# artist gate sees his name. Covers a service whose album ids do not line up
# with its artist ids, which the id filter cannot judge (TIDAL, see
# _filterForeignArtist's self-guard). Not asked when the album's first-named
# artist already matches the name searched (_renderAlbums, 0.56.14).
sub _mainArtistNamed {
    my ($al, $want) = @_;
    return undef unless ref $al eq 'HASH' && ref $al->{artists} eq 'ARRAY';
    my $wn = _norm($want // '');
    return undef unless length $wn;
    for my $x (@{ $al->{artists} }) {
        next unless ref $x eq 'HASH' && defined $x->{name} && !ref $x->{name};
        next unless _norm($x->{name}) eq $wn && _isMainCredit($x);
        return $x->{name};
    }
    return undef;
}

sub _filterForeignArtist {
    my ($albums, $svc, $wantId, $wantName) = @_;
    return $albums unless defined $wantId && ref $albums eq 'ARRAY';

    my $mine = grep { my $a = _albumArtistId($_);
                      defined $a && $a eq $wantId } @$albums;
    return $albums unless $mine;          # id spaces differ - do not touch

    # A COLLABORATION is credited to a different entity and is still genuinely
    # this artist's record — "Panda Bear & Sonic Boom" carries the collab's
    # artist id, not Sonic Boom's, and dropping it would lose an album the MB
    # spine DOES list. So a differing id is forgiven when the credit still
    # names the artist; only credits that do not (his other band's records)
    # are dropped.
    # The forgiveness must be NARROW. An EXACTLY equal credit under a different
    # id is a DIFFERENT ACT WITH THE SAME NAME — the Madness problem again, and
    # 0.44.1's softening let those straight back in (field: Sonic Boom's page
    # listed "Bajo Tu Voz" and "El Mssiah" by another Sonic Boom). A genuine
    # collaboration reads as the artist PLUS someone else ("Panda Bear & Sonic
    # Boom"), i.e. strictly MORE tokens than the name alone. So: forgive a
    # differing id only when the credit CONTAINS the artist and is not merely
    # equal to it.
    my $wn = defined $wantName ? _norm($wantName) : '';
    # Partitioned in ONE pass so the dropped set is the exact complement of the
    # kept set by construction — recomputing it, or matching on ref addresses,
    # is how a diagnostic drifts from the decision it claims to explain.
    my (@keep, @lost);
    for my $al (@$albums) {
        my $a  = _albumArtistId($al);
        my $cn = _norm(_albumArtistName($al));
        if (!defined $a || $a eq $wantId
            || ($wn ne '' && $cn ne '' && $cn ne $wn && _artistMatch($wn, $cn))) {
            push @keep, $al;
        }
        elsif (defined(my $as = _mainArtistAs($al, $wantId))) {
            # NAMED AS A MAIN ARTIST, NOT FIRST (0.56.13; Simon, 2026-10-01:
            # anything MusicBrainz lists under his own name "should come
            # through"). Qobuz credits "My Yoke Is Heavy" to Adrian Crowley
            # AND James Yorkston, both main artists, and lists it on Yorkston's
            # own artist page; reading the first one alone dropped it here. A
            # copy credited to him (`_creditAs`, read by _renderAlbums), so the
            # matcher's artist gate sees his name; Qobuz's own test, read in
            # its Plugin.pm (_isMainArtist): the id AND the main-artist role.
            push @keep, { %$al, _creditAs => $as };
        }
        else { push @lost, $al }
    }
    my $n = scalar @lost;
    if ($n) {
        # NAMES THE DROPPED RECORDS, not just a count. A count cannot answer
        # "was this album ever returned by the service?" - and that is the only
        # question that matters when a release the user knows exists is missing
        # from the page (field, 2026-07-21: Layo & Bushwacka's Low Life / All
        # Night Long / Feels Closer / The Raw Road absent while Tidal dropped 8
        # albums here). It also distinguishes the two failure modes that look
        # identical on screen: a genuine foreign record (correctly dropped) vs
        # the SAME act filed by the service under a second artist id, whose
        # credit is exactly equal and is therefore dropped by the same-name
        # rule that exists to keep a DIFFERENT act out. Same lesson as the
        # 0.44.17 artist-search name list.
        _dbg("$svc/$wantId: dropped $n album(s) credited to other artist ids | "
            . join('; ', map {
                  ($_->{title} // $_->{name} // '?') . ' [credit '
                  . (_albumArtistName($_) || '?') . ' id '
                  . (defined _albumArtistId($_) ? _albumArtistId($_) : '-') . ']'
              } @lost[0 .. ($#lost > 7 ? 7 : $#lost)]));
    }
    return \@keep;
}

# How many MB aliases to retry under. Aliases are ordered as MB returns them;
# an artist with a long alias list is usually one whose primary name works.
use constant ALIAS_MAX => 3;

# $fetch->($artistId, sub { \@rawAlbums })
# $search->($name, sub { \@artists })   — re-runs the service's ARTIST search
# $cb->($artist, \@rawAlbums)  — $artist undef means "could not resolve".
#
# Wrapper: try the searched name, then MB's ALIASES. A rapper whose records are
# all sold as "Tony Madness" is not absent from the service — we were asking
# under the wrong name (field, 2026-07-19). Alias retries cost one extra artist
# search each and happen ONLY on the failure path.
sub _resolveArtist {
    my ($svc, $query, $artists, $spine, $fetch, $cb, $aliases, $search, $strict, $compare) = @_;

    # The strongest attempt so far. A WEAKLY corroborated pick is held here
    # rather than returned, so a better-corroborated name can displace it — and
    # is returned unchanged when none does. That fallback is the whole safety
    # argument: every artist that resolves today still resolves, to the same
    # service entity, unless something demonstrably corroborates better.
    my ($best, $held);
    my $keep = sub {
        my ($artist, $albums, $score) = @_;
        return unless $artist;
        $best = { artist => $artist, albums => $albums, score => $score }
            if !$best || ($score // 0) > ($best->{score} // 0);
    };
    # THE DUO'S OWN ENTRY, PASSED OVER FOR ONE OF ITS MEMBERS (0.56.14; Simon,
    # 2026-10-01, on Robert Plant & Alison Krauss: Qobuz files "Raising Sand"
    # under the duo, "the other one is listed as separate artists"). Searched
    # under the duo's name, Qobuz's duo entry backs up one title, so it is held
    # and the retry under "Robert Plant" wins with seven - and the duo's list,
    # the only one holding "Raising Sand", was dropped. Its albums (already
    # fetched to score it - no request added) now go back with the answer, for
    # _resolveWithJoints to add like a joint artist's: only ever matching a
    # release MusicBrainz lists on the page. Only when all of these hold, so the
    # held-pick rule's protection is untouched (a same-name act's one
    # coincidental title, 0.47.0's Rossini rapper, never comes back this way):
    #   - not a shared name ($strict: Madness, The Bees);
    #   - the held entry's name IS the name searched (MB's own name for the act);
    #   - that name is a joint credit (_creditParts gives its 2+ parts), and
    #   - the artist settled on is one of its parts.
    my $answer = sub {
        my ($artist, $albums) = @_;
        my $beside;
        if ($held && $artist && !$strict
            && ($held->{artist}{id} // '') ne ($artist->{id} // '')
            && _norm($held->{artist}{name} // '') eq _norm($query // '')) {
            my $an = _norm($artist->{name} // '');
            my @parts = _creditParts($held->{artist}{name});
            if (length $an && grep { _norm($_) eq $an } @parts) {
                $beside = [ $held->{artist}, $held->{albums} ];
                _dbg("$svc: '$held->{artist}{name}' passed over for '$artist->{name}'"
                    . ' - its own albums kept beside');
            }
        }
        $cb->($artist, $albums, $beside);
    };
    my $settle = sub {
        return $cb->(undef, undef) unless $best;
        _dbg("$svc: settling on '" . ($best->{artist}{name} // '?')
            . "' (" . ($best->{artist}{id} // '?') . ') with '
            . ($best->{score} // 0) . ' spine title(s) - nothing corroborated better');
        $answer->($best->{artist}, $best->{albums});
    };

    _resolveOne($svc, $query, $artists, $spine, $fetch, sub {
        my ($artist, $albums, $score) = @_;
        # BOTH NAMES, WHEN THE PAGE ASKS ($compare, 0.56.19). The query is
        # MusicBrainz's English name standing in for a name with no Latin letter
        # (Browse::_poolQuery) and the first alias is that name. A service may
        # file the act under BOTH, as two artists: measured on Qobuz (rig,
        # 2026-10-01), "王菲" holds 38 albums (25 matched) and "Faye Wong" 7 (4
        # matched, none in common), and 0.56.18, answering the English name at
        # once because 4 is strong, took the page from 25 Qobuz matches to 4.
        # So the other name is asked too, the better-corroborated artist wins
        # (a tie keeps the English one), and the other's albums go beside it,
        # as a passed-over duo entry's do, when it corroborates strongly in its
        # own right. One more search per service, for these pages only; a weak
        # English answer takes the walk below, which asks the other name next.
        if ($compare && $artist && defined $score && $score >= SPINE_STRONG
            && $search && @{ $aliases || [] }) {
            my $other = $aliases->[0];
            _dbg("$svc: '" . ($artist->{name} // '?') . "' corroborates $score spine title(s)"
                . " - also asking under '$other'");
            return $search->($other, sub {
                _resolveOne($svc, $other, shift, $spine, $fetch, sub {
                    my ($b, $bAlbums, $bScore) = @_;
                    return $cb->($artist, $albums)
                        unless $b && defined $bScore && ($b->{id} // '') ne ($artist->{id} // '');
                    my ($win, $lose) = ([ $artist, $albums, $score ], [ $b, $bAlbums, $bScore ]);
                    ($win, $lose) = ($lose, $win) if $bScore > $score;
                    my $beside = $lose->[2] >= SPINE_STRONG ? [ $lose->[0], $lose->[1] ] : undef;
                    _dbg("$svc: '" . ($win->[0]{name} // '?') . "' ($win->[2]) wins over '"
                        . ($lose->[0]{name} // '?') . "' ($lose->[2])"
                        . ($beside ? ' - its albums kept beside' : ''));
                    $cb->($win->[0], $win->[1], $beside);
                }, $strict);
            });
        }
        # Nothing to judge by (no spine), or a genuinely corroborated artist:
        # done, at exactly today's cost — no extra search, no extra fetch.
        return $cb->($artist, $albums)
            if $artist && (!defined $score || $score >= SPINE_STRONG);
        if ($artist) {
            _dbg("$svc: '" . ($artist->{name} // '?') . "' corroborates only "
                . ($score // 0) . ' spine title(s) - holding it and looking further');
            $held = { artist => $artist, albums => $albums };
        }
        $keep->($artist, $albums, $score);

        my @names = @{ $aliases || [] };
        # A HELD pick is already an answer, so it buys ONE more name. A total
        # miss still walks the full list.
        my $cap = $best ? WEAK_RETRY_MAX : ALIAS_MAX;
        splice @names, $cap if @names > $cap;
        return $settle->() unless @names && $search;

        # Self-passing closure, not a captured lexical — avoids the reference
        # cycle Perl never reclaims (the 0.30.1 leak fix).
        my $i = 0;
        my $step = sub {
            my ($self) = @_;
            my $alias = $names[$i++];
            return $settle->() unless defined $alias;
            _dbg("$svc: " . ($best ? "only weak corroboration under '$query'"
                                   : "nothing under '$query'")
                . " - retrying MB alias '$alias'");
            $search->($alias, sub {
                _resolveOne($svc, $alias, shift, $spine, $fetch, sub {
                    my ($a, $al, $sc) = @_;
                    return $answer->($a, $al) if $a && (!defined $sc || $sc >= SPINE_STRONG);
                    $keep->($a, $al, $sc);
                    $self->($self);
                }, $strict);
            });
        };
        $step->($step);
    }, $strict);
}

sub _resolveOne {
    my ($svc, $query, $artists, $spine, $fetch, $cb, $strict) = @_;

    my @same = _sameName($query, $artists);

    # $strict: the NAME is known to be shared by several MB artists, so a
    # single same-name hit on this service proves nothing - it is most likely
    # the PROMINENT act. Score it against the spine like any other candidate,
    # and if it does not corroborate, report unresolved so the caller can retry
    # under MB's aliases.
    #
    # THE BUG THIS EXISTS FOR (field, 2026-07-19): Qobuz returns exactly ONE
    # artist called "Madness", so the US rapper's page took the shortcut below,
    # adopted the ska band, reported SUCCESS - and the alias retry that would
    # have found "Tony Madness" never ran.
    #
    # Deliberately NOT the default: for an unambiguous artist a single name
    # match is the right answer, and demanding catalogue corroboration would
    # reject legitimate artists whose service titles are spelled differently
    # from MusicBrainz's.
    my $verify = $spine && %$spine && (@same > 1 || ($strict && @same));

    unless ($verify) {
        my $a = _pickArtist($query, $artists);
        return $cb->(undef, undef) unless $a;
        # SCORE THE PICK — free, because its albums are fetched either way, and
        # it is the only thing standing between a caller and an UNVERIFIED
        # name match. `_pickArtist` falls back to `_artistMatch`, a token
        # SUBSET test, so browsing "Shostakovich" adopts "Maxim Shostakovich"
        # (his son) or "Shostakovich Quartet" with nothing checked at all —
        # measured on Qobuz and Deezer, 2026-07-22. undef = no spine, i.e. no
        # opinion; the caller must not read that as a zero.
        return $fetch->($a->{id}, sub {
            my ($albums) = @_;
            $cb->($a, $albums,
                  ($spine && %$spine) ? _spineScore($albums, $spine) : undef);
        });
    }

    splice @same, SPINE_ARTISTS if @same > SPINE_ARTISTS;
    my $left = scalar @same;
    my @scored;
    # NB the loop variable is NOT $a: a lexical $a in scope MASKS sort's own
    # $a, so `sort { $b->{score} <=> $a->{score} }` would read `score` off the
    # service-artist hashref (always undef) instead of the element being
    # compared. That is not a sorted list - the top-scoring candidate need not
    # end up first, so the wrong service artist gets adopted, and when the
    # misordered head scores 0 the whole thing reports UNRESOLVED even though a
    # candidate corroborated. Silent: `perl -c` cannot see it and this file has
    # no `use warnings`, so the "uninitialized value" warning never fires.
    for my $cand (@same) {
        $fetch->($cand->{id}, sub {
            my ($albums) = @_;
            push @scored, { artist => $cand, albums => $albums,
                            score => _spineScore($albums, $spine) };
            return if --$left;

            @scored = sort { $b->{score} <=> $a->{score} } @scored;
            _dbg("$svc: '$query' is ambiguous - "
                . join(', ', map { $_->{artist}{id} . '=' . $_->{score} } @scored)
                . ' spine titles');

            unless ($scored[0]{score}) {
                _dbg("$svc: no candidate corroborates this artist's releases"
                    . ' - UNRESOLVED (releases stay visible, unmatched)');
                return $cb->(undef, undef);
            }
            $cb->($scored[0]{artist}, $scored[0]{albums}, $scored[0]{score});
        });
    }
}

sub _pickArtist {
    my ($query, $artists) = @_;
    my $qn = _norm($query);
    return undef if $qn eq '';
    my $fuzzy;
    for my $a (@{ $artists || [] }) {
        next unless ref $a eq 'HASH' && defined $a->{id};
        my $n = _norm($a->{name} // '');
        next if $n eq '';
        return $a if $n eq $qn;
        $fuzzy ||= $a if _artistMatch($qn, $n);
    }
    return $fuzzy;
}

# Candidate release year, off the RAW service album (the plugins' rendered items
# drop it). Field names verified in each plugin's source, ORIGINAL release date
# first — a remaster's stream date would point at the wrong release-group:
#   Qobuz  release_date_original -> release_date_stream -> year
#   TIDAL  releaseDate
#   Deezer release_date
# Any 4-digit leading year wins; nothing sane -> undef (caller must cope).
sub _candYear {
    my ($album) = @_;
    for my $f (qw(release_date_original releaseDate release_date release_date_stream year date)) {
        my $v = $album->{$f};
        next unless defined $v && !ref $v;
        return $1 if $v =~ /^(\d{4})/;
    }
    return undef;
}

# What KIND of release a streaming copy is: 'album', 'ep', 'single' or undef
# (unknown). Judged as the Qobuz plugin judges its own artist pages (Plugin.pm,
# the artist/get album list we fetch too): 30+ minutes or more than 6 tracks is
# an album, under 4 tracks a single, anything between an EP. Counts first
# (Qobuz tracks_count, Tidal numberOfTracks, Deezer nb_tracks, all durations in
# seconds); a stated type only when there are no counts (Tidal `type`, Deezer
# `record_type`). Qobuz's own `release_type` is deliberately NOT read — its
# plugin overrides it with the counts, and 0.46.8 found it unreliable.
# THE ALBUM-SEARCH FALLBACK IS SIZED THE SAME WAY (corrected at the 0.51.13
# review; this comment used to claim search payloads carry nothing). Verified
# live: Deezer /search/album returns `nb_tracks` + `record_type`, and Qobuz
# search items carry `tracks_count`/`duration`, so a searched candidate is
# gated like any other. Only a payload with neither counts nor a type stays
# unknown, and an unknown size matches exactly as before. NB Deezer's `type`
# field is the ENTITY type ("album" for every row) — `record_type` is the one
# that means anything, and it is read only when there are no counts.
sub _candSize {
    my ($album) = @_;
    return undef unless ref $album eq 'HASH';
    my ($tracks) = grep { defined && !ref && /^\d+$/ }
                   map { $album->{$_} } qw(tracks_count numberOfTracks nb_tracks);
    my $dur = $album->{duration};
    $dur = undef unless defined $dur && !ref $dur && $dur =~ /^\d+(?:\.\d+)?$/;
    return _sizeFromCounts($tracks, $dur) if $tracks;
    my $type = lc($album->{record_type} // $album->{type} // '');
    return 'album'  if $type eq 'album' || $type eq 'compile';
    return 'ep'     if $type eq 'ep';
    return 'single' if $type eq 'single';
    return undef;
}

sub _sizeFromCounts {
    my ($tracks, $dur) = @_;
    return 'album'  if ($dur && $dur >= 1800) || $tracks > 6;
    return 'single' if $tracks < 4;
    return 'ep';
}

# A LIBRARY copy's size, worked out only when it matters (a copy title-matching
# a MusicBrainz Single) and remembered on the item. A RELEASETYPE tag of
# SINGLE/EP decides; LMS reads ALBUM for every untagged file (2,882 of Simon's
# 2,931), so ALBUM proves nothing and the tracks decide instead.
sub _localSize {
    my ($it) = @_;
    return $it->{_size} if exists $it->{_size};
    my $tag = uc($it->{_reltype} // '');
    return $it->{_size} = 'single' if $tag eq 'SINGLE';
    return $it->{_size} = 'ep'     if $tag eq 'EP';
    my $size;
    if (my $al = $it->{_albumid}) {
        my $r = eval {
            Slim::Control::Request::executeRequest(undef,
                ['titles', 0, 500, "album_id:$al", 'tags:d']);
        };
        my $loop = $r ? ($r->getResult('titles_loop') || []) : [];
        my $dur = 0;
        $dur += ($_->{duration} || 0) for @$loop;
        $size = _sizeFromCounts(scalar @$loop, $dur) if @$loop;
    }
    return $it->{_size} = $size;
}

# ===========================================================================
# THE TRACK MATCH (0.56.61; Simon, 2026-10-08). An owned album no group claims
# by title, id, alias or edition title - "Also in your library" - is put on the
# ONE group whose tracklist it carries. A tester's "McCoy Tyner Plays John
# Coltrane" missed MusicBrainz's "McCoy Tyner plays John Coltrane: Live at the
# Village Vanguard": the title rules only let the OWNED side be longer. Simon:
# match some of the name, then the track count and names; and "base it on a
# weighting match"; when it cannot work out which, a manual match (Browse,
# the release page's "Match an album from your library").
#
# MEASURED BEFORE IT WAS BUILT (CLAUDE.md, the 11 real matcher gaps, the
# 2026-10-08 replay; tools/leftover/): 7 matched in Simon's library + the
# tester's, all right; with every matched album's real group HIDDEN (1,193 with
# a candidate left) the first rule took 166 wrong groups - two-album sets
# ("Raintown / When the World Knows Your Name": all its tracks there) and
# live / demo versions ListenBrainz has no running times for - this one 6,
# each MusicBrainz holding the same or an overlapping tracklist twice. So:
#   - candidates: groups sharing a title WORD (the artist's words and
#     the/a/an/of/and/s aside), the 5 with the most title evidence;
#   - the tracks decide, both ways: your tracks found on the group's list
#     >= 0.65 (your copy may carry bonus tracks), the group's in your copy
#     >= 0.9 (the group may not: a two-album set, an album + EP);
#   - running times KNOWN for >= 80% of the paired tracks, and >= 80% of
#     those within max(4 s, 4%) (a live or demo version fails here);
#   - score 0.7 x tracks + 0.3 x title x _titleWeight; the best passing group
#     must reach 0.75 AND lead every other passing one by 0.1, or nothing is
#     matched ("a tie decides nothing", as the resolver's weighting).
# DSC-ONLY call-site logic: the shared matcher subs are untouched.
# ===========================================================================
use constant TRK_SHORTLIST => 5;
use constant TRK_FOUND_MIN => 0.65;
use constant TRK_COVER_MIN => 0.9;
use constant TRK_TIMED_MIN => 0.8;
use constant TRK_DUR_MIN   => 0.8;
use constant TRK_SCORE_MIN => 0.75;
use constant TRK_MARGIN    => 0.1;

my %TRK_STOP = map { $_ => 1 } qw(the a an of and s);
sub _trkToks { grep { length && !$TRK_STOP{$_} } split / /, ($_[0] // '') }

# Title evidence, 0..1, for an owned title against one group title (both
# _norm'd): 0.75 x the share of the owned title's words found + 0.25 x the
# share of the group title's. The artist's own words are set aside on each
# side unless nothing else is left. 0 = no word shared.
sub _trkTitle {
    my ($o, $g, $an) = @_;
    my %art = map { $_ => 1 } _trkToks($an);
    my @a = grep { !$art{$_} } _trkToks($o); @a = _trkToks($o) unless @a;
    my @b = grep { !$art{$_} } _trkToks($g); @b = _trkToks($g) unless @b;
    return 0 unless @a && @b;
    my %as = map { $_ => 1 } @a;
    my %bs = map { $_ => 1 } @b;
    my $common = grep { $bs{$_} } keys %as;
    return 0 unless $common;
    return 0.75 * $common / keys(%as) + 0.25 * $common / keys(%bs);
}

# The groups an owned title could be: [ { rg, tscore }, ... ], best first, at
# most TRK_SHORTLIST. A group is judged by its title, its aliases and its
# edition titles ($editions: Browse::_editionTitles' { rg => [[norm, raw, ...]] }),
# whichever says most.
sub trackShortlist {
    my ($class, $title, $artist, $groups, $editions) = @_;
    my $o  = _norm($title // '');
    my $an = _norm($artist // '');
    return () unless length $o;
    my @c;
    for my $rg (@{ $groups || [] }) {
        my $best = 0;
        for my $g (_norm($rg->{title} // ''), map({ _norm($_) } @{ $rg->{aliases} || [] }),
                   map({ $_->[0] } @{ ($editions || {})->{ $rg->{mbid} } || [] })) {
            next unless length $g;
            my $t = _trkTitle($o, $g, $an);
            $best = $t if $t > $best;
        }
        push @c, { rg => $rg, tscore => $best } if $best > 0;
    }
    @c = sort { $b->{tscore} <=> $a->{tscore} || ($a->{rg}{mbid} // '') cmp ($b->{rg}{mbid} // '') } @c;
    splice @c, TRK_SHORTLIST if @c > TRK_SHORTLIST;
    return @c;
}

# A track title as both sides are compared: _norm (brackets go), after a
# trailing " - Remastered 2009" / " - Live" style qualifier is dropped.
my $TRK_TAIL = qr/remaster|version|mix|edit|mono|stereo|live|demo|take|single|bonus|acoustic|instrumental|session/i;
sub _trkNorm {
    my $t = shift // '';
    $t =~ s/\s+[-\x{2013}\x{2014}]\s+.*$// if $t =~ /\s[-\x{2013}\x{2014}]\s+.*$TRK_TAIL/;
    return _norm($t);
}

# Evidence from two tracklists, each [ [title, seconds], ... ]: { found (share
# of OWN tracks on the group's list), cover (share of the GROUP's in the owned
# copy), m (pairs), timed (pairs with both times), dur (share of the timed
# pairs within max(4 s, 4%); undef with none) }. One-to-one, in list order: an
# exact title first, else one title that is the other plus words.
sub trackEvidence {
    my ($class, $own, $grp) = @_;
    my @o = map { [ _trkNorm($_->[0]), $_->[1] || 0 ] } @{ $own || [] };
    my @g = map { [ _trkNorm($_->[0]), $_->[1] || 0 ] } @{ $grp || [] };
    my (%used, @pairs);
    for my $x (@o) {
        next unless length $x->[0];
        my ($hit) = grep { !$used{$_} && $g[$_][0] eq $x->[0] } 0 .. $#g;
        ($hit) = grep { !$used{$_} && length $g[$_][0]
                        && (index($g[$_][0], "$x->[0] ") == 0 || index($x->[0], "$g[$_][0] ") == 0) } 0 .. $#g
            unless defined $hit;
        next unless defined $hit;
        $used{$hit} = 1;
        push @pairs, [ $x->[1], $g[$hit][1] ];
    }
    my @timed = grep { $_->[0] > 0 && $_->[1] > 0 } @pairs;
    my $close = grep { my $tol = 0.04 * $_->[1]; $tol = 4 if $tol < 4; abs($_->[0] - $_->[1]) <= $tol } @timed;
    return { found => @o ? @pairs / @o : 0, cover => @g ? @pairs / @g : 0,
             m => scalar @pairs, timed => scalar @timed, dur => @timed ? $close / @timed : undef };
}

# Score one candidate ({ tscore, ev }) with the owned title's weight: sets
# `agree` (the tracks pass) and `score`, and returns the candidate.
sub _trkScore {
    my ($c, $w) = @_;
    my $e = $c->{ev};
    unless ($e) { @$c{qw(agree score)} = (0, 0); return $c }
    my $dur = $e->{dur} // 0;
    $c->{agree} = ($e->{found} >= TRK_FOUND_MIN && $e->{cover} >= TRK_COVER_MIN
                   && $e->{m} && $e->{timed} >= TRK_TIMED_MIN * $e->{m} && $dur >= TRK_DUR_MIN) ? 1 : 0;
    $c->{score} = 0.7 * (2 * $e->{found} + $e->{cover}) / 3 * (0.5 + 0.5 * $dur)
                + 0.3 * $c->{tscore} * $w;
    return $c;
}

# The decision for one owned album: (the winning candidate or undef, the
# candidates best first). Each candidate carries { rg, tscore, ev } (ev undef
# when the group has no tracklist); $title/$artist give the title weight.
sub trackPick {
    my ($class, $cands, $title, $artist) = @_;
    my $w = _titleWeight($title, $artist);
    my @r = sort { $b->{score} <=> $a->{score} || ($a->{rg}{mbid} // '') cmp ($b->{rg}{mbid} // '') }
            map { _trkScore($_, $w) } @{ $cands || [] };
    my @pass = grep { $_->{agree} } @r;
    my $win = (@pass && $pass[0]{score} >= TRK_SCORE_MIN
               && (@pass == 1 || $pass[0]{score} - $pass[1]{score} >= TRK_MARGIN)) ? $pass[0] : undef;
    return ($win, \@r);
}

# An owned album's tracks, [ [title, seconds], ... ] in disc/track order, read
# once and kept on the item (a per-call copy, never a cached entry: localAlbums
# builds its items fresh, as _localSize relies on too).
sub ownTracks {
    my ($class, $it) = @_;
    return $it->{_tracks} if $it->{_tracks};
    my @t;
    if (my $al = $it->{_albumid}) {
        my $r = eval {
            Slim::Control::Request::executeRequest(undef,
                ['titles', 0, 500, "album_id:$al", 'tags:dti', 'sort:tracknum']);
        };
        @t = map { [ $_->{title} // '', $_->{duration} || 0 ] }
             sort { ($a->{disc} || 1) <=> ($b->{disc} || 1) || ($a->{tracknum} || 0) <=> ($b->{tracknum} || 0) }
             @{ $r ? ($r->getResult('titles_loop') || []) : [] };
    }
    return $it->{_tracks} = \@t;
}

# An owned album as the `manual` table keys it (DB.pm): its title and album
# artist, lower-cased and trimmed - not LMS's album id, which a rescan renumbers.
sub albumKey {
    my ($it) = @_;
    my ($t, $a) = map { my $v = lc($_ // ''); $v =~ s/^\s+|\s+$//g; $v } $it->{_candTitle}, $it->{_candArtist};
    return length $t ? "$t\x{1f}$a" : undef;
}

sub _decorate {
    my ($item, $svc, $album, $candArtist) = @_;
    $item->{_size}       = _candSize($album);
    $item->{_svc}        = $svc;
    $item->{_albumid}    = $album->{id};
    $item->{_cover}      = $item->{image} if defined $item->{image} && !ref $item->{image};
    $item->{_candTitle}  = $album->{title};
    $item->{_candArtist} = $candArtist;
    $item->{_year}       = _candYear($album);
    _addVersion($item, $album);
    # Qobuz search albums sometimes carry an editorial description — kept as a
    # review fallback for the detail page (MAI wins when it has one).
    $item->{_desc}       = $album->{description}
        if defined $album->{description} && !ref $album->{description} && length $album->{description};
}

# THE SERVICE'S OWN EDITION NAME ON ITS ROW (0.56.51; Simon, 2026-10-07). Qobuz
# album objects carry `version` ("Expanded Edition", "Remastered"), which the
# Qobuz plugin shows for tracks only; with every copy now listed (matchesFor),
# three 1964 "Getz/Gilberto" rows would otherwise read the same. Appended to
# line1, the title Material shows, right after the title (before the plugin's
# own " (Hi-Res)" or " [E]"), unless the title already says it, so a plugin that
# starts showing it does not double it. "Says it" is every WORD of the version,
# in any order (Simon, 2026-10-07: Qobuz's "Radio-Activity (2009 Digital
# Remaster)" with version "2009 Remaster" read the edition twice). Any service
# whose album carries the field gets it; Tidal's plugin and Deezer's do not read one, and a copy with
# none is unchanged. Display only: matching reads `_candTitle`, the raw title.
sub _addVersion {
    my ($item, $album) = @_;
    my $v = ref $album eq 'HASH' ? $album->{version} : undef;
    return unless defined $v && !ref $v;
    $v =~ s/^\s+|\s+$//g;
    return unless length $v;
    my $l1 = $item->{line1};
    return unless defined $l1 && !ref $l1 && length $l1;
    my %have = map { $_ => 1 } (lc $l1) =~ /(\w+)/g;
    my @want = (lc $v) =~ /(\w+)/g;
    return if !grep { !$have{$_} } @want;
    my $t = $album->{title};
    if (defined $t && !ref $t && length $t && index($l1, $t) == 0) {
        $item->{line1} = $t . " ($v)" . substr($l1, length $t);
    }
    else {
        $item->{line1} = "$l1 ($v)";
    }
    return;
}

# Normalise a fetch result to an arrayref of albums, or undef.
#
# VERIFIED against the plugin sources (2026-07-10): all three unwrap their own
# JSON envelope and hand us a plain ARRAY — Deezer Async.pm `artistAlbums`/
# `search` both do `shift->{data}` then `$cb->($albums || [])`; TIDAL Async.pm
# `artistAlbums` does `$cb->($albums || [])`. The exception is Qobuz, whose
# callback carries the whole result hash, so we reach into `{albums}{items}`
# ourselves. This helper keeps that reach in ONE place and tolerates an
# envelope if a plugin ever stops unwrapping (the old Deezer search leg carried
# a `{data}` unwrap that could no longer fire).
#
# undef means "not a list at all" — the callers treat that as a failed fetch
# (short retry TTL), never as a genuinely empty discography.
sub _albumArray {
    my ($x) = @_;
    return $x if ref $x eq 'ARRAY';
    if (ref $x eq 'HASH') {
        for my $k (qw(data items albums)) {
            return $x->{$k} if ref $x->{$k} eq 'ARRAY';
        }
    }
    return undef;
}

# ONE render loop for every adapter. $render is the service plugin's own node
# renderer (guarded — a die here is inside an async callback); $skip optionally
# drops entries before rendering.
#
# _candArtist feeds the matcher's MANDATORY artist gate, so it must never come
# out undef: an artist-album payload may carry {artist} with a name, only an
# {artists} list, or no artist at all (Deezer's /artist/N/albums), and Deezer's
# own renderer autovivifies an empty {artist} as a side effect. Hence the
# ladder ending in $artistName (the name the artist-first fetch resolved) and
# then ''. Computed BEFORE $render runs, so a renderer's autovivification can't
# poison it.
#
# Returns undef — meaning ERROR, cache briefly and retry — only when the
# renderer failed for EVERY album. An empty arrayref means the list really was
# empty, which the callers distinguish.
#
# $query: the name the services were searched under. An album whose FIRST-named
# artist already matches it keeps that credit, and is not re-credited by
# _mainArtistNamed to the service artist the lookup settled on (0.56.14). Field,
# 2026-10-01: TIDAL has no "Robert Plant & Alison Krauss", so the duo's page
# settled on Alison Krauss, whose list holds the duo's records credited Robert
# Plant first; re-credited to her, none passed the page's "Robert Plant" gate,
# and the whole page matched nothing on TIDAL. The second-main-artist case
# (James Yorkston's "My Yoke Is Heavy", Adrian Crowley first) is unchanged: its
# first-named artist is not the one searched.
sub _renderAlbums {
    my ($albums, $svc, $artistName, $render, $skip, $query) = @_;
    my @out;
    my $rendererFailed = 0;
    my $qn = _norm($query // '');
    for my $album (@{ $albums || [] }) {
        next unless ref $album eq 'HASH' && defined $album->{id};
        next if $skip && $skip->($album);
        my $ref = $album->{artist} || ($album->{artists} && $album->{artists}[0]) || {};
        my $first = (ref $ref eq 'HASH' && $ref->{name}) ? $ref->{name} : '';
        my $firstIsHim = length $qn && $first ne '' && !ref $first && _artistMatch($qn, _norm($first));
        my $candArtist = $album->{_creditAs}
                      || ($firstIsHim ? undef : _mainArtistNamed($album, $artistName))
                      || $first || $artistName || '';
        my $item = eval { $render->($album) };
        if ($@ || ref $item ne 'HASH') {
            $log->warn("$svc renderer failed: $@") if $@;
            $rendererFailed = 1;
            next;
        }
        _decorate($item, $svc, $album, $candArtist);
        push @out, $item;
    }
    return undef if !@out && $rendererFailed;
    return \@out;
}

# Joint artists fetched beside an artist on Qobuz (_jointArtists), and how long
# the artist's own answer waits for them. Declared before first use (a
# `use constant` below its caller is a strict-subs error).
use constant JOINT_MAX  => 3;
use constant JOINT_WAIT => 3;    # seconds past the artist's own answer

sub _searchQobuz {
    my ($client, $query, $svc, $collect, $spine, $aliases, $strict, $compare, $leaders) = @_;

    my $api = Plugins::Qobuz::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }

    # THE BIOGRAPHY RIDES IN THE SAME REPLY (the biography ladder, 2026-10-08;
    # Browse::_bioStart). Qobuz's artist/get carries `biography.content`, the
    # text the Qobuz plugin's own artist menu shows, and every candidate the
    # resolver fetches comes through here, so it costs no request. Kept per
    # artist id for this lookup; only the artist settled on is passed on.
    my %bio;
    my $fetch = sub {
        my ($id, $done) = @_;
        $api->getArtist(sub {
            my $r = shift;
            if (ref $r eq 'HASH' && ref $r->{biography} eq 'HASH') {
                my $t = $r->{biography}{content};
                $bio{$id} = $t if defined $t && !ref $t && $t =~ /\S/;
            }
            # The plugin's getArtist stops at 200 albums; the rest are asked
            # for here (_qobuzMoreAlbums), or not at all if it cannot be.
            _qobuzMoreAlbums($api, $id, $r, _albumArray(ref $r eq 'HASH' ? $r->{albums} : undef), sub {
                # Filtered BEFORE scoring as well as rendering: a foreign album
                # must not contribute to a candidate's spine score either.
                $done->(_filterForeignArtist($_[0], 'Qobuz', $id, $query));
            });
        }, $id);
    };

    my $search = sub {
        my ($name, $done) = @_;
        $api->search(sub {
            my $r = shift;
            $done->($r && $r->{artists} && $r->{artists}{items});
        }, lc($name), 'artists');
    };

    $api->search(sub {
        my $res = shift;
        _resolveWithJoints('Qobuz', $query, $res && $res->{artists} && $res->{artists}{items},
            $spine, $fetch, $aliases, $search, $strict, $compare, sub {
                my ($artist, $albums, $extra) = @_;
                unless ($artist) {
                    # With a spine, an unresolved artist is DELIBERATE (nothing
                    # corroborated) and the album-search fallback would pull the
                    # prominent same-named act — settle unresolved instead. Unless
                    # the band's LEADER came back (_resolveWithJoints): the service
                    # files the band under him, and his albums are the pool, to
                    # match the band's own releases only (_leaderOnly).
                    if ($spine && %$spine) {
                        return $collect->(_leaderOnly('Qobuz', $query, $extra, sub { _renderQobuzAlbums($client, $_[0], $svc, $_[1]) }));
                    }
                    _dbg("Qobuz: no artist hit for '$query' - album-search fallback");
                    return _qobuzAlbumSearch($api, $client, $query, $svc, $collect);
                }
                # A resolved artist with a raw-empty album list is a failed fetch
                # far more often than a zero-album artist — settle as error (short
                # retry), never a 1-day empty pin.
                return $collect->(undef) unless $albums && @$albums;
                # THE ARTIST SETTLED ON, for the biography ladder: who it is, how
                # many of the page's releases its own albums matched, and its
                # biography. Only this artist: never a joint or passed-over entry
                # ($extra), and nothing on the leader-only, album-search or
                # unresolved paths above. Kept with the pool (getCandidates).
                my $sp = ref $spine eq 'HASH' ? $spine : {};
                my $meta = { id => $artist->{id}, name => $artist->{name},
                             score => _spineScore($albums, $sp), spine => scalar(keys %$sp),
                             (defined $bio{ $artist->{id} // '' } ? (bio => $bio{ $artist->{id} }) : ()) };
                $collect->(_appendJoint('Qobuz', $query, $artist->{name},
                    _renderQobuzAlbums($client, $albums, $svc, $artist->{name}, $query), $extra,
                    sub { _renderQobuzAlbums($client, $_[0], $svc, $_[1]) }), $meta);
            }, $leaders);
    }, lc($query), 'artists');
}

# A QOBUZ ARTIST PAST THE PLUGIN'S 200 ALBUMS (0.56.54; Simon, 2026-10-07, Stan
# Getz: a fourth Qobuz copy of Getz/Gilberto sat past the 200th album; the Qobuz
# plugin's developer: "the API function artist/get ... is called with 'extra' =
# 'albums' and a 'limit' of 200 ... the maximum permitted limit is 500", more
# only through the catalog search). The plugin's getArtist fixes that limit and
# passes no offset, so the rest are asked for here through its own handler, the
# way the plugin asks (`_get`: its token, app id, cache and timeout), and put
# through the plugin's own `_precacheAlbum` (an exported function: drops what
# cannot be played, flattens genre and image) so a row is the same shape as one
# from getArtist.
#
# API manners: only when the first answer says there is more (`albums.total`),
# never blind; pages of 500, the largest limit the API allows; ONE request at a
# time, never in parallel; at most QOBUZ_ARTIST_MAX albums (a few requests) per
# artist, once per pool fetch (the pool is kept CAND_FOUND_TTL). The Qobuz
# plugin caches each page itself (its _ttl, set here to a day). The per-service
# watchdog (SVC_TIMEOUT) would throw away the WHOLE Qobuz pool, so the extra
# pages have a shorter deadline of their own and give up with what they have.
#
# Anything missing or failing leaves the 200 getArtist gave, as before: no
# handler `_get`, no `_precacheAlbum`, no `total`, an empty or failed page, the
# deadline. Verified live 2026-10-07: Qobuz honours `offset` on artist/get and
# sends `total`. Added time on a COLD open (logged, "the extra pages took"):
# 0.9 s for 806 albums, 1.4 s for 1023, 2.3 s for 1905 cut at 1500 - hence the
# 1000 cap (two extra requests at most).
use constant QOBUZ_PAGE_MAX     => 500;    # artist/get's largest limit (the plugin's QOBUZ_LIMIT)
use constant QOBUZ_FIRST_PAGE   => 200;    # the plugin's QOBUZ_DEFAULT_LIMIT, when the answer does not say
use constant QOBUZ_ARTIST_MAX   => 1000;   # albums read for one artist (Simon, 2026-10-07: 1500 cost Miles Davis 2.3 s; "cap at 1000")
use constant QOBUZ_PAGE_BUDGET  => 10;     # seconds the extra pages may take

sub _qobuzMoreAlbums {
    my ($api, $id, $r, $albums, $done) = @_;

    my $block = ref $r eq 'HASH' && ref $r->{albums} eq 'HASH' ? $r->{albums} : {};
    my $total = $block->{total};
    my $have  = ref $albums eq 'ARRAY' ? scalar @$albums : 0;
    my $first = $block->{limit};
    $first = QOBUZ_FIRST_PAGE unless defined $first && !ref $first && $first =~ /^\d+$/ && $first > 0;
    my $next  = (defined $block->{offset} && !ref $block->{offset} && $block->{offset} =~ /^\d+$/
                 ? $block->{offset} : 0) + $first;

    my $precache = Plugins::Qobuz::API::Common->can('_precacheAlbum');
    if (!defined $total || ref $total || $total !~ /^\d+$/) {
        _dbg("Qobuz artist $id: $have albums, the answer carries no total - not paging") if $have >= $first;
        return $done->($albums);
    }
    if ($total <= $next) {
        _dbg("Qobuz artist $id: $have albums of $total - complete");
        return $done->($albums);
    }
    unless ($api->can('_get') && $precache && ref $albums eq 'ARRAY') {
        _dbg("Qobuz artist $id: $have albums of $total - paging unavailable (handler _get or _precacheAlbum missing)");
        return $done->($albums);
    }

    my $want = $total > QOBUZ_ARTIST_MAX ? QOBUZ_ARTIST_MAX : $total;
    _dbg("Qobuz artist $id: $have albums of $total - asking for the rest"
        . ($want < $total ? " (cut at $want)" : '') . ", pages of " . QOBUZ_PAGE_MAX);

    my @all  = @$albums;
    my %seen = map { (defined $_->{id} ? $_->{id} : '') => 1 } grep { ref $_ eq 'HASH' } @all;
    my ($settled, $timer, $step);
    my $t0 = Time::HiRes::time();
    my $finish = sub {
        my ($why) = @_;
        return if $settled++;
        Slim::Utils::Timers::killSpecific($timer) if $timer;
        undef $step;    # the closure holds itself
        # The time the extra pages added to this fetch, in the log: Simon, 2026-10-07,
        # "Dont want added time as some is slow enough already".
        _dbg("Qobuz artist $id: " . scalar(@all) . " albums read ($why), the extra pages took "
            . sprintf('%.1f', Time::HiRes::time() - $t0) . ' s');
        $done->(\@all);
    };
    $timer = Slim::Utils::Timers::setTimer(undef, time() + QOBUZ_PAGE_BUDGET, sub {
        $timer = undef;
        $finish->('deadline - what had arrived is used');
    });
    $step = sub {
        return $finish->('all read') if $next >= $want;
        my $at = $next;
        $api->_get('artist/get', sub {
            return if $settled;
            my $res   = shift;
            my $items = ref $res eq 'HASH' && ref $res->{albums} eq 'HASH' ? $res->{albums}{items} : undef;
            unless (ref $items eq 'ARRAY' && @$items) {
                return $finish->("the page at offset $at gave nothing");
            }
            my $raw = scalar @$items;
            my $kept = eval { $precache->($items) };
            $kept = [] unless ref $kept eq 'ARRAY';
            for my $al (@$kept) {
                next unless ref $al eq 'HASH';
                next if defined $al->{id} && $seen{ $al->{id} }++;
                push @all, $al;
            }
            _dbg("Qobuz artist $id: offset $at gave $raw albums, " . scalar(@$kept) . " playable");
            $next = $at + $raw;
            $step->() if $step;
        }, { artist_id => $id, extra => 'albums', offset => $at, _ttl => 86400,
             limit => ($want - $at < QOBUZ_PAGE_MAX ? $want - $at : QOBUZ_PAGE_MAX) });
    };
    $step->();
}

# The joint artists a service's artist search returned for $name: entries whose
# name is a joint credit (_creditParts, the one definition of one) naming $name
# as one of its acts. At most JOINT_MAX, in the service's order.
sub _jointArtists {
    my ($items, $name) = @_;
    my $want = _norm($name // '');
    return () unless length $want && ref $items eq 'ARRAY';
    my @out;
    for my $a (@$items) {
        next unless ref $a eq 'HASH' && defined $a->{id} && defined $a->{name};
        my @parts = _creditParts($a->{name});
        next unless @parts >= 2 && grep { _norm($_) eq $want } @parts;
        push @out, $a;
        last if @out >= JOINT_MAX;
    }
    return @out;
}

# JOINT ARTISTS, EVERY SERVICE (0.56.13; Simon, 2026-10-01: albums MusicBrainz
# lists under the artist's own name "should come through", and if it lists them
# under a separate artist "we live with it"; then "should be across all the
# platforms we support"). A service files some of an artist's records under a
# JOINT artist entity of its own - Qobuz's "James Yorkston & The Big Eyes Family
# Players" holds his "Folk Songs" - and the artist's own entry does not list
# them. The search that finds the artist returns those joint entries too
# (_jointArtists), so their albums are fetched beside it, at the same time, with
# the adapter's own $fetch, and handed back for the adapter to render
# (_appendJoint). They only ever MATCH a release MusicBrainz lists on the page
# and never show as "Also on streaming" extras (Browse skips `_joint`).
#
# Same contract as _resolveArtist, whose arguments it takes, plus $done gets the
# joint albums as a third argument (each a copy tagged `_jointOf`, its joint
# artist's name; already on the artist's own list -> left out). A duo's own
# entry that _resolveArtist passed over for one of its members joins them
# (0.56.14), with no request of its own. Nothing joint is
# handed back when the artist itself was not identified. The artist's own answer
# waits at most JOINT_WAIT for joint lookups still out: they are an addition,
# and one that never answered would otherwise hold the whole pool until the
# service watchdog marked it failed. Measured on Qobuz (James Yorkston: one
# joint artist, one extra request); the other three services' shapes are read
# in their plugins' sources, not yet measured live.
sub _resolveWithJoints {
    my ($svc, $query, $items, $spine, $fetch, $aliases, $search, $strict, $compare, $done, $leaders) = @_;
    my @joint = _jointArtists($items, $query);
    my ($main, @got, @lead, $finished, $waitTimer);
    # THE BAND'S LEADER (2026-10-08, The Oscar Peterson Trio; API::peekEponymous):
    # the service entity named EXACTLY as the member MusicBrainz says the band is
    # named after, found among the band's own search hits, else by one search of
    # his name, run beside the band's lookup. His albums join as a joint artist's
    # do (match-only, never extras), and ALSO when the band has no entity of its
    # own here (the adapters' _leaderOnly): that is the case it exists for.
    my $wantN = _norm($query // '');
    my %seenL;
    my @want = grep { my $n = _norm($_ // ''); length $n && $n ne $wantN && !$seenL{$n}++ }
               @{ ref $leaders eq 'ARRAY' ? $leaders : [] };
    my %fetching = map { (($_->{id} // '') => 1) } @joint;
    my $left = scalar(@joint) + scalar(@want);
    # ONE FETCH PER SERVICE ARTIST in this lookup: when the band's search hits
    # hold only its leader, _resolveArtist can settle on that same entity (his
    # albums back up the band's titles), and the leader's own fetch would ask
    # again - for Oscar Peterson, five Qobuz pages. Each caller gets its own
    # copy of the list.
    my %memo;
    my $copy = sub { defined $_[0] ? [ map { ref $_ eq 'HASH' ? { %$_ } : $_ } @{ $_[0] } ] : undef };
    my $fetchOnce = sub {
        my ($id, $cb) = @_;
        my $k = $id // '';
        if (my $m = $memo{$k}) {
            return $m->{done} ? $cb->($copy->($m->{list})) : push @{ $m->{wait} }, $cb;
        }
        $memo{$k} = { wait => [ $cb ] };
        $fetch->($id, sub {
            my $m = $memo{$k};
            @$m{qw(done list)} = (1, $_[0]);
            $_->($copy->($_[0])) for @{ delete $m->{wait} || [] };
        });
    };
    my $finish = sub {
        my ($force) = @_;
        return if $finished || !$main || ($left && !$force);
        $finished = 1;
        Slim::Utils::Timers::killSpecific($waitTimer) if $waitTimer;
        _dbg("$svc: '$query' - $left joint/leader artist(s) not back after "
            . JOINT_WAIT . 's, going without them') if $left;
        my ($artist, $albums, $beside) = @$main;
        my %have = map { (($_->{id} // '') => 1) } grep { ref $_ eq 'HASH' } @{ $albums || [] };
        # The passed-over duo's own albums (_resolveArtist), added as a joint
        # artist's are.
        my @dup = $beside
            ? (map { +{ %$_, _jointOf => $beside->[0]{name} } }
               grep { ref $_ eq 'HASH' && defined $_->{id} } @{ $beside->[1] || [] })
            : ();
        # Joint credits only beside an identified artist; the leader's albums
        # either way.
        my @extra = grep { !$have{ $_->{id} // '' }++ } (($artist ? (@got, @dup) : ()), @lead);
        $done->($artist, $albums, \@extra);
    };
    for my $ja (@joint) {
        $fetchOnce->($ja->{id}, sub {
            return if $finished;
            push @got, map { +{ %$_, _jointOf => $ja->{name} } }
                       grep { ref $_ eq 'HASH' && defined $_->{id} } @{ $_[0] || [] };
            $left--;
            $finish->();
        });
    }
    my $fetchLeader = sub {
        my ($hit, $name) = @_;
        if (!$hit || $fetching{ $hit->{id} }++) {
            _dbg("$svc: '$query' - no artist named '$name' (the band's leader) here") unless $hit;
            $left--;
            return $finish->();
        }
        _dbg("$svc: '$query' - fetching the band's leader '$name' ($hit->{id}) beside it");
        $fetchOnce->($hit->{id}, sub {
            return if $finished;
            push @lead, map { +{ %$_, _jointOf => $name } }
                        grep { ref $_ eq 'HASH' && defined $_->{id} } @{ $_[0] || [] };
            $left--;
            $finish->();
        });
    };
    for my $name (@want) {
        my $n = _norm($name);
        if (my $hit = _exactArtist($items, $n)) { $fetchLeader->($hit, $name); next }
        unless ($search) { $fetchLeader->(undef, $name); next }
        $search->($name, sub {
            return if $finished;
            $fetchLeader->(_exactArtist($_[0], $n), $name);
        });
    }
    _resolveArtist($svc, $query, $items, $spine, $fetchOnce, sub {
        $main = [ @_ ];
        $finish->();
        $waitTimer = Slim::Utils::Timers::setTimer(undef, time() + JOINT_WAIT,
            sub { $waitTimer = undef; $finish->(1) }) unless $finished;
    }, $aliases, $search, $strict, $compare);
}

# The first artist in a service's search hits whose name, normalised, IS $norm.
sub _exactArtist {
    my ($items, $norm) = @_;
    return undef unless ref $items eq 'ARRAY' && length($norm // '');
    for my $a (@$items) {
        next unless ref $a eq 'HASH' && defined $a->{id} && defined $a->{name};
        return $a if _norm($a->{name}) eq $norm;
    }
    return undef;
}

# A band with NO entity of its own on the service, whose leader's albums came
# back (_resolveWithJoints): those albums are its pool, rendered as joint albums
# (match-only, credited to the band for the matcher's gate). Nothing came back:
# undef, unresolved, exactly as before.
sub _leaderOnly {
    my ($svc, $query, $extra, $render) = @_;
    return undef unless ref $extra eq 'ARRAY' && @$extra;
    _dbg("$svc: '$query' has no artist of its own here - its leader's albums are the pool");
    return _appendJoint($svc, $query, $query, [], $extra, $render);
}

# The joint albums rendered with the adapter's own renderer ($render->(\@albums,
# $creditName)), one joint artist at a time, marked `_joint` and appended to the
# artist's own rendered list. Credited to the ARTIST for the matcher's gate: the
# joint name already proves he is on the record, and the page's own name may be
# a variant the joint credit does not contain ("James Yorkston and friends").
sub _appendJoint {
    my ($svc, $query, $artistName, $out, $extra, $render) = @_;
    return $out unless $out && $extra && @$extra;
    my (%by, @order);
    for my $al (@$extra) {
        my $n = $al->{_jointOf} // '';
        push @order, $n unless $by{$n};
        push @{ $by{$n} }, $al;
    }
    my @j;
    push @j, @{ $render->($by{$_}, $_) || [] } for @order;
    for my $it (@j) {
        $it->{_joint} = 1;
        $it->{_candArtist} = $artistName if defined $artistName && length $artistName;
    }
    _dbg("$svc: '$query' + " . scalar(@j) . ' album(s) from joint artist(s) '
        . join(', ', map { "'$_'" } @order)) if @j;
    return [ @$out, @j ];
}

sub _qobuzAlbumSearch {
    my ($api, $client, $query, $svc, $collect) = @_;
    $api->search(sub {
        my $res = shift;
        return $collect->(undef) unless defined $res;
        $collect->(_renderQobuzAlbums(
            $client, _albumArray(ref $res eq 'HASH' ? $res->{albums} : undef) || [], $svc, undef));
    }, lc($query), 'albums');
}

sub _renderQobuzAlbums {
    my ($client, $albums, $svc, $artistName, $query) = @_;
    return _renderAlbums($albums, $svc, $artistName,
        sub { Plugins::Qobuz::Plugin::_albumItem($client, $_[0]) },
        sub { defined $_[0]->{streamable} && !$_[0]->{streamable} }, $query);
}

sub _searchTidal {
    my ($client, $query, $svc, $collect, $spine, $aliases, $strict, $compare, $leaders) = @_;

    my $api = Plugins::TIDAL::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }

    # TIDAL splits a discography across filter buckets — fetch all three in
    # parallel and merge (id-deduped; the buckets shouldn't overlap).
    my $fetch = sub {
        my ($id, $done) = @_;
        my @filters = qw(ALBUMS EPSANDSINGLES COMPILATIONS);
        my (@albums, %seen);
        my $left = scalar @filters;
        for my $f (@filters) {
            $api->artistAlbums(sub {
                my $a = _albumArray(shift);
                push @albums, grep { ref $_ eq 'HASH' && defined $_->{id} && !$seen{$_->{id}}++ }
                    @{ $a || [] };
                $done->(_filterForeignArtist(\@albums, 'Tidal', $id, $query)) unless --$left;
            }, $id, $f);
        }
    };

    my $search = sub {
        my ($name, $done) = @_;
        $api->search(sub { $done->(ref $_[0] eq 'ARRAY' ? $_[0] : []) },
            { type => 'artists', search => $name, limit => 25 });
    };

    $api->search(sub {
        my $artists = shift;
        _resolveWithJoints('Tidal', $query, ref $artists eq 'ARRAY' ? $artists : [],
            $spine, $fetch, $aliases, $search, $strict, $compare, sub {
                my ($artist, $albums, $extra) = @_;
                unless ($artist) {
                    if ($spine && %$spine) {
                        return $collect->(_leaderOnly('Tidal', $query, $extra, sub { _renderTidalAlbums($_[0], $svc, $_[1]) }));
                    }
                    _dbg("Tidal: no artist hit for '$query' - album-search fallback");
                    return _tidalAlbumSearch($api, $query, $svc, $collect);
                }
                return $collect->(undef) unless $albums && @$albums;   # all-empty = failed fetch
                $collect->(_appendJoint('Tidal', $query, $artist->{name},
                    _renderTidalAlbums($albums, $svc, $artist->{name}, $query), $extra,
                    sub { _renderTidalAlbums($_[0], $svc, $_[1]) }));
            }, $leaders);
    }, { type => 'artists', search => $query, limit => 25 });
}

sub _tidalAlbumSearch {
    my ($api, $query, $svc, $collect) = @_;
    $api->search(sub {
        my $albums = shift;
        return $collect->(undef) unless defined $albums;
        $collect->(_renderTidalAlbums(_albumArray($albums) || [], $svc, undef));
    }, { type => 'albums', search => $query, limit => 50 });
}

sub _renderTidalAlbums {
    my ($albums, $svc, $artistName, $query) = @_;
    return _renderAlbums($albums, $svc, $artistName,
        sub { Plugins::TIDAL::Plugin::_renderAlbum($_[0]) }, undef, $query);
}

sub _searchDeezer {
    my ($client, $query, $svc, $collect, $spine, $aliases, $strict, $compare, $leaders) = @_;

    my $api = Plugins::Deezer::Plugin::getAPIHandler($client);
    unless ($api) { $collect->(undef); return }

    my $fetch = sub {
        my ($id, $done) = @_;
        $api->artistAlbums(sub { $done->(_albumArray(shift)) }, $id);
    };

    my $search = sub {
        my ($name, $done) = @_;
        $api->search(sub { $done->(ref $_[0] eq 'ARRAY' ? $_[0] : []) },
            { search => $name, type => 'artist', strict => 'off', limit => 25 });
    };

    $api->search(sub {
        my $artists = shift;
        _resolveWithJoints('Deezer', $query, ref $artists eq 'ARRAY' ? $artists : [],
            $spine, $fetch, $aliases, $search, $strict, $compare, sub {
                my ($artist, $albums, $extra) = @_;
                unless ($artist) {
                    if ($spine && %$spine) {
                        return $collect->(_leaderOnly('Deezer', $query, $extra, sub { _renderDeezerAlbums($_[0], $svc, $_[1]) }));
                    }
                    _dbg("Deezer: no artist hit for '$query' - album-search fallback");
                    return _deezerAlbumSearch($api, $query, $svc, $collect);
                }
                return $collect->(undef) unless $albums && @$albums;
                # /artist/N/albums items carry NO artist object — Deezer's own
                # _renderAlbum reads $item->{artist}{name} and would leave it undef,
                # which is exactly why it takes the artist name as a 3rd arg. Pass
                # the resolved name (verified: sub _renderAlbum($item,$addArtistToTitle,$artist)).
                $collect->(_appendJoint('Deezer', $query, $artist->{name},
                    _renderDeezerAlbums($albums, $svc, $artist->{name}, $query), $extra,
                    sub { _renderDeezerAlbums($_[0], $svc, $_[1]) }));
            }, $leaders);
    }, { search => $query, type => 'artist', strict => 'off', limit => 25 });
}

sub _deezerAlbumSearch {
    my ($api, $query, $svc, $collect) = @_;
    $api->search(sub {
        my $albums = shift;
        return $collect->(undef) unless defined $albums;
        $collect->(_renderDeezerAlbums(_albumArray($albums) || [], $svc, undef));
    }, { search => $query, type => 'album', strict => 'off', limit => 50 });
}

sub _renderDeezerAlbums {
    my ($albums, $svc, $artistName, $query) = @_;
    # 3rd arg backfills favorites_title when the payload has no artist object
    # (the artist-albums endpoint) — mirrors the plugin's own use.
    return _renderAlbums($albums, $svc, $artistName,
        sub { Plugins::Deezer::Plugin::_renderAlbum($_[0], 0, $artistName) }, undef, $query);
}

# ---------------------------------------------------------------------------
# SPOTIFY, via the Spotty plugin (docs/spotify-adapter-plan.md; Spotty 4.62.2's
# source read 2026-09-25). Same artist-first shape as _searchTidal, with three
# differences that all come from how Spotty answers:
#
#   1. EVERY FAILURE LOOKS LIKE SUCCESS. A 429, a dead token (a lapsed
#      subscription keeps its cached credentials: the handler exists and every
#      token refresh fails) and a 502 all reach us as an EMPTY list; undef never
#      does. So a Spotify search that returns ZERO raw results answers undef
#      (unresolved: CAND_ERR_TTL, and peekPool does not count it as resolved,
#      so hide_unmatched hides nothing on a failure nobody confirmed). LBF's
#      `_emptyResultIsError`. PFR declined it only because its warm would
#      re-search an absent album hourly for ever; this plugin has no warm and
#      re-asks only when someone opens that artist.
#   2. The title is `name` and `artist` is a STRING, so every album is reshaped
#      on a COPY (_spotifyAlbum) before the shared code sees it.
#   3. We page artistAlbums OURSELVES, one request at a time, at limit 50.
#      Spotty's Pipeline would otherwise fetch every page after the first in
#      PARALLEL, and a 429 part-way drops pages silently: a SHORTENED pool,
#      cached as found for three days.
#
# The refusal stamp is our own clock (PFR's shape), not Spotty's flag, which
# clears only on the next SUCCESSFUL response. Nothing here slows a view; the
# clock is kept so a later pump could read it. Declared above first use: `our`
# is lexically scoped, and a suite places the stamp.
# ---------------------------------------------------------------------------
use constant SPOTIFY_PAGE           => 50;    # Spotty sends ONE request per call at <= 50
use constant SPOTIFY_MAX_PAGES      => 4;     # 200 albums
use constant SPOTIFY_INCLUDE        => 'album,single,compilation';   # no appears_on
use constant SPOTIFY_ARTIST_LIMIT   => 25;    # Spotty's own default is 200 = 4 requests
use constant SPOTIFY_BACKOFF_WINDOW => 30;    # seconds; Spotify's observed Retry-After was 3-7s
our $SPOTIFY_REFUSED_AT = 0;

# Spotty's rate-limit flag, guarded so an older or reshaped Spotty reads as
# "no signal" rather than taking a resolve down.
sub _spottyRateLimited {
    my $f = Plugins::Spotty::API->can('hasError429') or return 0;
    return eval { $f->('Plugins::Spotty::API') } ? 1 : 0;
}

sub _spotifyBackingOff {
    return (time() - ($SPOTIFY_REFUSED_AT || 0)) < SPOTIFY_BACKOFF_WINDOW ? 1 : 0;
}

# An EMPTY answer from Spotty is never a verdict (see 1 above). Stamps the
# refusal clock when Spotty says it is rate-limiting, and logs which.
sub _spotifyEmpty {
    my ($what) = @_;
    my $refused = _spottyRateLimited();
    $SPOTIFY_REFUSED_AT = time() if $refused;
    _dbg("Spotify: $what returned nothing - "
        . ($refused ? 'Spotify is rate-limiting (429)' : 'no answer (dead token, 502 or genuinely none)')
        . ' - left unresolved');
    return undef;
}

# The reshaping step, on a COPY (Spotty caches the hash it hands us):
#   title  <- name       (_decorate's _candTitle, peekPool's title index)
#   artist <- artists[0] (the {id,name} hash: _albumArtistId, _filterForeignArtist
#                         and _renderAlbums' _candArtist all read a HASH artist)
# The fields Spotty's _albumItem reads (name, artists, release_date, image, uri)
# are untouched, so what it renders cannot change.
sub _spotifyAlbum {
    my ($al) = @_;
    return undef unless ref $al eq 'HASH';
    my %c = %$al;
    $c{title} = $c{name} if defined $c{name} && !defined $c{title};
    $c{artist} = $c{artists}[0]
        if ref $c{artists} eq 'ARRAY' && ref $c{artists}[0] eq 'HASH';

    # SIZE, in the words the shared _candSize already reads, so that sub stays
    # untouched for every other service. Spotify has no duration, so the
    # 30-minute rule cannot promote a 5-6 track LP: its `album_type` decides
    # for an album or compilation. It files EPs under `single`, so a single is
    # sized by its track count (1-3 single, 4-6 EP, more an album), the rule
    # the Qobuz copies get. No type, or a single with no count: unknown, which
    # matches exactly as before.
    my $type = lc($c{album_type} // '');
    if ($type eq 'album' || $type eq 'compilation') {
        $c{record_type} = 'album';
    }
    elsif ($type eq 'single' && defined $c{total_tracks} && $c{total_tracks} =~ /^\d+$/) {
        $c{tracks_count} = $c{total_tracks};
    }
    return \%c;
}

sub _searchSpotify {
    my ($client, $query, $svc, $collect, $spine, $aliases, $strict, $compare, $leaders) = @_;

    # A CLASS method, and it needs a client: none -> no handler -> unresolved
    # (never a confirmed miss). hasCredentials is deliberately never called: it
    # rescans cache folders on every call while empty.
    my $api = eval { Plugins::Spotty::Plugin->getAPIHandler($client) };
    unless ($api) { _dbg('Spotify: no API handler (no player, or signed out)'); $collect->(undef); return }

    # One page at a time; a short page ends the list, SPOTIFY_MAX_PAGES caps it.
    # An empty FIRST page is a failure (see 1 above). An empty LATER page ends
    # the list, unless Spotty is rate-limiting: then the whole list is undef,
    # never a shortened pool. (A 502 on a later page cannot be told from the
    # end of an exactly-50-album list; that is the residual.) A refusal answers
    # synchronously, so this recurses at most SPOTIFY_MAX_PAGES deep.
    my $fetch = sub {
        my ($id, $done) = @_;
        my @albums;
        my $page = sub {
            my ($self, $n) = @_;
            $api->artistAlbums(sub {
                my $got = shift;
                my @l = ref $got eq 'ARRAY' ? grep { ref $_ eq 'HASH' && defined $_->{id} } @$got : ();
                unless (@l) {
                    return $done->(_spotifyEmpty("artist $id albums page 1")) unless $n;
                    return $done->(_spotifyEmpty("artist $id albums page " . ($n + 1)))
                        if _spottyRateLimited();
                }
                push @albums, @l;
                if (@l >= SPOTIFY_PAGE && $n + 1 < SPOTIFY_MAX_PAGES) {
                    return $self->($self, $n + 1);
                }
                _dbg("Spotify: artist $id album list capped at " . scalar(@albums))
                    if @l >= SPOTIFY_PAGE;
                $done->(_filterForeignArtist([ map { _spotifyAlbum($_) } @albums ],
                    'Spotify', $id, $query));
            }, { uri => "spotify:artist:$id", limit => SPOTIFY_PAGE,
                 offset => $n * SPOTIFY_PAGE, include => SPOTIFY_INCLUDE });
        };
        $page->($page, 0);
    };

    my $search = sub {
        my ($name, $done) = @_;
        $api->search(sub { $done->(ref $_[0] eq 'ARRAY' ? $_[0] : []) },
            { query => $name, type => 'artist', limit => SPOTIFY_ARTIST_LIMIT });
    };

    $api->search(sub {
        my $artists = shift;
        return $collect->(_spotifyEmpty("artist search '$query'"))
            unless ref $artists eq 'ARRAY' && @$artists;
        _resolveWithJoints('Spotify', $query, $artists, $spine, $fetch,
            $aliases, $search, $strict, $compare, sub {
                my ($artist, $albums, $extra) = @_;
                unless ($artist) {
                    if ($spine && %$spine) {
                        return $collect->(_leaderOnly('Spotify', $query, $extra, sub { _renderSpotifyAlbums($client, $_[0], $svc, $_[1]) }));
                    }
                    _dbg("Spotify: no artist hit for '$query' - album-search fallback");
                    return _spotifyAlbumSearch($api, $client, $query, $svc, $collect);
                }
                return $collect->(undef) unless $albums && @$albums;
                $collect->(_appendJoint('Spotify', $query, $artist->{name},
                    _renderSpotifyAlbums($client, $albums, $svc, $artist->{name}, $query), $extra,
                    sub { _renderSpotifyAlbums($client, $_[0], $svc, $_[1]) }));
            }, $leaders);
    }, { query => $query, type => 'artist', limit => SPOTIFY_ARTIST_LIMIT });
}

sub _spotifyAlbumSearch {
    my ($api, $client, $query, $svc, $collect) = @_;
    $api->search(sub {
        my $albums = shift;
        return $collect->(_spotifyEmpty("album search '$query'"))
            unless ref $albums eq 'ARRAY' && @$albums;
        $collect->(_renderSpotifyAlbums($client,
            [ map { _spotifyAlbum($_) } grep { ref $_ eq 'HASH' } @$albums ], $svc, undef));
    }, { query => $query, type => 'album', limit => SPOTIFY_PAGE });
}

# $albums are already reshaped. Spotty puts its own album.png placeholder in
# `image` for an album without art, and tiles prefer _cover over Cover Art
# Archive art (Browse::_releaseItem), so only a real http(s) cover may become
# _cover; the row itself keeps the placeholder as its icon. Done here, not in
# the shared _decorate: no other service sends a placeholder that way.
sub _renderSpotifyAlbums {
    my ($client, $albums, $svc, $artistName, $query) = @_;
    my $out = _renderAlbums($albums, $svc, $artistName,
        sub { Plugins::Spotty::OPML::_albumItem($client, $_[0]) }, undef, $query);
    for my $it (@{ $out || [] }) {
        delete $it->{_cover} unless defined $it->{_cover} && $it->{_cover} =~ m{^https?://}i;
    }
    return $out;
}

# The artist-search leg (Browse's artist search). Zero raw results answer undef,
# so searchArtists marks Spotify FAILED and the merged list is not cached.
sub _artistsSpotify {
    my ($client, $query, $svc, $collect) = @_;
    my $api = eval { Plugins::Spotty::Plugin->getAPIHandler($client) };
    unless ($api) { $collect->(undef); return }
    $api->search(sub {
        my $list = shift;
        return $collect->(_spotifyEmpty("artist search '$query'"))
            unless ref $list eq 'ARRAY' && @$list;
        $collect->(_artistHits($list, $svc));
    }, { query => $query, type => 'artist', limit => SEARCH_MAX });
}

# Same-title release-groups ("rivals") compete for one candidate.
#
# The Beatles have FOUR official release-groups whose titles normalise to the
# artist name — the 1968 album plus compilations from 1967/1983/1988 — so the
# streaming album titled "The Beatles" title-matches all four and the White
# Album's artwork appeared four times (Simon, 2026-07-10). A candidate belongs
# to exactly ONE release group; this decides which.
#
# DELIBERATELY NOT nearest-year. Streaming catalogues date a remaster by its
# REISSUE year, so a 2009 White Album remaster is nearer 1988 than 1968 and
# nearest-year would hand it to the compilation — worse than the bug. The rule
# is therefore conservative:
#   * candidate year EXACTLY equals a rival's first-release year -> that rival
#     (a service listing the 1988 compilation as 1988 gets it right);
#   * otherwise the EARLIEST rival wins. A self-titled album is the original;
#     the later same-named records are compilations of it.
# An undated or reissue-dated candidate therefore lands on the real album, and
# the compilations show nothing rather than a wrong thing.
#
# $rivals must be pre-sorted deterministically (see Browse::_rivalsByTitle):
# dated ascending, undated last, mbid as the final tiebreak — the whole feed's
# item_id walk depends on this being stable across rebuilds.
sub _rivalOwner {
    my ($candYear, $rivals) = @_;
    if ($candYear) {
        for my $r (@$rivals) {
            return $r->{mbid} if $r->{year} && $r->{year} == $candYear;
        }
    }
    return $rivals->[0]{mbid};
}

# Tier 0 — EXACT IDENTITY, ahead of every title rule and immune to all of them.
# A library album tagged MUSICBRAINZ_ALBUMID carries a RELEASE mbid; MB models
# reissues, box sets and bonus-disc editions as releases under ONE release
# group, so the release->group map (API::peekReleaseMap, free from the bootleg
# check) answers "is this album this tile?" with no string comparison at all.
# This is what makes "The Beatles and Esher Demos" resolve to the White Album:
# the titles share nothing the matcher can use, but they are the same group.
# Some taggers write the GROUP mbid instead, so accept a direct hit too.
# Streaming candidates carry no MBID -> they always fall through to the matcher.
sub _mbidMatch {
    my ($it, $rgMbid, $relMap) = @_;
    my $mb = $it->{_mbid} or return 0;
    return 0 unless $rgMbid;
    return 1 if $mb eq $rgMbid;
    return 1 if $relMap && defined $relMap->{$mb} && $relMap->{$mb} eq $rgMbid;
    return 0;
}

# The group a local copy's MBID places it in, when that group is one of this
# page's ($idGroups = { rg-mbid => 1 }). A copy matched there by id is not
# offered to any other group by title (Simon, 2026-09-19: "it should not try to
# match again it if its matched via id"). No id, an id the release map cannot
# place, or a group not on the page -> undef, and the title decides as before.
sub _idGroup {
    my ($it, $relMap, $idGroups) = @_;
    my $mb = $it->{_mbid} or return undef;
    return undef unless $idGroups && %$idGroups;
    return $mb if $idGroups->{$mb};
    my $g = $relMap ? $relMap->{$mb} : undef;
    return (defined $g && $idGroups->{$g}) ? $g : undef;
}

# ===========================================================================
# Matching (verbatim from the Pitchfork/ListenBrainz plugins — keep in sync)
# ===========================================================================

# An MB release-group ALIAS is a weaker claim than the group's own title, so it
# does NOT get the full rule set — the same discipline 0.11.1 applied to
# self-titled releases, and for the same reason. The prefix rule reads
# "<album> <extra>" as an edition suffix, which is right for "(Deluxe)" and
# WRONG for a different record that merely starts with the same words: via the
# alias "The Man·Machine", Kraftwerk's "Die Mensch·Maschine" claimed the remix
# tribute album "The Man-Machine Recreated" (caught by t_alias.pl, 2026-07-22).
#
# So an alias must be the WHOLE title, with one deliberate exception: a "/" or
# ":" immediately after it marks an ALTERNATE TITLE rather than an edition, and
# that is still the same record — Big Star's release group `3rd` (alias
# "Third") against the owned copy "Third/Sister Lovers".
#
# The artist gate is unchanged: shape is decided here, identity by _albumMatches.
# DSC-ONLY call-site logic — aliases are not part of the shared matcher, so this
# does NOT trip LBF's tools/matcher_sync_check.py.
sub _aliasMatches {
    my ($artistNorm, $aliasNorm, $aliasRaw, $candArtist, $candTitle) = @_;
    return 0 unless defined $candTitle && length $candTitle;
    my $cn = _norm($candTitle);
    unless ($cn eq $aliasNorm) {
        return 0 unless $candTitle =~ m{^\s*\Q$aliasRaw\E\s*[/:]}i;
    }
    return _albumMatches($artistNorm, $aliasNorm, $candArtist, $candTitle, $aliasRaw);
}

sub _albumMatches {
    my ($artistNorm, $albumNorm, $candArtist, $candTitle, $albumRaw) = @_;

    # All-punctuation / single-char titles ("( )", "X") normalise to (near)
    # nothing, so the standard path can't see them. Compare a punctuation-
    # PRESERVING form instead — lowercase, whitespace stripped: "( )" == "()"
    # but != "( ) (live)". Exact equality only (a prefix rule here would let
    # "x" swallow "xx") and the artist gate is mandatory — a match this thin
    # can't stand on the title alone. (Sigur Rós "( )", 2026-07-10.)
    if (length $albumNorm < 2) {
        my $ap = _punctNorm($albumRaw);
        return 0 unless length $ap;
        return 0 unless _punctNorm($candTitle) eq $ap;
        return 0 if $artistNorm eq '';
        return _artistMatch($artistNorm, _norm($candArtist));
    }
    my $t = _norm($candTitle);
    return 0 if $t eq '';

    # SELF-TITLED releases ("The Beatles", "Weezer") match on the EXACT title
    # only. Every rule below reads "<album> <extra>" as the same album carrying
    # an edition suffix — true for "(Deluxe)", catastrophic when the album
    # title IS the artist name, where it swallows the whole discography: the
    # "The Beatles" release-group matched "The Beatles 1962-1966" (the Red
    # album), "The Beatles 1967-1970" (Blue) and "The Beatles Anthology 1".
    # Via claimedLocalIds it also swallowed the user's own copies of those
    # albums, hiding them from the library-extras section. Bracketed decoration
    # is already stripped by _norm, so the White Album still matches its
    # "The Beatles (White Album)" / "(Remastered)" listings.
    # Residual, NOT fixable on title alone: MusicBrainz has four release-groups
    # titled "The Beatles", so one candidate legitimately matches them all.
    # (Simon's library, 2026-07-10.)
    if (length($artistNorm) && $albumNorm eq $artistNorm) {
        return 0 unless $t eq $albumNorm;
        return _artistMatch($artistNorm, _norm($candArtist));
    }

    my $ok = ($t eq $albumNorm || index($t, "$albumNorm ") == 0);

    # Trailing format descriptor ("… EP"/"… LP") present on one side only.
    if (!$ok) {
        my $ab = _stripFmt($albumNorm);
        my $tb = _stripFmt($t);
        $ok = 1 if length($ab) >= 3 && length($tb) >= 3
                && ($tb eq $ab || index($tb, "$ab ") == 0);
    }

    # Decorative non-ASCII glyphs spelled differently between sources.
    if (!$ok) {
        my $aa = _asciiNorm($albumNorm);
        my $ta = _asciiNorm($t);
        $ok = 1 if length($aa) >= 2 && length($ta) >= 2
                && ($ta eq $aa || index($ta, "$aa ") == 0);
    }

    # COMPOUND-WORD / WORD-BOUNDARY variant: the two titles are identical once
    # every space is removed -- e.g. MB "England's Newest Hit Makers" (the
    # Rolling Stones' 1964 debut) vs the streaming spelling "England's Newest
    # Hitmakers" ('hit makers' <-> 'hitmakers'). The services and MusicBrainz
    # routinely disagree on whether a compound is one word or two, and no fold
    # above sees a space as optional. EXACT space-collapsed equality ONLY -- no
    # prefix rule here, because collapsing the spaces also destroys the word
    # boundary that makes the prefix tiers safe (a prefix match on
    # "hitmakers..." could then swallow an unrelated title). Length-gated so a
    # short collapsed key can't collide by accident. Field: 2026-07-24.
    #
    # DELIBERATE DSC-ONLY DIVERGENCE from the fleet-synced matcher (held here to
    # prove in the field before porting to LBF/PFR/LL) -- so matcher_sync_check
    # reports drift on _albumMatches BY DESIGN until this is ported.
    if (!$ok) {
        (my $as = $albumNorm) =~ s/\s+//g;
        (my $ts = $t)         =~ s/\s+//g;
        $ok = 1 if length($as) >= 6 && $ts eq $as;
    }

    # Titles carrying the ARTIST NAME as a prefix on ONE side only — e.g. the
    # release "Belle and Sebastian Write About Love" vs the MB release-group
    # "Write About Love" (found via Simon's library 2026-07-09; also fixes the
    # same album's streaming match). Strip a leading "<artist> " from both
    # sides and re-compare; gated on a >=3 char remainder, and the artist
    # check below still applies. DELIBERATE DIVERGENCE from the LBF/PFR
    # matcher — candidate to port back upstream.
    #
    # NOT across a spaced slash: "The B‐52’s / Cosmic Thing" is TWO titles, the
    # first of which merely equals the artist name. _norm erases the slash, so
    # without this the two-album set claimed "Cosmic Thing" and a streaming
    # two-fer would be claimed by the "Cosmic Thing" group (field, 2026-09-19).
    # Only the side carrying the slash is refused, so the other side still
    # gets its own prefix stripped.
    if (!$ok && length $artistNorm) {
        my $ab = ($albumRaw  // '') =~ m{\s/\s} ? $albumNorm
               : _stripArtistPrefix($albumNorm, $artistNorm);
        my $tb = ($candTitle // '') =~ m{\s/\s} ? $t
               : _stripArtistPrefix($t, $artistNorm);
        if (($ab ne $albumNorm || $tb ne $t) && length($ab) >= 3 && length($tb) >= 3) {
            $ok = 1 if $tb eq $ab || index($tb, "$ab ") == 0;
        }
    }
    return 0 unless $ok;

    return ($t eq $albumNorm) ? 1 : 0 if $artistNorm eq '';
    return _artistMatch($artistNorm, _norm($candArtist));
}

sub _stripFmt {
    my $s = shift // '';
    $s =~ s/\s+(?:ep|lp)$//;
    return $s;
}

# Lowercased, whitespace-stripped, punctuation KEPT — only for titles _norm
# erases (see the short-title branch in _albumMatches).
sub _punctNorm {
    my $s = shift // '';
    if (!utf8::is_utf8($s) && $s =~ /[^\x00-\x7f]/) {
        my $d = $s;
        $s = $d if utf8::decode($d);
    }
    $s = lc($s);
    $s =~ s/\s+//g;
    return $s;
}

sub _stripArtistPrefix {
    my ($t, $a) = @_;
    return substr($t, length($a) + 1) if index($t, "$a ") == 0;
    return $t;
}

sub _asciiNorm {
    my $s = shift // '';
    $s =~ s/[^\x00-\x7f]+/ /g;
    $s =~ s/[^a-z0-9]+/ /g;
    $s =~ s/^\s+//; $s =~ s/\s+$//;
    $s =~ s/\s+/ /g;
    return $s;
}

# First-token index keys for an already-NORMALISED title — a SUPERSET pre-filter
# so a release group only tests candidates that COULD match it. Testing every
# streaming candidate (pools run to hundreds) against every release group was the
# render's R x C matcher cost. NOT part of the shared matcher — it only decides
# which candidates reach the unchanged _albumMatches, so it changes a result only
# where it is NOT a proper superset - see the compound-word caveat below. Every
# _albumMatches positive path
# leaves the two normalised titles sharing a first token in AT LEAST ONE form:
#   - the norm itself       (exact / trailing-extra prefix / _stripFmt: _stripFmt
#                            only trims a trailing "ep"/"lp", so the front is kept)
#   - _asciiNorm(norm)      (an accented FIRST token spelled differently per side)
#   - artist-prefix stripped ("<artist> <album>" present on one side only)
# so indexing candidates under all three and looking a release group up under all
# three carries those paths across. It is a NARROWING, not a guarantee, and the
# distinction matters: the COMPOUND-WORD tier matches two titles that differ only
# in where the spaces fall, and when that difference lands in the FIRST word
# ("Sun Flower" / "Sunflower") the two sides bucket apart and the candidate never
# reaches _albumMatches at all. Left as is, deliberately: the field cases run
# mid-title ("England's Newest Hit Makers"), where the first token is shared.
# DO NOT restate this as "cannot miss a real match" - it said exactly that until
# 2026-09-11. No claim of that shape is worth making about a matcher working
# across services that each spell an album their own way; the tiers are here to
# guard the cases we have actually seen, and new ones get handled as they turn up.
# Short (<2 char) normalised titles match via the raw-punctuation branch instead
# and are full-scanned at the call site.
sub _titleKeys {
    my ($norm, $artistNorm) = @_;
    return () unless defined $norm && length $norm;
    my %k;
    $k{$1} = 1 if $norm =~ /^(\S+)/;
    my $a = _asciiNorm($norm);
    $k{$1} = 1 if length $a && $a =~ /^(\S+)/;
    if (defined $artistNorm && length $artistNorm) {
        my $p = _stripArtistPrefix($norm, $artistNorm);
        $k{$1} = 1 if $p ne $norm && length $p && $p =~ /^(\S+)/;
    }
    delete $k{''};
    return keys %k;
}

sub _artistMatch {
    my ($a, $b) = @_;
    return 0 if $a eq '' || $b eq '';

    my %at = map { ($_ => 1) } split ' ', $a;
    my %bt = map { ($_ => 1) } split ' ', $b;
    my ($small, $big) = (scalar keys %at <= scalar keys %bt) ? (\%at, \%bt) : (\%bt, \%at);

    for my $tok (keys %$small) {
        return 0 unless $big->{$tok};
    }
    return 1;
}

my $HAVE_NFD = eval { require Unicode::Normalize; 1 } ? 1 : 0;
# LETTERS NFD CANNOT DECOMPOSE.
#
# The NFD pass above strips COMBINING MARKS, which is why every true accent
# already folds: "Sigur Rós", "Björk", "Dvořák", "Beyoncé" all reduce to ASCII
# without a single table entry. What NFD cannot touch is a letter whose mark is
# part of the glyph itself — a STROKE (ø đ ł ŧ ƀ), a HOOK (ɓ ɗ ƙ), or a
# LIGATURE/DIGRAPH (æ œ ĳ ǉ) — because those are atomic codepoints with no
# canonical decomposition. Left alone they survive into the key as non-ASCII,
# so the name is unfindable typed the plain way.
#
# Applied AFTER lc(), so only lowercase forms are needed — but note that several
# uppercase Latin Extended-B letters lowercase to a DIFFERENT block (Ⱥ U+023A ->
# ⱥ U+2C65, Ʉ U+0244 -> ʉ U+0289), which is why those targets appear here.
#
# Swept 2026-07-21 across U+00C0-U+024F: 130 letters reached the key non-ASCII
# before this table, 26 after. The 26 left are click consonants (ǀ ǁ ǂ ǃ),
# glottal stops (ɂ) and tone/phonetic letters with no sensible ASCII base —
# deliberately unmapped, because guessing a base is worse than not folding.
my %FOLD = (
    # ligatures and digraphs
    "\x{e6}"  => 'ae', "\x{153}" => 'oe', "\x{df}"  => 'ss', "\x{fe}" => 'th',
    "\x{133}" => 'ij', "\x{1c6}" => 'dz', "\x{1f3}" => 'dz', "\x{1c9}" => 'lj',
    "\x{1cc}" => 'nj', "\x{223}" => 'ou', "\x{195}" => 'hv', "\x{1a3}" => 'oi',
    # stroked / barred letters
    "\x{f8}"  => 'o', "\x{111}" => 'd', "\x{142}" => 'l', "\x{127}" => 'h',
    "\x{167}" => 't', "\x{180}" => 'b', "\x{19a}" => 'l', "\x{1e5}" => 'g',
    "\x{23c}" => 'c', "\x{23f}" => 's', "\x{240}" => 'z', "\x{247}" => 'e',
    "\x{249}" => 'j', "\x{24b}" => 'q', "\x{24d}" => 'r', "\x{24f}" => 'y',
    "\x{1b6}" => 'z', "\x{2c65}" => 'a', "\x{2c66}" => 't', "\x{289}" => 'u',
    "\x{268}" => 'i', "\x{275}" => 'o',
    # hooked letters
    "\x{253}" => 'b', "\x{188}" => 'c', "\x{256}" => 'd', "\x{257}" => 'd',
    "\x{192}" => 'f', "\x{260}" => 'g', "\x{199}" => 'k', "\x{1ad}" => 't',
    "\x{1a5}" => 'p', "\x{272}" => 'n', "\x{19e}" => 'n', "\x{288}" => 't',
    "\x{28b}" => 'v', "\x{1b4}" => 'y', "\x{271}" => 'm',
    # dotless, long-s, turned and archaic forms
    "\x{131}" => 'i', "\x{17f}" => 's', "\x{140}" => 'l', "\x{138}" => 'k',
    "\x{149}" => 'n', "\x{14b}" => 'n', "\x{1dd}" => 'e', "\x{259}" => 'e',
    "\x{254}" => 'o', "\x{25b}" => 'e', "\x{25c}" => 'e', "\x{292}" => 'z',
    "\x{250}" => 'a', "\x{26f}" => 'm', "\x{28a}" => 'u', "\x{26a}" => 'i',
    "\x{283}" => 'sh', "\x{263}" => 'g', "\x{28c}" => 'v', "\x{280}" => 'r',
    "\x{21d}" => 'g', "\x{1bf}" => 'w', "\x{1a8}" => 's', "\x{225}" => 'z',
    "\x{221}" => 'd', "\x{234}" => 'l', "\x{235}" => 'n', "\x{236}" => 't',
    "\x{237}" => 'j', "\x{f0}"  => 'd',
);

sub _norm {
    my $s = shift // '';
    if (!utf8::is_utf8($s) && $s =~ /[^\x00-\x7f]/) {
        my $d = $s;
        $s = $d if utf8::decode($d);
    }
    $s = lc($s);
    if ($HAVE_NFD && utf8::is_utf8($s)) {
        $s = Unicode::Normalize::NFC(
             Unicode::Normalize::NFD($s) =~ s/[\x{0300}-\x{036F}]+//gr );
        $s =~ s/([^\x00-\x7f])/exists $FOLD{$1} ? $FOLD{$1} : $1/ge;
    }
    # LEETSPEAK SUBSTITUTIONS — a punctuation mark standing in for a LETTER.
    #
    # Applied ONLY when a word character FOLLOWS the mark. That is precisely
    # what separates a letter from decoration: "P!nk" -> pink and "Ke$ha" ->
    # kesha (the mark sits INSIDE the word), while a trailing or free-standing
    # mark is punctuation and falls through to the [^\p{Alnum}] rule below.
    #
    # WHY, and it is not cosmetic (field, 2026-07-21): the old unconditional
    # fold made a name spelled WITH the mark disagree with the same name
    # spelled WITHOUT it — "Layo & Bushwacka!" -> 'layo bushwackai' against
    # 'layo bushwacka'. `_albumMatches`' artist gate is MANDATORY, so EVERY
    # streaming candidate was rejected and the page read "No releases found"
    # for an artist with five MB albums and a correctly resolved MBID. The same
    # fold also made "Panic At The Disco" unsearchable without the "!", and let
    # the same-name row fold pick a different survivor from one query to the
    # next (whichever spelling won decided whether the page then worked).
    #
    # A name made ENTIRELY of these marks ("!!!", a real band) keeps the old
    # unconditional fold: stripping would leave '', and `_artistMatch` rejects
    # an empty side outright — i.e. this very bug in a new costume.
    # "$" and "@" are UNCONDITIONAL: in a stylised name they are effectively
    # always a letter, including at the END - "$uicideboy$" is Suicideboy(s),
    # so the trailing "$" is an s, not decoration. Scoping the boundary rule
    # below to them broke exactly that (caught by the cross-repo behaviour
    # harness, which PFR documents as a supported case).
    $s =~ s/\$/s/g;
    $s =~ s/\@/a/g;
    # "!" IS different, and it is the one that motivated this: it has a real
    # decorative use that the others do not - "Wham!", "Panic! At The Disco",
    # "Godspeed You! Black Emperor", "Layo & Bushwacka!" - where the mark is
    # punctuation and the name is spelled both ways in the wild. So "!" folds
    # to a letter ONLY when a word character FOLLOWS it (inside a word, as in
    # "P!nk"); otherwise it falls through to the [^\p{Alnum}] pass below.
    #
    # A name of nothing BUT marks ("!!!", a real band) keeps the unconditional
    # fold: stripping would leave '', and `_artistMatch` rejects an empty side
    # outright - this very bug in a new costume.
    if ($s =~ /[\p{Alnum}]/) { $s =~ s/(?<=\w)!(?=\w)/i/g }
    else                      { $s =~ s/!/i/g }
    $s =~ s/\x{20ac}/e/g;   # euro sign
    $s =~ s/\x{a3}/l/g;     # pound sign
    $s =~ s/\x{a5}/y/g;     # yen sign

    # "&" and "+" are SPOKEN "and", and this is the same rule as every
    # substitution above it — a symbol folded to the word it stands for, like
    # $ -> s and ! -> i. Without it the two spellings key differently ("simon
    # garfunkel" vs "simon and garfunkel", because & alone becomes a space
    # below), so the SAME act arrives from two services as two search rows and
    # only merges if MusicBrainz happens to record the variant as an alias.
    # Field 2026-07-21: Deezer says "Layo and bushwacka!" where Tidal says
    # "Layo & Bushwacka" — one act, two rows.
    #
    # "+" is included because services use it the same way; MB's own alias list
    # for that duo literally carries "Layo + Bushwacka!".
    $s =~ s/[&+]/ and /g;
    $s =~ s/[\(\[].*?[\)\]]//g;

    # APOSTROPHES ELIDE — they do NOT become a space. Every other mark handled
    # by the [^\p{Alnum}] rule below SEPARATES words; an apostrophe sits INSIDE
    # one, marking a contraction or a possessive, and both spellings of the same
    # name are common in the wild.
    #
    # WHY (field, 2026-07-21): spacing it keyed "Jane's Addiction" as
    # 'jane s addiction' against 'janes addiction'. `_artistMatch` is an
    # exact-token SUBSET test, so the token 'janes' matched nothing on the other
    # side and the act failed to match against EVERY source — not just the
    # library. Same for O'Connor/OConnor, D'Angelo/DAngelo, The B-52's/B-52s.
    # This is the "!" fold's mandatory-artist-gate failure in another costume.
    #
    # LMS's own index agrees with eliding: it TOKENISES on the apostrophe
    # (verified live — `artists search:Connor` returns "Sinead O'Connor", and
    # `search:s Addiction` returns "Jane's Addiction"), so folding the mark away
    # is the one choice that puts both spellings on a single key.
    #
    # GUARD — "'n'" contracting "and" is the exception, because there the mark
    # joins two WORDS rather than sitting inside one. All three spellings agree
    # TODAY ("Rock'n'Roll", "Rock 'n' Roll" and "Rock N Roll" all key
    # 'rock n roll'); eliding blindly would key the first as 'rocknroll' and
    # break a set that currently works. Space that one form first and the
    # three-way agreement survives untouched.
    my $apos = qr/['\x{2019}\x{2018}\x{02bc}\x{00b4}\x{2032}`]/;
    $s =~ s/(?<=\w)${apos}n${apos}(?=\w)/ n /g;
    $s =~ s/$apos//g;

    $s =~ s/[^\p{Alnum}]+/ /g;
    $s =~ s/^\s+//; $s =~ s/\s+$//;
    $s =~ s/\s+/ /g;
    return $s;
}

1;
